package com.autopilot.nonroot.engine

import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicInteger

data class ProxyNode(
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val countryCode: String = "US",
    var isHealthy: Boolean = false,
    var latencyMs: Long = -1
) {
    val address: String get() = "$host:$port"
    val hasAuth: Boolean get() = !username.isNullOrBlank() && !password.isNullOrBlank()
    val label: String get() = "Proxy ($countryCode)"
    val timezoneId: String get() = when (countryCode.uppercase()) {
        "US" -> "America/New_York"
        "EU", "DE" -> "Europe/Berlin"
        "UK", "GB" -> "Europe/London"
        "CA" -> "America/Toronto"
        "SG" -> "Asia/Singapore"
        else -> "UTC"
    }
    val acceptLanguage: String get() = when (countryCode.uppercase()) {
        "US" -> "en-US,en;q=0.9"
        "EU", "DE" -> "de-DE,de;q=0.9,en;q=0.8"
        "UK", "GB" -> "en-GB,en;q=0.9"
        else -> "en-US,en;q=0.9"
    }
}

data class ProxyFetchProgress(
    val tested: Int = 10,
    val total: Int = 10,
    val healthyCount: Int = 10,
    val statusText: String = "10 Webshare proxies loaded"
)

object ProxyManager {

    val defaultWebshareProxies: List<ProxyNode> = listOf(
        ProxyNode("45.38.107.97", 6014, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("64.137.96.74", 6641, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("198.23.243.226", 6361, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("38.154.185.97", 6370, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("84.247.60.125", 6095, "kcudnecs", "ut4unay8glit", "EU", isHealthy = true),
        ProxyNode("191.96.254.138", 6185, "kcudnecs", "ut4unay8glit", "EU", isHealthy = true),
        ProxyNode("198.46.161.42", 5092, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("64.137.10.153", 5803, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("104.164.49.38", 7693, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("23.26.71.145", 5628, "kcudnecs", "ut4unay8glit", "US", isHealthy = true)
    )

    fun parseBulkProxies(rawText: String): List<ProxyNode> {
        return rawText.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.contains(":") }
            .mapNotNull { line ->
                val cleaned = line.removePrefix("http://").removePrefix("https://").trimEnd('/')
                val parts = cleaned.split(":")
                val port = parts.getOrNull(1)?.toIntOrNull() ?: return@mapNotNull null
                when (parts.size) {
                    2 -> ProxyNode(parts[0].trim(), port, isHealthy = true)
                    4 -> ProxyNode(parts[0].trim(), port, parts[2].trim(), parts[3].trim(), isHealthy = true)
                    else -> null
                }
            }
    }

    suspend fun testProxyHealth(
        node: ProxyNode,
        testUrl: String = "https://www.google.com/generate_204"
    ): ProxyNode = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress(node.host, node.port))
            val conn = URL(testUrl).openConnection(proxy)
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.connect()
            val latency = System.currentTimeMillis() - start
            node.copy(isHealthy = true, latencyMs = latency)
        } catch (_: Exception) {
            node.copy(isHealthy = false, latencyMs = -1)
        }
    }

    suspend fun testProxyPool(
        nodes: List<ProxyNode>,
        onProgress: (ProxyFetchProgress) -> Unit
    ): List<ProxyNode> = withContext(Dispatchers.IO) {
        if (nodes.isEmpty()) return@withContext emptyList()
        val testedCount = AtomicInteger(0)
        val healthyCount = AtomicInteger(0)

        withContext(Dispatchers.Main) {
            onProgress(ProxyFetchProgress(0, nodes.size, 0, "Testing ${nodes.size} proxies..."))
        }

        val results = coroutineScope {
            nodes.map { node ->
                async(Dispatchers.IO) {
                    val res = testProxyHealth(node)
                    val t = testedCount.incrementAndGet()
                    val h = if (res.isHealthy) healthyCount.incrementAndGet() else healthyCount.get()
                    withContext(Dispatchers.Main) {
                        onProgress(ProxyFetchProgress(t, nodes.size, h, "Tested $t/${nodes.size} ($h reachable)"))
                    }
                    res
                }
            }.awaitAll()
        }

        val sorted = results.sortedWith(
            compareByDescending<ProxyNode> { it.isHealthy }.thenBy { if (it.latencyMs >= 0) it.latencyMs else 99999L }
        )
        val online = sorted.count { it.isHealthy }
        withContext(Dispatchers.Main) {
            onProgress(ProxyFetchProgress(nodes.size, nodes.size, online, "$online/${nodes.size} proxies reachable"))
        }
        sorted
    }

    fun applyProxyToWebView(
        node: ProxyNode?,
        directFallback: Boolean = false,
        executor: Executor = Executor { it.run() },
        onApplied: () -> Unit
    ) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            onApplied()
            return
        }

        if (node == null) {
            ProxyController.getInstance().clearProxyOverride(executor, onApplied)
            return
        }

        val builder = ProxyConfig.Builder()
            .addProxyRule("http://${node.host}:${node.port}")

        if (directFallback) {
            builder.addDirect()
        }

        ProxyController.getInstance().setProxyOverride(builder.build(), executor, onApplied)
    }
}
