# AutoPilot Best v6.0 Ultimate (Android Native Kotlin + Jetpack Compose)

## What's New in v6.0 Ultimate
- **1–2,000 Mini-Web Batch Queue Engine**: Configure from **1 up to 2,000 total target pages**, processed automatically in safe concurrent mini-tab batches (1–12 mini WebViews at a time) so your phone never crashes from RAM exhaustion.
- **Synchronized Page-Load Timer**: Countdown timer **does NOT start** until ALL active pages in the current batch finish loading (`onPageFinished`), with a live `Loading X/Y` status indicator and a 35s anti-hang fallback.
- **Dead Proxy Auto-Skip + Async Latency Tester**: Pre-loaded with your 10 Webshare proxies (saved in `SharedPreferences`), real `HTTP CONNECT` + `Proxy-Authorization` latency testing, and automatic failover that skips dead/unreachable proxies on error.
- **3-Mode Live View (Stats / Mini-Grid / Full WebView)**: Inspect your realtime dashboard, watch all active mini-tabs side-by-side in a compact 2-column **Mini-Grid**, or expand any tab to full-screen WebView.
- **Data & RAM Saver (Block Images)**: Optional toggle to skip heavy network images for faster loading across large 1,000–2,000 page queues.
- **All v5.5 Pro Features Preserved**: Persistent Foreground Service (`START_STICKY` + `PARTIAL_WAKE_LOCK`), 5-layer Deep Auto Clear Cache, Non-Root Device Spoofing (Device ID + User-Agent rotation), IP-Matched Timezone, Auto Scroll, Auto Video View (with mute), and Auto Click & Back (2s–60s custom slider).
