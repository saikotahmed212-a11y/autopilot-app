package com.autopilot.nonroot.engine

import java.security.MessageDigest
import kotlin.random.Random

data class DeviceProfile(
    val name: String,
    val modelCode: String,
    val userAgent: String,
    val acceptLanguage: String = "en-US,en;q=0.9",
    val osLabel: String = "Android 14",
    val platform: String = "Linux armv8l",
    val screenWidth: Int = 412,
    val screenHeight: Int = 915,
    val hardwareConcurrency: Int = 8
) {
    val id: String get() = name
}

object DeviceProfileEngine {
    val profiles: List<DeviceProfile> = listOf(
        DeviceProfile(
            name = "Pixel 8 Pro (Android 14)",
            modelCode = "PX8P",
            userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "Android 14",
            platform = "Linux armv8l",
            screenWidth = 412,
            screenHeight = 915,
            hardwareConcurrency = 8
        ),
        DeviceProfile(
            name = "Galaxy S24 Ultra (Android 14)",
            modelCode = "S24U",
            userAgent = "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "Android 14",
            platform = "Linux aarch64",
            screenWidth = 412,
            screenHeight = 892,
            hardwareConcurrency = 8
        ),
        DeviceProfile(
            name = "iPhone 15 Pro (iOS 17.6)",
            modelCode = "IP15P",
            userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "iOS 17.6",
            platform = "iPhone",
            screenWidth = 393,
            screenHeight = 852,
            hardwareConcurrency = 6
        ),
        DeviceProfile(
            name = "OnePlus 12 (Android 14)",
            modelCode = "OP12",
            userAgent = "Mozilla/5.0 (Linux; Android 14; CPH2581) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
            acceptLanguage = "en-GB,en;q=0.9",
            osLabel = "Android 14",
            platform = "Linux armv8l",
            screenWidth = 412,
            screenHeight = 919,
            hardwareConcurrency = 8
        ),
        DeviceProfile(
            name = "Windows 11 Chrome (Desktop)",
            modelCode = "WIN11",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "Windows 11",
            platform = "Win32",
            screenWidth = 1920,
            screenHeight = 1080,
            hardwareConcurrency = 12
        )
    )

    fun getRandomProfile(): DeviceProfile = profiles.random()

    fun pickRandom(excludeId: String? = null): DeviceProfile {
        val candidates = profiles.filter { it.name != excludeId }
        return if (candidates.isNotEmpty()) candidates.random() else getRandomProfile()
    }

    fun generateNonRootDeviceId(profile: DeviceProfile): String {
        val seed = "${profile.modelCode}-${System.nanoTime()}-${Random.nextInt(10000, 99999)}"
        val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val hex = digest.take(6).joinToString("") { "%02X".format(it) }
        return "${profile.modelCode}-$hex"
    }

    fun sanitizeUserAgent(ua: String): String = ua.replace("; wv", "")
}
