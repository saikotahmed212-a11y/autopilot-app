package com.autopilot.nonroot.engine

import android.util.Base64
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicInteger

data class ProxyNode(
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val countryCode: String = "US",
    val isHealthy: Boolean = true,
    val latencyMs: Long = -1L
) {
    val address: String get() = "$host:$port"
    val hasAuth: Boolean get() = !username.isNullOrBlank() && !password.isNullOrBlank()
    val timezoneId: String get() = when (countryCode.uppercase()) {
        "US" -> "America/New_York"
        "EU", "DE" -> "Europe/Berlin"
        "UK", "GB" -> "Europe/London"
        "CA" -> "America/Toronto"
        "FR" -> "Europe/Paris"
        "NL" -> "Europe/Amsterdam"
        "SG" -> "Asia/Singapore"
        "JP" -> "Asia/Tokyo"
        "AU" -> "Australia/Sydney"
        else -> "UTC"
    }
    val acceptLanguage: String get() = when (countryCode.uppercase()) {
        "EU", "DE" -> "de-DE,de;q=0.9,en;q=0.8"
        "UK", "GB" -> "en-GB,en;q=0.9"
        else -> "en-US,en;q=0.9"
    }
}

data class ProxyFetchProgress(
    val tested: Int = 10,
    val total: Int = 10,
    val healthyCount: Int = 10,
    val statusText: String = "10 Webshare proxies ready"
)

object ProxyManager {

    val defaultWebshareProxies: List<ProxyNode> = listOf(
        ProxyNode("45.38.107.97", 6014, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("64.137.96.74", 6641, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("198.23.243.226", 6361, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("38.154.185.97", 6370, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("84.247.60.125", 6095, "kcudnecs", "ut4unay8glit", "EU", isHealthy = true),
        ProxyNode("191.96.254.138", 6185, "kcudnecs", "ut4unay8glit", "EU", isHealthy = true),
        ProxyNode("198.46.161.42", 5092, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("64.137.10.153", 5803, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("104.164.49.38", 7693, "kcudnecs", "ut4unay8glit", "US", isHealthy = true),
        ProxyNode("23.26.71.145", 5628, "kcudnecs", "ut4unay8glit", "US", isHealthy = true)
    )

    fun parseBulkProxies(rawText: String): List<ProxyNode> {
        return rawText.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.contains(":") }
            .mapNotNull { line ->
                val cleaned = line
                    .removePrefix("http://")
                    .removePrefix("https://")
                    .trimEnd('/')
                val parts = cleaned.split(":")
                val host = parts.getOrNull(0)?.trim().orEmpty()
                val port = parts.getOrNull(1)?.trim()?.toIntOrNull()
                if (host.isEmpty() || port == null || port !in 1..65535) {
                    return@mapNotNull null
                }
                when (parts.size) {
                    2 -> ProxyNode(host = host, port = port, countryCode = "US", isHealthy = true)
                    4 -> ProxyNode(
                        host = host,
                        port = port,
                        username = parts[2].trim(),
                        password = parts[3].trim(),
                        countryCode = "US",
                        isHealthy = true
                    )
                    else -> null
                }
            }
    }

    /**
     * Async HTTP CONNECT + Proxy-Authorization health check for accurate ms latency.
     */
    suspend fun testProxyHealth(node: ProxyNode): ProxyNode = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        var socket: Socket? = null
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(node.host, node.port), 5000)
            socket.soTimeout = 5000

            val sb = StringBuilder()
            sb.append("CONNECT www.google.com:443 HTTP/1.1\r\n")
            sb.append("Host: www.google.com:443\r\n")
            if (node.hasAuth) {
                val creds = "${node.username}:${node.password}"
                val encoded = Base64.encodeToString(creds.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                sb.append("Proxy-Authorization: Basic $encoded\r\n")
            }
            sb.append("Proxy-Connection: Keep-Alive\r\n\r\n")

            socket.getOutputStream().write(sb.toString().toByteArray(Charsets.UTF_8))
            socket.getOutputStream().flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val statusLine = reader.readLine() ?: ""
            val latency = System.currentTimeMillis() - start
            val ok = statusLine.contains(" 200")
            node.copy(isHealthy = ok, latencyMs = if (ok) latency else -1L)
        } catch (_: Exception) {
            node.copy(isHealthy = false, latencyMs = -1L)
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {}
        }
    }

    suspend fun testProxyPool(
        nodes: List<ProxyNode>,
        onProgress: (ProxyFetchProgress) -> Unit
    ): List<ProxyNode> = withContext(Dispatchers.IO) {
        if (nodes.isEmpty()) {
            withContext(Dispatchers.Main) {
                onProgress(ProxyFetchProgress(0, 0, 0, "No proxies to test"))
            }
            return@withContext emptyList()
        }

        val testedCount = AtomicInteger(0)
        val healthyCount = AtomicInteger(0)

        withContext(Dispatchers.Main) {
            onProgress(ProxyFetchProgress(0, nodes.size, 0, "Testing ${nodes.size} proxies..."))
        }

        val results = coroutineScope {
            nodes.map { node ->
                async(Dispatchers.IO) {
                    val checked = testProxyHealth(node)
                    val t = testedCount.incrementAndGet()
                    val h = if (checked.isHealthy) healthyCount.incrementAndGet() else healthyCount.get()
                    withContext(Dispatchers.Main) {
                        onProgress(
                            ProxyFetchProgress(
                                tested = t,
                                total = nodes.size,
                                healthyCount = h,
                                statusText = "Tested $t/${nodes.size} ($h online)"
                            )
                        )
                    }
                    checked
                }
            }.awaitAll()
        }

        val sorted = results.sortedWith(
            compareByDescending<ProxyNode> { it.isHealthy }
                .thenBy { if (it.latencyMs >= 0) it.latencyMs else Long.MAX_VALUE }
        )
        val online = sorted.count { it.isHealthy }
        withContext(Dispatchers.Main) {
            onProgress(
                ProxyFetchProgress(
                    tested = nodes.size,
                    total = nodes.size,
                    healthyCount = online,
                    statusText = "$online/${nodes.size} proxies online"
                )
            )
        }
        sorted
    }

    fun isProxyOverrideSupported(): Boolean {
        return WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)
    }

    fun applyProxyToWebView(
        node: ProxyNode?,
        executor: Executor,
        onApplied: (Boolean) -> Unit
    ) {
        if (!isProxyOverrideSupported()) {
            onApplied(false)
            return
        }

        if (node == null) {
            ProxyController.getInstance().clearProxyOverride(executor) {
                onApplied(true)
            }
            return
        }

        val config = ProxyConfig.Builder()
            .addProxyRule("http://${node.host}:${node.port}")
            .build()

        ProxyController.getInstance().setProxyOverride(config, executor) {
            onApplied(true)
        }
    }
}
