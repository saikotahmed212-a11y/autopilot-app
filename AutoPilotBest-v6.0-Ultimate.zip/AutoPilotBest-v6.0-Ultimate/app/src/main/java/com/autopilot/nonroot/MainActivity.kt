package com.autopilot.nonroot

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.autopilot.nonroot.engine.AutomationEngineManager
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.engine.ProxyStorage
import com.autopilot.nonroot.model.*
import com.autopilot.nonroot.ui.LiveAutomationDashboard
import com.autopilot.nonroot.ui.StatusPill
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        setContent {
            AutoPilotApp()
        }
    }
}

@Composable
fun AutoPilotApp() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val engineSnapshot by AutomationEngineManager.state.collectAsState()

    var uiState by remember {
        val savedProxies = ProxyStorage.loadProxies(context)
        AutomationEngineManager.updateProxyPool(savedProxies)
        mutableStateOf(
            AppUiState(
                proxyPool = savedProxies,
                proxyProgress = ProxyFetchProgress(
                    tested = savedProxies.size,
                    total = savedProxies.size,
                    healthyCount = savedProxies.count { it.isHealthy },
                    statusText = "${savedProxies.size} proxies loaded"
                )
            )
        )
    }

    LaunchedEffect(Unit) {
        AutomationEngineManager.setGlobalCountersCallbacks(
            onImpression = { uiState = uiState.copy(totalImpressions = uiState.totalImpressions + 1) },
            onVideoView = { uiState = uiState.copy(totalVideoViews = uiState.totalVideoViews + 1) }
        )
    }

    fun testLoadedProxies() {
        if (uiState.isTestingProxies) return
        scope.launch {
            uiState = uiState.copy(isTestingProxies = true)
            val checked = ProxyManager.testProxyPool(uiState.proxyPool) { progress ->
                uiState = uiState.copy(proxyProgress = progress)
            }
            ProxyStorage.saveProxies(context, checked)
            AutomationEngineManager.updateProxyPool(checked)
            uiState = uiState.copy(proxyPool = checked, isTestingProxies = false)
        }
    }

    fun launchAutomation(config: AutomationConfig) {
        AutomationEngineManager.startSession(context, config, uiState.proxyPool)
        uiState = uiState.copy(
            totalAutomationsRun = uiState.totalAutomationsRun + 1,
            showLiveDashboard = true
        )
    }

    AutoPilotTheme(darkTheme = uiState.darkThemeEnabled) {
        if (uiState.showLiveDashboard && engineSnapshot.isRunning) {
            LiveAutomationDashboard(
                snapshot = engineSnapshot,
                onBack = { uiState = uiState.copy(showLiveDashboard = false) },
                onStop = {
                    AutomationEngineManager.stopSession(context, stopService = true)
                    uiState = uiState.copy(showLiveDashboard = false)
                }
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(
                        containerColor = if (uiState.darkThemeEnabled) NavBarDark else Color.White,
                        tonalElevation = 0.dp
                    ) {
                        val tabs = listOf(
                            BottomTab.HOME to Icons.Rounded.Home,
                            BottomTab.AUTOMATIONS to Icons.Rounded.PlayCircle,
                            BottomTab.VPN to Icons.Rounded.Public,
                            BottomTab.PROFILE to Icons.Rounded.Person
                        )
                        tabs.forEach { (tab, icon) ->
                            val selected = uiState.currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { uiState = uiState.copy(currentTab = tab) },
                                icon = { Icon(imageVector = icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 12.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AccentBlueLight,
                                    indicatorColor = AccentBlue,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                    when (uiState.currentTab) {
                        BottomTab.HOME -> HomeScreen(
                            uiState = uiState,
                            engineSnapshot = engineSnapshot,
                            onStartNew = { uiState = uiState.copy(currentTab = BottomTab.AUTOMATIONS) },
                            onOpenLive = { uiState = uiState.copy(showLiveDashboard = true) },
                            onStopActive = {
                                AutomationEngineManager.stopSession(context, stopService = true)
                                uiState = uiState.copy(showLiveDashboard = false)
                            },
                            onAddSchedule = { task -> uiState = uiState.copy(scheduledTasks = uiState.scheduledTasks + task) },
                            onRunScheduled = { task ->
                                launchAutomation(
                                    AutomationConfig(
                                        sessionName = task.label,
                                        urls = parseMultipleSites(task.url),
                                        totalTargetPages = uiState.defaultTargetPages,
                                        tabCount = task.tabs.coerceIn(1, 12),
                                        refreshIntervalSec = uiState.defaultRefreshSec,
                                        scrollIntervalSec = uiState.defaultScrollSec,
                                        deviceSpoofingEnabled = uiState.deviceSpoofingDefault,
                                        runInBackground = true
                                    )
                                )
                            }
                        )

                        BottomTab.AUTOMATIONS -> CreateAutomationScreen(
                            uiState = uiState,
                            onLaunch = { config -> launchAutomation(config) }
                        )

                        BottomTab.VPN -> ProxyPoolScreen(
                            uiState = uiState,
                            onTestProxies = { testLoadedProxies() },
                            onResetDefault = {
                                val defaults = ProxyManager.defaultWebshareProxies
                                ProxyStorage.saveProxies(context, defaults)
                                AutomationEngineManager.updateProxyPool(defaults)
                                uiState = uiState.copy(
                                    proxyPool = defaults,
                                    proxyProgress = ProxyFetchProgress(defaults.size, defaults.size, defaults.size, "${defaults.size} default proxies restored")
                                )
                            },
                            onClearAll = {
                                ProxyStorage.clearProxies(context)
                                AutomationEngineManager.updateProxyPool(emptyList())
                                uiState = uiState.copy(
                                    proxyPool = emptyList(),
                                    proxyProgress = ProxyFetchProgress(0, 0, 0, "All proxies cleared")
                                )
                            },
                            onImportBulk = { parsed, replaceAll ->
                                val updated = if (replaceAll) parsed else (parsed + uiState.proxyPool)
                                ProxyStorage.saveProxies(context, updated)
                                AutomationEngineManager.updateProxyPool(updated)
                                uiState = uiState.copy(
                                    proxyPool = updated,
                                    proxyProgress = ProxyFetchProgress(
                                        tested = 0,
                                        total = updated.size,
                                        healthyCount = updated.count { it.isHealthy },
                                        statusText = "${updated.size} proxies saved"
                                    )
                                )
                            }
                        )

                        BottomTab.PROFILE -> ProfileScreen(
                            uiState = uiState,
                            onNameChange = { uiState = uiState.copy(userName = it) },
                            onEmailChange = { uiState = uiState.copy(userEmail = it) },
                            onToggleTheme = { uiState = uiState.copy(darkThemeEnabled = !uiState.darkThemeEnabled) },
                            onToggleDeviceSpoofing = { uiState = uiState.copy(deviceSpoofingDefault = it) },
                            onDefaultTabsChange = { uiState = uiState.copy(defaultTabs = it) },
                            onDefaultRefreshChange = { uiState = uiState.copy(defaultRefreshSec = it) },
                            onDefaultScrollChange = { uiState = uiState.copy(defaultScrollSec = it) },
                            onRequestIgnoreBatteryOpt = { requestBatteryOptimizationExemption(context) },
                            onClearCache = {
                                AutomationEngineManager.clearCacheNow(context)
                                try {
                                    CookieManager.getInstance().removeSessionCookies(null)
                                    CookieManager.getInstance().removeAllCookies(null)
                                    CookieManager.getInstance().flush()
                                    WebStorage.getInstance().deleteAllData()
                                    context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                                } catch (_: Exception) {}
                                uiState = uiState.copy(cacheMessage = "Deep cache, cookies & storage cleared (0 MB)")
                            }
                        )
                    }
                }
            }
        }
    }
}

private fun requestBatteryOptimizationExemption(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {}
    }
}

@Composable
fun AppLogoBadge(sizeDp: Int = 36) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape((sizeDp / 3.5f).dp))
            .background(Color(0xFF111827)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "AutoPilot Best Logo",
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun HomeScreen(
    uiState: AppUiState,
    engineSnapshot: EngineSnapshot,
    onStartNew: () -> Unit,
    onOpenLive: () -> Unit,
    onStopActive: () -> Unit,
    onAddSchedule: (ScheduledTask) -> Unit,
    onRunScheduled: (ScheduledTask) -> Unit
) {
    var showScheduleDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogoBadge(sizeDp = 38)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("AutoPilot Best", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AccentBlueLight)
                    Text("v6.0 Ultimate • 1–2,000 Mini-Web Engine", fontSize = 11.sp, color = AccentTeal, fontWeight = FontWeight.SemiBold)
                }
            }
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(CardDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = AccentBlueLight)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text("Hello, ${uiState.userName} 👋", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Batch queue up to 2,000 pages, synchronized load timer & auto-skip dead proxies.", fontSize = 13.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onStartNew,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Start New Automation", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
            ) {
                Text("Impressions", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(3.dp))
                Text("${uiState.totalImpressions}", color = SuccessGreen, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
            ) {
                Text("Video Views", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(3.dp))
                Text("${uiState.totalVideoViews}", color = WarningAmber, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
            ) {
                Text("Sessions", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(3.dp))
                Text("${uiState.totalAutomationsRun}", color = AccentBlueLight, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Active Automations", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(10.dp))

        if (!engineSnapshot.isRunning) {
            Box(
                modifier = Modifier.fillMaxWidth().height(104.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text("No active automations", color = TextSecondary, fontSize = 15.sp)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onOpenLive() }
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = engineSnapshot.config?.sessionName ?: "Active Session",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusPill(
                            text = when {
                                engineSnapshot.isPaused -> "Paused"
                                !engineSnapshot.allPagesLoaded -> "Loading ${engineSnapshot.loadedTabsCount}/${engineSnapshot.tabs.size}"
                                else -> "Timer ${engineSnapshot.secondsUntilNextRefresh}s"
                            },
                            isRunning = !engineSnapshot.isPaused && engineSnapshot.allPagesLoaded
                        )
                        IconButton(onClick = onStopActive) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Stop", tint = Color(0xFFF87171))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${engineSnapshot.completedPagesCount}/${engineSnapshot.totalTargetPages}", color = AccentTeal, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Pages", color = TextSecondary, fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${engineSnapshot.tabs.size}", color = AccentBlueLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Mini-Tabs", color = TextSecondary, fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(formatDuration(engineSnapshot.runtimeSeconds), color = AccentBlueLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Runtime", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Scheduled", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            TextButton(onClick = { showScheduleDialog = true }) { Text("+ Add", color = AccentBlueLight, fontWeight = FontWeight.SemiBold) }
        }

        if (uiState.scheduledTasks.isEmpty()) {
            Text("No schedules yet — tap + Add to save a quick launch preset.", color = TextSecondary, fontSize = 13.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                uiState.scheduledTasks.forEach { task ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.label, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("${task.url} • ${task.tabs} mini-tabs • ${task.timeLabel}", color = TextSecondary, fontSize = 12.sp)
                        }
                        Button(onClick = { onRunScheduled(task) }) { Text("Run") }
                    }
                }
            }
        }
    }

    if (showScheduleDialog) {
        var label by rememberSaveable { mutableStateOf("Quick Preset") }
        var url by rememberSaveable { mutableStateOf("https://ipv4.webshare.io") }
        var time by rememberSaveable { mutableStateOf("10:00 AM") }
        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = { Text("Add Scheduled Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Task Name") })
                    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Sites (comma separated)") })
                    OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (url.isNotBlank()) {
                        onAddSchedule(ScheduledTask(label = label, url = url, timeLabel = time, tabs = uiState.defaultTabs))
                    }
                    showScheduleDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showScheduleDialog = false }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAutomationScreen(
    uiState: AppUiState,
    onLaunch: (AutomationConfig) -> Unit
) {
    var sessionName by rememberSaveable { mutableStateOf("Ultimate Batch") }
    var urlInput by rememberSaveable { mutableStateOf("https://ipv4.webshare.io") }
    var quickSiteInput by rememberSaveable { mutableStateOf("") }
    var totalTargetPages by rememberSaveable { mutableFloatStateOf(uiState.defaultTargetPages.toFloat()) }
    var tabs by rememberSaveable { mutableFloatStateOf(uiState.defaultTabs.toFloat()) }
    var refreshSec by rememberSaveable { mutableIntStateOf(uiState.defaultRefreshSec) }
    var scrollSec by rememberSaveable { mutableIntStateOf(uiState.defaultScrollSec) }
    var deviceSpoofingEnabled by rememberSaveable { mutableStateOf(uiState.deviceSpoofingDefault) }
    var randomizeEnabled by rememberSaveable { mutableStateOf(true) }
    var useProxyRotation by rememberSaveable { mutableStateOf(true) }
    var autoSkipDeadProxies by rememberSaveable { mutableStateOf(true) }
    var autoVideoViewEnabled by rememberSaveable { mutableStateOf(true) }
    var muteAutoVideo by rememberSaveable { mutableStateOf(true) }
    var runInBackground by rememberSaveable { mutableStateOf(true) }
    var autoClearCachePerCycle by rememberSaveable { mutableStateOf(true) }
    var autoClickAndBackEnabled by rememberSaveable { mutableStateOf(true) }
    var clickBackWaitSec by rememberSaveable { mutableFloatStateOf(5f) }
    var blockImagesForSpeed by rememberSaveable { mutableStateOf(false) }
    var autoStopOnTargetComplete by rememberSaveable { mutableStateOf(true) }

    var refreshExpanded by remember { mutableStateOf(false) }
    var scrollExpanded by remember { mutableStateOf(false) }

    val refreshOptions = listOf(15, 30, 45, 60, 90, 120)
    val scrollOptions = listOf(5, 8, 10, 15, 20, 30)
    val targetPresets = listOf(10, 50, 200, 500, 1000, 2000)
    val parsedSites = remember(urlInput) { parseMultipleSites(urlInput) }

    fun addQuickSite() {
        val cleaned = quickSiteInput.trim()
        if (cleaned.isNotEmpty()) {
            urlInput = if (urlInput.isBlank()) cleaned else "$urlInput, $cleaned"
            quickSiteInput = ""
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("Create Automation", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(18.dp)
        ) {
            OutlinedTextField(
                value = sessionName,
                onValueChange = { sessionName = it },
                label = { Text("Session Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text("Target URLs (comma or newline separated)") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = quickSiteInput,
                    onValueChange = { quickSiteInput = it },
                    label = { Text("Add another site") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                FilledTonalButton(onClick = { addQuickSite() }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("${parsedSites.size} sites configured", color = AccentBlueLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                parsedSites.forEach { site ->
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(CardDark).padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(site, color = TextPrimary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            // 1 - 2,000 Total Target Web Pages Queue
            Text(
                text = "Total Target Pages: ${totalTargetPages.roundToInt()} (1–2,000)",
                color = AccentTeal,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("1", color = TextSecondary, fontSize = 12.sp)
                Slider(
                    value = totalTargetPages,
                    onValueChange = { totalTargetPages = it },
                    valueRange = 1f..2000f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("2000", color = TextSecondary, fontSize = 12.sp)
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                targetPresets.forEach { preset ->
                    val isSelected = totalTargetPages.roundToInt() == preset
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) AccentTeal else CardDark)
                            .clickable { totalTargetPages = preset.toFloat() }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text("$preset", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            // Mini-Windows per batch (RAM safe 1-12)
            Text("Mini-Windows per Batch: ${tabs.roundToInt()} (Simultaneous)", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Text("Runs small mini-batches simultaneously to handle up to 2,000 pages safely", color = TextSecondary, fontSize = 11.sp)
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("1", color = TextSecondary, fontSize = 13.sp)
                Slider(
                    value = tabs,
                    onValueChange = { tabs = it },
                    valueRange = 1f..12f,
                    steps = 10,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("12", color = TextSecondary, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text("Timer After All Pages Load (seconds)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Text("Countdown starts ONLY after every page in the batch finishes loading", color = SuccessGreen, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(expanded = refreshExpanded, onExpandedChange = { refreshExpanded = !refreshExpanded }) {
                OutlinedTextField(
                    value = "$refreshSec seconds",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = refreshExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                )
                ExposedDropdownMenu(expanded = refreshExpanded, onDismissRequest = { refreshExpanded = false }) {
                    refreshOptions.forEach { opt ->
                        DropdownMenuItem(text = { Text("$opt seconds") }, onClick = { refreshSec = opt; refreshExpanded = false })
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text("Auto Scroll Interval (seconds)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(expanded = scrollExpanded, onExpandedChange = { scrollExpanded = !scrollExpanded }) {
                OutlinedTextField(
                    value = "$scrollSec seconds",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scrollExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                )
                ExposedDropdownMenu(expanded = scrollExpanded, onDismissRequest = { scrollExpanded = false }) {
                    scrollOptions.forEach { opt ->
                        DropdownMenuItem(text = { Text("$opt seconds") }, onClick = { scrollSec = opt; scrollExpanded = false })
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            ToggleRow("Keep Running in Background", "Continues when app is minimized or closed", SuccessGreen, runInBackground) { runInBackground = it }
            ToggleRow("Device Spoofing (Non-Root)", "Rotates Device ID & browser profile", AccentBlueLight, deviceSpoofingEnabled) { deviceSpoofingEnabled = it }
            ToggleRow("Use Proxy Rotation", "Rotates your 10 Webshare proxies sequentially", SuccessGreen, useProxyRotation) { useProxyRotation = it }
            if (useProxyRotation) {
                ToggleRow("Auto-Skip Dead Proxies", "Immediately switches IP if a proxy fails or times out", AccentTeal, autoSkipDeadProxies) { autoSkipDeadProxies = it }
            }
            ToggleRow("Deep Auto Clear Cache (Per Batch)", "Wipes cache, cookies, DOM & recreates WebView", SuccessGreen, autoClearCachePerCycle) { autoClearCachePerCycle = it }
            ToggleRow("Auto Video View", "Auto-plays HTML5 videos on loaded pages", WarningAmber, autoVideoViewEnabled) { autoVideoViewEnabled = it }
            if (autoVideoViewEnabled) {
                ToggleRow("Mute Auto-Played Videos", "Recommended for smooth autoplay", TextSecondary, muteAutoVideo) { muteAutoVideo = it }
            }
            ToggleRow("Auto Click & Back", "Clicks a visible link, waits ${clickBackWaitSec.roundToInt()}s, then goes back", AccentBlueLight, autoClickAndBackEnabled) { autoClickAndBackEnabled = it }
            if (autoClickAndBackEnabled) {
                Column(modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, bottom = 6.dp)) {
                    Text(
                        text = "Back Wait Time: ${clickBackWaitSec.roundToInt()} seconds",
                        color = AccentBlueLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("2s", color = TextSecondary, fontSize = 11.sp)
                        Slider(
                            value = clickBackWaitSec,
                            onValueChange = { clickBackWaitSec = it },
                            valueRange = 2f..60f,
                            modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
                        )
                        Text("60s", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
            ToggleRow("Data & RAM Saver (Block Images)", "Loads mini-batches much faster on mobile data", AccentTeal, blockImagesForSpeed) { blockImagesForSpeed = it }
            ToggleRow("Auto-Stop at Target Pages", "Stops cleanly after ${totalTargetPages.roundToInt()} pages finish", TextSecondary, autoStopOnTargetComplete) { autoStopOnTargetComplete = it }
            ToggleRow("Randomize Intervals (±3s)", "Human-like timing variation", TextSecondary, randomizeEnabled) { randomizeEnabled = it }

            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    onLaunch(
                        AutomationConfig(
                            sessionName = sessionName.ifBlank { "AutoPilot" },
                            urls = parsedSites,
                            totalTargetPages = totalTargetPages.roundToInt().coerceIn(1, 2000),
                            tabCount = tabs.roundToInt().coerceIn(1, 12),
                            refreshIntervalSec = refreshSec,
                            scrollIntervalSec = scrollSec,
                            deviceSpoofingEnabled = deviceSpoofingEnabled,
                            randomizeIntervals = randomizeEnabled,
                            useProxyRotation = useProxyRotation,
                            autoSkipDeadProxies = autoSkipDeadProxies,
                            autoVideoViewEnabled = autoVideoViewEnabled,
                            muteAutoVideo = muteAutoVideo,
                            runInBackground = runInBackground,
                            autoClearCachePerCycle = autoClearCachePerCycle,
                            autoClickAndBackEnabled = autoClickAndBackEnabled,
                            clickBackWaitSec = clickBackWaitSec.roundToInt(),
                            blockImagesForSpeed = blockImagesForSpeed,
                            autoStopOnTargetComplete = autoStopOnTargetComplete
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Live Automation", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    subtitleColor: Color,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = subtitleColor, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun ProxyPoolScreen(
    uiState: AppUiState,
    onTestProxies: () -> Unit,
    onResetDefault: () -> Unit,
    onClearAll: () -> Unit,
    onImportBulk: (List<ProxyNode>, Boolean) -> Unit
) {
    var showBulkDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Proxy Pool", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Row {
                IconButton(onClick = { showBulkDialog = true }) { Icon(Icons.Rounded.Add, contentDescription = "Bulk Paste", tint = AccentBlueLight) }
                IconButton(onClick = onTestProxies) { Icon(Icons.Rounded.Refresh, contentDescription = "Test Proxies", tint = AccentBlueLight) }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(AccentBlue), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Shield, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("${uiState.proxyPool.size} Proxies Saved", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(uiState.proxyProgress.statusText, fontSize = 12.sp, color = SuccessGreen)
            }
            if (uiState.isTestingProxies) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp, color = AccentBlueLight)
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showBulkDialog = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) {
                Text("Bulk Paste", fontSize = 12.sp)
            }
            FilledTonalButton(onClick = onTestProxies, modifier = Modifier.weight(1f), enabled = uiState.proxyPool.isNotEmpty() && !uiState.isTestingProxies) {
                Text("Test", fontSize = 12.sp)
            }
            OutlinedButton(onClick = onResetDefault) {
                Text("Reset", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        uiState.proxyPool.forEach { node ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(node.address, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text(if (node.hasAuth) "${node.countryCode} • ${node.timezoneId} • Auth" else "${node.countryCode} • HTTP", color = TextSecondary, fontSize = 11.sp)
                }
                val statusLabel = when {
                    node.isHealthy && node.latencyMs >= 0 -> "${node.latencyMs} ms"
                    node.isHealthy -> "READY"
                    else -> "OFFLINE"
                }
                Text(
                    text = statusLabel,
                    color = if (node.isHealthy) SuccessGreen else Color(0xFFF87171),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (uiState.proxyPool.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = onClearAll, modifier = Modifier.align(Alignment.End)) {
                Text("Clear All Proxies", color = Color(0xFFF87171), fontSize = 12.sp)
            }
        }
    }

    if (showBulkDialog) {
        var bulkText by rememberSaveable { mutableStateOf("") }
        var replaceAll by rememberSaveable { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showBulkDialog = false },
            title = { Text("Bulk Paste Proxies") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Format: host:port or host:port:username:password", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(value = bulkText, onValueChange = { bulkText = it }, label = { Text("Proxies") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = replaceAll, onCheckedChange = { replaceAll = it })
                        Text("Replace existing list", fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parsed = ProxyManager.parseBulkProxies(bulkText)
                    if (parsed.isNotEmpty()) onImportBulk(parsed, replaceAll)
                    showBulkDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBulkDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ProfileScreen(
    uiState: AppUiState,
    onNameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onToggleTheme: () -> Unit,
    onToggleDeviceSpoofing: (Boolean) -> Unit,
    onDefaultTabsChange: (Int) -> Unit,
    onDefaultRefreshChange: (Int) -> Unit,
    onDefaultScrollChange: (Int) -> Unit,
    onRequestIgnoreBatteryOpt: () -> Unit,
    onClearCache: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Profile", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        AppLogoBadge(sizeDp = 76)
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(value = uiState.userName, onValueChange = onNameChange, label = { Text("Display Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = uiState.userEmail, onValueChange = onEmailChange, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onToggleTheme() }.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Theme", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Text(if (uiState.darkThemeEnabled) "Dark" else "Light", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text("Default Preferences", color = AccentBlueLight, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Column(modifier = Modifier.fillMaxWidth()) {
            Text("Default Mini-Tabs per Batch: ${uiState.defaultTabs}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultTabs.toFloat(), onValueChange = { onDefaultTabsChange(it.roundToInt()) }, valueRange = 1f..12f, steps = 10)
            Text("Default Refresh Interval (sec): ${uiState.defaultRefreshSec}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultRefreshSec.toFloat(), onValueChange = { onDefaultRefreshChange(it.roundToInt()) }, valueRange = 15f..120f, steps = 9)
            Text("Default Scroll Interval (sec): ${uiState.defaultScrollSec}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultScrollSec.toFloat(), onValueChange = { onDefaultScrollChange(it.roundToInt()) }, valueRange = 5f..30f, steps = 4)
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text("Root & Device", color = AccentBlueLight, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Security, contentDescription = null, tint = AccentBlueLight)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Root Status", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text("Non-Root mode active (no Magisk needed)", color = TextSecondary, fontSize = 11.sp)
                }
            }
            Box(
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEF3C7)).padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text("Non-Root", color = Color(0xFF92400E), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = SuccessGreen)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Device Spoofing", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text("Non-Root WebView ID & Profile rotation", color = SuccessGreen, fontSize = 11.sp)
                }
            }
            Switch(checked = uiState.deviceSpoofingDefault, onCheckedChange = onToggleDeviceSpoofing)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onRequestIgnoreBatteryOpt() }.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, tint = WarningAmber)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Background Battery Mode", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text("Allow unrestricted background running", color = TextSecondary, fontSize = 11.sp)
                }
            }
            Text("Allow", color = AccentBlueLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.CleaningServices, contentDescription = null, tint = TextSecondary)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text(uiState.cacheMessage ?: "Deep WebView cache & cookies", color = TextSecondary, fontSize = 11.sp)
                }
            }
            TextButton(onClick = onClearCache) { Text("Clear", color = AccentBlueLight, fontWeight = FontWeight.Bold) }
        }
    }
}
