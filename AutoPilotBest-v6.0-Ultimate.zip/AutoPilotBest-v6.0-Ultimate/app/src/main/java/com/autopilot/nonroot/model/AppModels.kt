package com.autopilot.nonroot.model

import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyNode
import java.util.UUID

enum class BottomTab(val label: String) {
    HOME("Home"),
    AUTOMATIONS("Automations"),
    VPN("Proxies"),
    PROFILE("Profile")
}

fun parseMultipleSites(rawInput: String): List<String> {
    return rawInput
        .split(",", "\n", ";")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
        .ifEmpty { listOf("https://ipv4.webshare.io") }
}

fun formatDuration(totalSeconds: Int): String {
    val hrs = totalSeconds / 3600
    val mins = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    return String.format("%02d:%02d:%02d", hrs, mins, secs)
}

data class ActivityLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timeLabel: String,
    val tag: String, // Scroll, Info, Profile, Proxy, Video, Cache, Click, Back, Timer, Pause
    val message: String
)

data class TabStatus(
    val index: Int,
    val pageNumberInQueue: Int = 1,
    val url: String,
    val isRunning: Boolean = true,
    val isLoaded: Boolean = false,
    val scrollCount: Int = 0,
    val lastAction: String = "Loading..."
)

data class AutomationConfig(
    val id: String = UUID.randomUUID().toString(),
    val sessionName: String = "AutoPilot Ultimate",
    val urls: List<String>,
    val totalTargetPages: Int = 100, // 1 to 2000 target mini-pages
    val tabCount: Int = 4, // 1 to 12 concurrent mini-windows per batch
    val refreshIntervalSec: Int = 30,
    val scrollIntervalSec: Int = 8,
    val deviceSpoofingEnabled: Boolean = true,
    val randomizeIntervals: Boolean = true,
    val useProxyRotation: Boolean = true,
    val autoSkipDeadProxies: Boolean = true,
    val autoVideoViewEnabled: Boolean = true,
    val muteAutoVideo: Boolean = true,
    val runInBackground: Boolean = true,
    val autoClearCachePerCycle: Boolean = true,
    val autoClickAndBackEnabled: Boolean = true,
    val clickBackWaitSec: Int = 5,
    val blockImagesForSpeed: Boolean = false,
    val autoStopOnTargetComplete: Boolean = true
)

data class ScheduledTask(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val url: String,
    val timeLabel: String,
    val tabs: Int
)

data class EngineSnapshot(
    val config: AutomationConfig? = null,
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isCompleted: Boolean = false,
    val activeTabIndex: Int = 0,
    val tabs: List<TabStatus> = emptyList(),
    val currentDevice: DeviceProfile = DeviceProfileEngine.getRandomProfile(),
    val spoofedDeviceId: String = "N/A (spoofing disabled)",
    val currentProxy: ProxyNode? = null,
    val proxyStatusLabel: String = "Disabled",
    val proxyCountryLabel: String = "N/A",
    val proxyTimezoneLabel: String = "System Local",
    val skippedDeadProxiesCount: Int = 0,
    val refreshCount: Int = 0,
    val scrollCount: Int = 0,
    val runtimeSeconds: Int = 0,
    val allPagesLoaded: Boolean = false,
    val loadedTabsCount: Int = 0,
    val batchLoadElapsedSec: Int = 0,
    val secondsUntilNextRefresh: Int = 30,
    val completedPagesCount: Int = 0,
    val totalTargetPages: Int = 100,
    val currentBatchNumber: Int = 1,
    val totalBatches: Int = 25,
    val sessionImpressions: Int = 0,
    val sessionVideoViews: Int = 0,
    val cacheClearCount: Int = 0,
    val webViewGeneration: Int = 0,
    val liveStatusMessage: String = "Idle",
    val lastUpdatedLabel: String = "--:--:--",
    val manualVerificationNeeded: Boolean = false,
    val logs: List<ActivityLogEntry> = emptyList()
)

data class AppUiState(
    val currentTab: BottomTab = BottomTab.HOME,
    val userName: String = "Expert",
    val userEmail: String = "autopilot.best@local",
    val totalAutomationsRun: Int = 0,
    val totalImpressions: Int = 0,
    val totalVideoViews: Int = 0,
    val defaultTabs: Int = 4,
    val defaultTargetPages: Int = 100,
    val defaultRefreshSec: Int = 30,
    val defaultScrollSec: Int = 8,
    val deviceSpoofingDefault: Boolean = true,
    val darkThemeEnabled: Boolean = true,
    val proxyPool: List<ProxyNode> = emptyList(),
    val isTestingProxies: Boolean = false,
    val proxyProgress: ProxyFetchProgress = ProxyFetchProgress(),
    val showLiveDashboard: Boolean = false,
    val scheduledTasks: List<ScheduledTask> = emptyList(),
    val cacheMessage: String? = null
)
