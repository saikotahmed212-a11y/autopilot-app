package com.autopilot.nonroot.ui

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.autopilot.nonroot.engine.AutomationEngineManager
import com.autopilot.nonroot.model.ActivityLogEntry
import com.autopilot.nonroot.model.EngineSnapshot
import com.autopilot.nonroot.model.formatDuration
import com.autopilot.nonroot.ui.theme.*

private enum class ViewerMode { STATS, MINI_GRID, FULL_WEB }

@Composable
fun LiveAutomationDashboard(
    snapshot: EngineSnapshot,
    onBack: () -> Unit,
    onStop: () -> Unit
) {
    val context = LocalContext.current
    var viewMode by remember { mutableStateOf(ViewerMode.STATS) }

    BackHandler {
        if (viewMode != ViewerMode.STATS) {
            viewMode = ViewerMode.STATS
        } else {
            onBack()
        }
    }

    val config = snapshot.config
    val sessionTitle = config?.sessionName?.ifBlank { "AutoPilot" } ?: "AutoPilot"

    Scaffold(
        containerColor = BgDark,
        topBar = {
            Surface(color = SurfaceDark, tonalElevation = 2.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconButton(onClick = {
                                if (viewMode != ViewerMode.STATS) viewMode = ViewerMode.STATS else onBack()
                            }) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                            }
                            Text(
                                text = sessionTitle,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusPill(
                                text = when {
                                    snapshot.isPaused -> "Paused"
                                    !snapshot.allPagesLoaded -> "Loading ${snapshot.loadedTabsCount}/${snapshot.tabs.size}"
                                    else -> "Timer ${snapshot.secondsUntilNextRefresh}s"
                                },
                                isRunning = !snapshot.isPaused && snapshot.allPagesLoaded
                            )
                        }

                        IconButton(onClick = { AutomationEngineManager.clearCacheNow(context) }) {
                            Icon(Icons.Rounded.CleaningServices, contentDescription = "Clear Cache", tint = SuccessGreen, modifier = Modifier.size(20.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // 3-Mode Switcher: Stats | Mini-Grid | Full WebView
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModeChip(
                            label = "Stats",
                            icon = Icons.Rounded.Dashboard,
                            selected = viewMode == ViewerMode.STATS,
                            onClick = { viewMode = ViewerMode.STATS },
                            modifier = Modifier.weight(1f)
                        )
                        ModeChip(
                            label = "Mini-Grid (${snapshot.tabs.size})",
                            icon = Icons.Rounded.GridView,
                            selected = viewMode == ViewerMode.MINI_GRID,
                            onClick = { viewMode = ViewerMode.MINI_GRID },
                            modifier = Modifier.weight(1f)
                        )
                        ModeChip(
                            label = "Full Web",
                            icon = Icons.Rounded.Web,
                            selected = viewMode == ViewerMode.FULL_WEB,
                            onClick = { viewMode = ViewerMode.FULL_WEB },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        bottomBar = {
            Surface(color = NavBarDark, tonalElevation = 6.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(vertical = 10.dp, horizontal = 28.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(WarningAmber)
                            .clickable { AutomationEngineManager.togglePause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (snapshot.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            contentDescription = "Pause/Resume",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DangerRed)
                            .clickable { onStop() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Stop,
                            contentDescription = "Stop",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(AccentBlue)
                            .clickable { AutomationEngineManager.addNewTab() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add Mini-Tab",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (snapshot.manualVerificationNeeded) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF451A03))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Site requires manual verification",
                            color = Color(0xFFFEF3C7),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    TextButton(onClick = {
                        viewMode = ViewerMode.FULL_WEB
                        AutomationEngineManager.resumeFromVerification()
                    }) {
                        Text("Open / Resume", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            when (viewMode) {
                ViewerMode.STATS -> RealtimeDashboardPane(
                    snapshot = snapshot,
                    onOpenTabWebView = { tabIndex ->
                        AutomationEngineManager.selectTab(tabIndex)
                        viewMode = ViewerMode.FULL_WEB
                    }
                )
                ViewerMode.MINI_GRID -> MiniGridWebViewPane(
                    snapshot = snapshot,
                    onExpandTab = { tabIndex ->
                        AutomationEngineManager.selectTab(tabIndex)
                        viewMode = ViewerMode.FULL_WEB
                    }
                )
                ViewerMode.FULL_WEB -> LiveWebViewPane(snapshot = snapshot)
            }
        }
    }
}

@Composable
private fun ModeChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) AccentBlue else CardDark)
            .clickable { onClick() }
            .padding(vertical = 7.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(5.dp))
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun MiniGridWebViewPane(
    snapshot: EngineSnapshot,
    onExpandTab: (Int) -> Unit
) {
    val chunked = snapshot.tabs.chunked(2)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mini-Grid Batch Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CardDark)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mini-Grid • Batch ${snapshot.currentBatchNumber}/${snapshot.totalBatches}",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = if (snapshot.allPagesLoaded) {
                        "All ${snapshot.tabs.size} loaded • Rotating in ${snapshot.secondsUntilNextRefresh}s"
                    } else {
                        "Waiting for all pages (${snapshot.loadedTabsCount}/${snapshot.tabs.size}) before timer starts"
                    },
                    color = if (snapshot.allPagesLoaded) SuccessGreen else WarningAmber,
                    fontSize = 11.sp
                )
            }
            if (!snapshot.allPagesLoaded) {
                TextButton(onClick = { AutomationEngineManager.forceStartTimerNow() }) {
                    Text("Start Timer", color = AccentBlueLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        chunked.forEach { rowTabs ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowTabs.forEach { tab ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardDark)
                            .border(
                                width = 1.dp,
                                color = if (tab.isLoaded) SuccessGreen.copy(alpha = 0.5f) else WarningAmber.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(14.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceDark)
                                .clickable { onExpandTab(tab.index) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(if (tab.isLoaded) SuccessGreen else WarningAmber)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "#${tab.pageNumberInQueue} (T${tab.index + 1})",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.OpenInFull,
                                contentDescription = "Expand",
                                tint = AccentBlueLight,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        Box(modifier = Modifier.fillMaxWidth().height(185.dp)) {
                            key(tab.index, snapshot.webViewGeneration) {
                                AndroidView(
                                    modifier = Modifier.fillMaxSize(),
                                    factory = { ctx ->
                                        val wv = AutomationEngineManager.getOrCreateWebView(ctx, tab.index)
                                        (wv.parent as? ViewGroup)?.removeView(wv)
                                        wv
                                    },
                                    onRelease = { wv ->
                                        (wv.parent as? ViewGroup)?.removeView(wv)
                                    }
                                )
                            }
                        }
                    }
                }
                if (rowTabs.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
    }
}

@Composable
private fun RealtimeDashboardPane(
    snapshot: EngineSnapshot,
    onOpenTabWebView: (Int) -> Unit
) {
    val spoofingActive = snapshot.config?.deviceSpoofingEnabled == true
    val proxyActive = snapshot.currentProxy != null
    val progress = if (snapshot.totalTargetPages > 0) {
        (snapshot.completedPagesCount.toFloat() / snapshot.totalTargetPages.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Queue Progress Card (1-2000 Target Pages)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .border(1.dp, BorderMuted, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Queue: ${snapshot.completedPagesCount} / ${snapshot.totalTargetPages} Pages",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Batch ${snapshot.currentBatchNumber}/${snapshot.totalBatches}",
                    color = AccentBlueLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp)),
                color = AccentTeal,
                trackColor = SurfaceDark
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (snapshot.allPagesLoaded) {
                        "All ${snapshot.tabs.size} loaded • Rotate in ${snapshot.secondsUntilNextRefresh}s"
                    } else {
                        "Waiting for load: ${snapshot.loadedTabsCount}/${snapshot.tabs.size} (Timer paused)"
                    },
                    color = if (snapshot.allPagesLoaded) SuccessGreen else WarningAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (!snapshot.allPagesLoaded) {
                    Text(
                        text = "Force Start",
                        color = AccentBlueLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { AutomationEngineManager.forceStartTimerNow() }
                    )
                } else {
                    Text(
                        text = "Cleared: ${snapshot.cacheClearCount}x",
                        color = AccentTeal,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Live Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Live Status (Realtime)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = snapshot.liveStatusMessage,
                    color = AccentBlueLight,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text("Updated: ${snapshot.lastUpdatedLabel}", color = TextSecondary, fontSize = 11.sp)
        }

        // 3x2 Main Stats Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(title = "Active Mini-Tabs", value = "${snapshot.tabs.size}", modifier = Modifier.weight(1f))
            MetricCard(title = "Refresh Count", value = "${snapshot.refreshCount}", modifier = Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(title = "Scroll Count", value = "${snapshot.scrollCount}", modifier = Modifier.weight(1f))
            MetricCard(title = "Runtime", value = formatDuration(snapshot.runtimeSeconds), modifier = Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(title = "Impressions", value = "${snapshot.sessionImpressions}", valueColor = SuccessGreen, modifier = Modifier.weight(1f))
            MetricCard(title = "Video Views", value = "${snapshot.sessionVideoViews}", valueColor = WarningAmber, modifier = Modifier.weight(1f))
        }

        // Current Device ID (Spoofed) Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Current Device ID (Spoofed)", color = TextSecondary, fontSize = 12.sp)
                TextButton(
                    onClick = { AutomationEngineManager.rotateNow(triggeredByDeadProxy = false) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = AccentBlueLight, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Next Batch", color = AccentBlueLight, fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Fingerprint,
                    contentDescription = null,
                    tint = if (spoofingActive) SuccessGreen else AccentBlueLight,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = snapshot.spoofedDeviceId,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = snapshot.currentDevice.name,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 2x2 Status Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoStatusCard(
                label = "Dead Proxies Skipped",
                value = "${snapshot.skippedDeadProxiesCount} skipped",
                dotColor = if (snapshot.skippedDeadProxiesCount > 0) WarningAmber else SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            InfoStatusCard(
                label = "Spoofing",
                value = if (spoofingActive) "Active (Non-Root)" else "Disabled",
                dotColor = if (spoofingActive) SuccessGreen else TextSecondary,
                modifier = Modifier.weight(1f)
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoStatusCard(
                label = "Proxy",
                value = snapshot.proxyStatusLabel,
                dotColor = if (proxyActive) SuccessGreen else TextSecondary,
                modifier = Modifier.weight(1f)
            )
            InfoStatusCard(
                label = "Country & Timezone",
                value = "${snapshot.proxyCountryLabel} • ${snapshot.proxyTimezoneLabel}",
                dotColor = if (proxyActive) AccentBlueLight else TextSecondary,
                modifier = Modifier.weight(1f)
            )
        }

        // Activity Log Card
        Text("Activity Log", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (snapshot.logs.isEmpty()) {
                Text("Waiting for activity...", color = TextSecondary, fontSize = 13.sp)
            } else {
                snapshot.logs.take(15).forEach { entry ->
                    ActivityLogRow(entry)
                }
            }
        }

        // Tabs Overview Grid
        Text("Mini-Tabs Overview", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        val chunkedTabs = snapshot.tabs.chunked(2)
        chunkedTabs.forEach { rowTabs ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowTabs.forEach { tab ->
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFEAF2FF))
                            .clickable { onOpenTabWebView(tab.index) }
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Tab ${tab.index + 1}",
                                color = Color(0xFF1E293B),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Page #${tab.pageNumberInQueue}",
                                color = Color(0xFF475569),
                                fontSize = 10.sp
                            )
                        }
                        StatusPill(
                            text = when {
                                snapshot.isPaused -> "Paused"
                                tab.isLoaded -> "Loaded"
                                else -> "Loading"
                            },
                            isRunning = !snapshot.isPaused && tab.isLoaded
                        )
                    }
                }
                if (rowTabs.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        Button(
            onClick = { AutomationEngineManager.addNewTab() },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Add Mini-Tab to Batch", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun LiveWebViewPane(snapshot: EngineSnapshot) {
    val activeIdx = snapshot.activeTabIndex.coerceIn(0, (snapshot.tabs.size - 1).coerceAtLeast(0))

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceDark)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            snapshot.tabs.forEach { tab ->
                val selected = tab.index == activeIdx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (selected) AccentBlue else CardDark)
                        .clickable { AutomationEngineManager.selectTab(tab.index) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Tab ${tab.index + 1} (#${tab.pageNumberInQueue})",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (snapshot.tabs.isNotEmpty()) {
                key(activeIdx, snapshot.webViewGeneration) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            val wv = AutomationEngineManager.getOrCreateWebView(ctx, activeIdx)
                            (wv.parent as? ViewGroup)?.removeView(wv)
                            wv
                        },
                        onRelease = { wv ->
                            (wv.parent as? ViewGroup)?.removeView(wv)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatusPill(text: String, isRunning: Boolean) {
    val bg = if (isRunning) SuccessPillBg else Color(0xFFFEF3C7)
    val fg = if (isRunning) SuccessPillText else Color(0xFF92400E)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (isRunning) SuccessGreen else WarningAmber)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(text = text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    valueColor: Color = TextPrimary,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .padding(vertical = 15.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = value, color = valueColor, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = title, color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun InfoStatusCard(
    label: String,
    value: String,
    dotColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .padding(14.dp)
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(dotColor))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ActivityLogRow(entry: ActivityLogEntry) {
    val badgeBg = when (entry.tag) {
        "Scroll" -> Color(0xFF1D4ED8)
        "Profile" -> Color(0xFF047857)
        "Proxy" -> Color(0xFF6D28D9)
        "Video" -> Color(0xFFB45309)
        "Cache" -> Color(0xFF0F766E)
        "Click" -> Color(0xFFBE185D)
        "Back" -> Color(0xFF4338CA)
        "Timer" -> Color(0xFF0284C7)
        "Pause" -> Color(0xFF9A3412)
        else -> Color(0xFF334155)
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = entry.timeLabel, color = TextSecondary, fontSize = 11.sp, modifier = Modifier.width(58.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(badgeBg)
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(text = entry.tag, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = entry.message,
            color = TextPrimary,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}
