package com.autopilot.nonroot.engine

import android.annotation.SuppressLint
import android.content.Context
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.autopilot.nonroot.model.ActivityLogEntry
import com.autopilot.nonroot.model.AutomationConfig
import com.autopilot.nonroot.model.EngineSnapshot
import com.autopilot.nonroot.model.TabStatus
import com.autopilot.nonroot.model.formatDuration
import com.autopilot.nonroot.service.AutomationForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil
import kotlin.random.Random

/**
 * Persistent v6.0 Ultimate Background Engine:
 * - Processes 1 to 2,000 target mini-pages in safe concurrent batches (1-12 mini WebViews at once)
 * - Synchronized Timer: Countdown NEVER starts until ALL tabs in the current batch finish loading
 * - Dead Proxy Auto-Skip: Skips offline proxies and auto-fails over on WebView proxy/network errors
 * - 5-Layer Deep Auto Clear Cache & Fresh WebView Recreation per batch
 * - Auto Scroll, Auto Video View, Auto Click & Back (custom timer), Non-Root Device Spoofing
 */
object AutomationEngineManager {

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(EngineSnapshot())
    val state: StateFlow<EngineSnapshot> = _state.asStateFlow()

    private var appContext: Context? = null
    private var proxyPool: MutableList<ProxyNode> = mutableListOf()
    private val runtimeDeadProxies = mutableSetOf<String>()
    private var proxyIndex: Int = 0
    private var runtimeJob: Job? = null
    private var scrollJob: Job? = null

    private val webViews = mutableMapOf<Int, WebView>()
    private val loadedTabsInBatch = mutableSetOf<Int>()
    private val videoCountedPerTab = mutableSetOf<Int>()
    private var proxyFailoverInProgress = false
    private var currentBatchErrorCount = 0

    private var totalImpressionsCallback: (() -> Unit)? = null
    private var totalVideoViewsCallback: (() -> Unit)? = null

    private const val MAX_BATCH_LOAD_WAIT_SEC = 35

    fun setGlobalCountersCallbacks(
        onImpression: () -> Unit,
        onVideoView: () -> Unit
    ) {
        totalImpressionsCallback = onImpression
        totalVideoViewsCallback = onVideoView
    }

    fun updateProxyPool(proxies: List<ProxyNode>) {
        proxyPool = proxies.toMutableList()
        runtimeDeadProxies.clear()
    }

    fun getOrCreateWebView(context: Context, tabIndex: Int): WebView {
        val ctx = appContext ?: context.applicationContext
        return webViews.getOrPut(tabIndex) {
            createConfiguredWebView(ctx, tabIndex)
        }
    }

    private fun pickNextHealthyProxy(skipDead: Boolean): ProxyNode? {
        if (proxyPool.isEmpty()) return null
        val healthyCandidates = if (skipDead) {
            proxyPool.filter { it.isHealthy && it.address !in runtimeDeadProxies }
        } else {
            proxyPool
        }
        val activePool = if (healthyCandidates.isNotEmpty()) {
            healthyCandidates
        } else {
            // Reset runtime dead set if all proxies failed once so we can retry cleanly
            runtimeDeadProxies.clear()
            proxyPool
        }
        val picked = activePool[proxyIndex % activePool.size]
        proxyIndex = (proxyIndex + 1) % activePool.size
        return picked
    }

    fun startSession(
        context: Context,
        config: AutomationConfig,
        proxies: List<ProxyNode>
    ) {
        stopSession(context, stopService = false)

        appContext = context.applicationContext
        proxyPool = proxies.toMutableList()
        runtimeDeadProxies.clear()
        proxyIndex = 0
        loadedTabsInBatch.clear()
        videoCountedPerTab.clear()
        proxyFailoverInProgress = false
        currentBatchErrorCount = 0

        val totalPages = config.totalTargetPages.coerceIn(1, 2000)
        val batchSize = config.tabCount.coerceIn(1, 12).coerceAtMost(totalPages)
        val totalBatches = ceil(totalPages.toDouble() / batchSize.toDouble()).toInt().coerceAtLeast(1)

        val initialDevice = DeviceProfileEngine.getRandomProfile()
        val spoofId = if (config.deviceSpoofingEnabled) {
            DeviceProfileEngine.generateNonRootDeviceId(initialDevice)
        } else {
            "N/A (spoofing disabled)"
        }

        val initialProxy = if (config.useProxyRotation) {
            pickNextHealthyProxy(config.autoSkipDeadProxies)
        } else {
            null
        }

        val initialTabs = (0 until batchSize).map { idx ->
            TabStatus(
                index = idx,
                pageNumberInQueue = idx + 1,
                url = normalizeUrl(config.urls[idx % config.urls.size]),
                isRunning = true,
                isLoaded = false,
                scrollCount = 0,
                lastAction = "Loading..."
            )
        }

        _state.value = EngineSnapshot(
            config = config,
            isRunning = true,
            isPaused = false,
            isCompleted = false,
            activeTabIndex = 0,
            tabs = initialTabs,
            currentDevice = initialDevice,
            spoofedDeviceId = spoofId,
            currentProxy = initialProxy,
            proxyStatusLabel = initialProxy?.address ?: "Disabled",
            proxyCountryLabel = initialProxy?.countryCode ?: "N/A",
            proxyTimezoneLabel = initialProxy?.timezoneId ?: TimeZone.getDefault().id,
            skippedDeadProxiesCount = 0,
            refreshCount = 0,
            scrollCount = 0,
            runtimeSeconds = 0,
            allPagesLoaded = false,
            loadedTabsCount = 0,
            batchLoadElapsedSec = 0,
            secondsUntilNextRefresh = config.refreshIntervalSec.coerceAtLeast(5),
            completedPagesCount = 0,
            totalTargetPages = totalPages,
            currentBatchNumber = 1,
            totalBatches = totalBatches,
            sessionImpressions = 0,
            sessionVideoViews = 0,
            cacheClearCount = 0,
            webViewGeneration = 0,
            liveStatusMessage = "Loading Batch 1/$totalBatches (0/$batchSize loaded)...",
            lastUpdatedLabel = currentTimeFull(),
            manualVerificationNeeded = false,
            logs = emptyList()
        )

        addLog("Info", "Started: $totalPages target pages ($batchSize mini-tabs/batch)")
        if (config.deviceSpoofingEnabled) {
            addLog("Profile", "Non-Root ID: $spoofId (${initialDevice.name})")
        }

        if (config.runInBackground) {
            AutomationForegroundService.start(
                context,
                "Loading Batch 1/$totalBatches • 0/$totalPages pages"
            )
        }

        val executor = ContextCompat.getMainExecutor(context.applicationContext)
        val proceedStart = {
            ProxyManager.applyProxyToWebView(initialProxy, executor) { applied ->
                if (initialProxy != null) {
                    addLog(
                        "Proxy",
                        if (applied) {
                            "Connected: ${initialProxy.address} (${initialProxy.countryCode} • ${initialProxy.timezoneId})"
                        } else {
                            "Direct mode (proxy override unsupported)"
                        }
                    )
                }
                initialTabs.forEach { tab ->
                    val wv = getOrCreateWebView(context.applicationContext, tab.index)
                    applyDeviceProfileToWebView(
                        wv,
                        initialDevice,
                        config.autoVideoViewEnabled,
                        config.autoClearCachePerCycle,
                        config.blockImagesForSpeed
                    )
                    loadTabUrl(wv, tab.url, initialDevice, initialProxy, config.autoClearCachePerCycle)
                }
                addLog("Timer", "Waiting for all $batchSize pages to load before starting timer...")
                startLoops()
            }
        }

        if (config.autoClearCachePerCycle) {
            clearAllWebViewCacheAndCookies(recreateViews = true) { proceedStart() }
        } else {
            proceedStart()
        }
    }

    fun forceStartTimerNow() {
        val s = _state.value
        if (!s.isRunning || s.allPagesLoaded) return
        _state.update {
            it.copy(
                allPagesLoaded = true,
                liveStatusMessage = "Timer started manually (${it.secondsUntilNextRefresh}s)",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Timer", "Timer started manually (${s.loadedTabsCount}/${s.tabs.size} loaded)")
    }

    fun togglePause() {
        val current = _state.value
        if (!current.isRunning) return
        val nextPaused = !current.isPaused
        _state.update {
            it.copy(
                isPaused = nextPaused,
                liveStatusMessage = if (nextPaused) "Paused by user" else "Resumed automation",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Pause", if (nextPaused) "Session paused" else "Session resumed")
        updateNotification()
    }

    fun selectTab(index: Int) {
        val current = _state.value
        if (index in current.tabs.indices) {
            _state.update { it.copy(activeTabIndex = index) }
        }
    }

    fun addNewTab() {
        val ctx = appContext ?: return
        val current = _state.value
        val cfg = current.config ?: return
        if (current.tabs.size >= 12) {
            addLog("Info", "Max 12 simultaneous mini-tabs per batch (for RAM safety)")
            return
        }
        val newIdx = current.tabs.size
        val nextPageNum = (current.completedPagesCount + newIdx + 1).coerceAtMost(current.totalTargetPages)
        val url = normalizeUrl(cfg.urls[(nextPageNum - 1) % cfg.urls.size])
        val newTab = TabStatus(
            index = newIdx,
            pageNumberInQueue = nextPageNum,
            url = url,
            isRunning = true,
            isLoaded = false,
            lastAction = "Loading..."
        )
        val updatedTabs = current.tabs + newTab
        _state.update {
            it.copy(
                tabs = updatedTabs,
                liveStatusMessage = "Added Mini-Tab ${newIdx + 1}",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        val wv = getOrCreateWebView(ctx, newIdx)
        applyDeviceProfileToWebView(
            wv,
            current.currentDevice,
            cfg.autoVideoViewEnabled,
            cfg.autoClearCachePerCycle,
            cfg.blockImagesForSpeed
        )
        loadTabUrl(wv, url, current.currentDevice, current.currentProxy, cfg.autoClearCachePerCycle)
        addLog("Info", "Mini-Tab ${newIdx + 1} added (Page #$nextPageNum)")
        updateNotification()
    }

    fun resumeFromVerification() {
        _state.update {
            it.copy(
                manualVerificationNeeded = false,
                liveStatusMessage = "Resumed after verification",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Info", "Manual verification cleared")
    }

    fun rotateNow(triggeredByDeadProxy: Boolean = false) {
        val ctx = appContext ?: return
        val current = _state.value
        val cfg = current.config ?: return
        if (!current.isRunning) return

        // Update batch completion counter if this was a normal cycle finish
        val newCompletedCount = if (!triggeredByDeadProxy) {
            (current.completedPagesCount + current.tabs.size).coerceAtMost(current.totalTargetPages)
        } else {
            current.completedPagesCount
        }

        // Check if 1-2000 target queue finished
        if (!triggeredByDeadProxy && cfg.autoStopOnTargetComplete && newCompletedCount >= current.totalTargetPages) {
            _state.update {
                it.copy(
                    completedPagesCount = newCompletedCount,
                    isCompleted = true,
                    liveStatusMessage = "Completed all ${current.totalTargetPages} pages!",
                    lastUpdatedLabel = currentTimeFull()
                )
            }
            addLog("Info", "Target reached: $newCompletedCount/${current.totalTargetPages} pages done!")
            stopSession(ctx, stopService = true)
            return
        }

        val remainingPages = if (cfg.autoStopOnTargetComplete) {
            (current.totalTargetPages - newCompletedCount).coerceAtLeast(1)
        } else {
            cfg.tabCount.coerceIn(1, 12)
        }
        val nextBatchSize = cfg.tabCount.coerceIn(1, 12).coerceAtMost(remainingPages)
        val nextBatchNum = if (!triggeredByDeadProxy) {
            val nextB = current.currentBatchNumber + 1
            if (nextB > current.totalBatches && !cfg.autoStopOnTargetComplete) 1 else nextB.coerceAtMost(current.totalBatches)
        } else {
            current.currentBatchNumber
        }

        val nextDevice = if (cfg.deviceSpoofingEnabled) {
            DeviceProfileEngine.pickRandom(current.currentDevice.name)
        } else {
            current.currentDevice
        }
        val nextSpoofId = if (cfg.deviceSpoofingEnabled) {
            DeviceProfileEngine.generateNonRootDeviceId(nextDevice)
        } else {
            "N/A (spoofing disabled)"
        }

        val nextProxy = if (cfg.useProxyRotation) {
            pickNextHealthyProxy(cfg.autoSkipDeadProxies)
        } else {
            null
        }

        val nextRefreshSec = if (cfg.randomizeIntervals) {
            (cfg.refreshIntervalSec + Random.nextInt(-3, 4)).coerceAtLeast(5)
        } else {
            cfg.refreshIntervalSec.coerceAtLeast(5)
        }

        val nextTabs = (0 until nextBatchSize).map { idx ->
            val pageNum = newCompletedCount + idx + 1
            TabStatus(
                index = idx,
                pageNumberInQueue = pageNum,
                url = normalizeUrl(cfg.urls[(pageNum - 1) % cfg.urls.size]),
                isRunning = true,
                isLoaded = false,
                scrollCount = 0,
                lastAction = "Loading..."
            )
        }

        loadedTabsInBatch.clear()
        videoCountedPerTab.clear()
        currentBatchErrorCount = 0
        proxyFailoverInProgress = false

        val executor = ContextCompat.getMainExecutor(ctx)
        val proceedRotation = {
            ProxyManager.applyProxyToWebView(nextProxy, executor) { _ ->
                _state.update { s ->
                    s.copy(
                        tabs = nextTabs,
                        activeTabIndex = 0,
                        currentDevice = nextDevice,
                        spoofedDeviceId = nextSpoofId,
                        currentProxy = nextProxy,
                        proxyStatusLabel = nextProxy?.address ?: "Disabled",
                        proxyCountryLabel = nextProxy?.countryCode ?: "N/A",
                        proxyTimezoneLabel = nextProxy?.timezoneId ?: TimeZone.getDefault().id,
                        refreshCount = if (triggeredByDeadProxy) s.refreshCount else s.refreshCount + 1,
                        completedPagesCount = newCompletedCount,
                        currentBatchNumber = nextBatchNum,
                        allPagesLoaded = false,
                        loadedTabsCount = 0,
                        batchLoadElapsedSec = 0,
                        secondsUntilNextRefresh = nextRefreshSec,
                        liveStatusMessage = "Loading Batch $nextBatchNum/${s.totalBatches} (0/$nextBatchSize loaded)...",
                        lastUpdatedLabel = currentTimeFull()
                    )
                }

                if (cfg.deviceSpoofingEnabled) {
                    addLog("Profile", "Rotated ID: $nextSpoofId (${nextDevice.name})")
                }
                if (nextProxy != null) {
                    addLog("Proxy", "Switched IP: ${nextProxy.address} (${nextProxy.countryCode} • ${nextProxy.timezoneId})")
                }
                addLog("Timer", "Batch $nextBatchNum loading — timer paused until all $nextBatchSize pages finish")

                // Freshly load all mini-tabs in this batch
                nextTabs.forEach { tab ->
                    val wv = getOrCreateWebView(ctx, tab.index)
                    applyDeviceProfileToWebView(
                        wv,
                        nextDevice,
                        cfg.autoVideoViewEnabled,
                        cfg.autoClearCachePerCycle,
                        cfg.blockImagesForSpeed
                    )
                    loadTabUrl(wv, tab.url, nextDevice, nextProxy, cfg.autoClearCachePerCycle)
                }
                updateNotification()
            }
        }

        if (cfg.autoClearCachePerCycle) {
            clearAllWebViewCacheAndCookies(recreateViews = true) { proceedRotation() }
        } else {
            proceedRotation()
        }
    }

    fun stopSession(context: Context? = null, stopService: Boolean = true) {
        runtimeJob?.cancel()
        scrollJob?.cancel()
        runtimeJob = null
        scrollJob = null

        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) {
            val executor = ContextCompat.getMainExecutor(ctx)
            ProxyManager.applyProxyToWebView(null, executor) {}
            if (stopService) {
                AutomationForegroundService.stop(ctx)
            }
        }

        webViews.values.forEach { wv ->
            try {
                wv.stopLoading()
                wv.loadUrl("about:blank")
                wv.clearHistory()
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.destroy()
            } catch (_: Exception) {}
        }
        webViews.clear()
        loadedTabsInBatch.clear()
        videoCountedPerTab.clear()
        proxyFailoverInProgress = false

        _state.value = EngineSnapshot()
    }

    private fun startLoops() {
        runtimeJob?.cancel()
        scrollJob?.cancel()

        // 1-second loop: Timer ONLY counts down AFTER allPagesLoaded == true!
        runtimeJob = engineScope.launch {
            while (isActive) {
                delay(1000L)
                val s = _state.value
                if (!s.isRunning) break
                if (s.isPaused || s.manualVerificationNeeded) continue

                val newRuntime = s.runtimeSeconds + 1

                if (!s.allPagesLoaded) {
                    val waitSec = s.batchLoadElapsedSec + 1
                    if (waitSec >= MAX_BATCH_LOAD_WAIT_SEC) {
                        // Safety anti-hang fallback if 1 site never fires onPageFinished
                        _state.update {
                            it.copy(
                                runtimeSeconds = newRuntime,
                                batchLoadElapsedSec = waitSec,
                                allPagesLoaded = true,
                                liveStatusMessage = "Load timeout (${MAX_BATCH_LOAD_WAIT_SEC}s) • Timer started",
                                lastUpdatedLabel = currentTimeFull()
                            )
                        }
                        addLog("Timer", "Fallback timer start (${s.loadedTabsCount}/${s.tabs.size} loaded after ${MAX_BATCH_LOAD_WAIT_SEC}s)")
                    } else {
                        _state.update {
                            it.copy(
                                runtimeSeconds = newRuntime,
                                batchLoadElapsedSec = waitSec
                            )
                        }
                    }
                } else {
                    if (s.secondsUntilNextRefresh > 1) {
                        _state.update {
                            it.copy(
                                runtimeSeconds = newRuntime,
                                secondsUntilNextRefresh = it.secondsUntilNextRefresh - 1
                            )
                        }
                    } else {
                        _state.update { it.copy(runtimeSeconds = newRuntime) }
                        rotateNow(triggeredByDeadProxy = false)
                    }
                }

                if (newRuntime % 3 == 0) {
                    updateNotification()
                }
            }
        }

        // Scroll, Video & Auto Click-Back loop (waits until allPagesLoaded == true)
        scrollJob = engineScope.launch {
            while (isActive) {
                val cfg = _state.value.config ?: break
                val jitter = if (cfg.randomizeIntervals) Random.nextLong(-2000L, 2000L) else 0L
                delay((cfg.scrollIntervalSec * 1000L + jitter).coerceAtLeast(2500L))

                val s = _state.value
                if (!s.isRunning) break
                if (s.isPaused || s.manualVerificationNeeded || !s.allPagesLoaded || s.tabs.isEmpty()) continue

                val tabIdx = s.scrollCount % s.tabs.size
                val wv = webViews[tabIdx] ?: continue

                if (cfg.autoVideoViewEnabled) {
                    triggerAutoVideo(wv, cfg.muteAutoVideo) { playing ->
                        if (playing) {
                            if (videoCountedPerTab.add(tabIdx)) {
                                _state.update { cur ->
                                    cur.copy(
                                        sessionVideoViews = cur.sessionVideoViews + 1,
                                        liveStatusMessage = "Tab ${tabIdx + 1}: Video playing",
                                        lastUpdatedLabel = currentTimeFull()
                                    )
                                }
                                totalVideoViewsCallback?.invoke()
                                addLog("Video", "Tab ${tabIdx + 1}: Auto-playing video")
                            }
                        } else if (cfg.autoClickAndBackEnabled && s.scrollCount > 0 && s.scrollCount % 3 == 0) {
                            performAutoClickAndBack(wv, tabIdx)
                        } else {
                            performHumanScroll(wv, tabIdx)
                        }
                    }
                } else if (cfg.autoClickAndBackEnabled && s.scrollCount > 0 && s.scrollCount % 3 == 0) {
                    performAutoClickAndBack(wv, tabIdx)
                } else {
                    performHumanScroll(wv, tabIdx)
                }
            }
        }
    }

    private fun handlePossibleDeadProxyError(tabIndex: Int, errorCode: Int) {
        val s = _state.value
        val cfg = s.config ?: return
        val activeProxy = s.currentProxy ?: return
        if (!cfg.useProxyRotation || !cfg.autoSkipDeadProxies || proxyFailoverInProgress) return

        val isProxyFailure = errorCode == WebViewClient.ERROR_PROXY_AUTHENTICATION ||
            errorCode == WebViewClient.ERROR_CONNECT ||
            errorCode == WebViewClient.ERROR_HOST_LOOKUP ||
            errorCode == WebViewClient.ERROR_TIMEOUT ||
            errorCode == WebViewClient.ERROR_IO

        if (!isProxyFailure) return

        currentBatchErrorCount += 1
        // If at least 1 tab fails with a proxy/connection error on a dead proxy, auto-skip!
        if (currentBatchErrorCount >= 1) {
            proxyFailoverInProgress = true
            runtimeDeadProxies.add(activeProxy.address)
            proxyPool = proxyPool.map {
                if (it.address == activeProxy.address) it.copy(isHealthy = false, latencyMs = -1L) else it
            }.toMutableList()

            _state.update { cur ->
                cur.copy(
                    skippedDeadProxiesCount = cur.skippedDeadProxiesCount + 1,
                    liveStatusMessage = "Dead proxy ${activeProxy.address} skipped — switching IP...",
                    lastUpdatedLabel = currentTimeFull()
                )
            }
            addLog("Proxy", "Auto-skipped dead proxy ${activeProxy.address} (Tab ${tabIndex + 1} err $errorCode)")

            engineScope.launch {
                delay(800L)
                if (_state.value.isRunning) {
                    rotateNow(triggeredByDeadProxy = true)
                }
            }
        }
    }

    private fun markTabLoaded(tabIndex: Int) {
        val current = _state.value
        if (!current.isRunning) return
        if (tabIndex !in current.tabs.indices) return

        loadedTabsInBatch.add(tabIndex)
        val totalInBatch = current.tabs.size
        val loadedCount = loadedTabsInBatch.size
        val allDoneNow = !current.allPagesLoaded && loadedCount >= totalInBatch

        _state.update { cur ->
            val updatedTabs = cur.tabs.map { t ->
                if (t.index == tabIndex) t.copy(isLoaded = true, lastAction = "Loaded") else t
            }
            cur.copy(
                tabs = updatedTabs,
                loadedTabsCount = loadedCount,
                allPagesLoaded = cur.allPagesLoaded || allDoneNow,
                liveStatusMessage = if (allDoneNow) {
                    "All $totalInBatch pages loaded • Timer started (${cur.secondsUntilNextRefresh}s)"
                } else if (!cur.allPagesLoaded) {
                    "Loading Batch ${cur.currentBatchNumber}/${cur.totalBatches} ($loadedCount/$totalInBatch loaded)..."
                } else {
                    cur.liveStatusMessage
                },
                lastUpdatedLabel = currentTimeFull()
            )
        }

        if (allDoneNow) {
            addLog("Timer", "All $totalInBatch pages loaded — countdown timer started!")
            updateNotification()
        }
    }

    private fun performAutoClickAndBack(wv: WebView, tabIdx: Int) {
        val jsClick = """
            (function() {
                const links = Array.from(document.querySelectorAll('a[href]')).filter(a => {
                    const href = (a.getAttribute('href') || '').trim();
                    if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
                    const rect = a.getBoundingClientRect();
                    return rect.width > 10 && rect.height > 10 && a.offsetParent !== null;
                });
                if (links.length === 0) return 'NO_LINK';
                const target = links[Math.floor(Math.random() * Math.min(links.length, 12))];
                const label = (target.innerText || target.getAttribute('href') || 'link').trim().substring(0, 32);
                try {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.removeAttribute('target');
                    target.click();
                    return 'CLICKED:' + label;
                } catch (e) {
                    return 'ERROR';
                }
            })();
        """.trimIndent()

        wv.evaluateJavascript(jsClick) { raw ->
            val res = raw?.trim('"') ?: ""
            if (res.startsWith("CLICKED:")) {
                val label = res.removePrefix("CLICKED:").ifBlank { "link" }
                _state.update { s ->
                    val updatedTabs = s.tabs.map { t ->
                        if (t.index == tabIdx) t.copy(scrollCount = t.scrollCount + 1, lastAction = "Clicked: $label") else t
                    }
                    s.copy(
                        tabs = updatedTabs,
                        scrollCount = s.scrollCount + 1,
                        liveStatusMessage = "Tab ${tabIdx + 1}: Clicked '$label'",
                        lastUpdatedLabel = currentTimeFull()
                    )
                }
                addLog("Click", "Tab ${tabIdx + 1}: Clicked $label")

                val cfgNow = _state.value.config
                val baseWaitSec = (cfgNow?.clickBackWaitSec ?: 5).coerceIn(2, 60)
                val jitterMs = if (cfgNow?.randomizeIntervals == true) Random.nextLong(-1000L, 1500L) else 0L
                val backDelayMs = (baseWaitSec * 1000L + jitterMs).coerceAtLeast(1000L)
                wv.postDelayed({
                    val cur = _state.value
                    if (!cur.isRunning || cur.isPaused) return@postDelayed
                    if (wv.canGoBack()) {
                        wv.goBack()
                        _state.update { s ->
                            s.copy(
                                liveStatusMessage = "Tab ${tabIdx + 1}: Navigated back",
                                lastUpdatedLabel = currentTimeFull()
                            )
                        }
                        addLog("Back", "Tab ${tabIdx + 1}: Returned back")
                    } else {
                        val origUrl = cur.tabs.getOrNull(tabIdx)?.url
                        if (origUrl != null) {
                            loadTabUrl(wv, origUrl, cur.currentDevice, cur.currentProxy)
                            addLog("Back", "Tab ${tabIdx + 1}: Returned to main page")
                        }
                    }
                }, backDelayMs)
            } else {
                performHumanScroll(wv, tabIdx)
            }
        }
    }

    private fun performHumanScroll(wv: WebView, tabIdx: Int) {
        val scrollBack = Random.nextInt(100) < 22
        val px = if (scrollBack) -Random.nextInt(90, 220) else Random.nextInt(220, 480)
        wv.evaluateJavascript("window.scrollBy({ top: $px, behavior: 'smooth' });", null)

        val actionText = if (scrollBack) {
            "Tab ${tabIdx + 1}: Scrolled back ${-px}px"
        } else {
            "Tab ${tabIdx + 1}: Scrolled down ${px}px"
        }
        val shortAction = if (scrollBack) "Scrolled back ${-px}px" else "Scrolled ${px}px down"

        _state.update { s ->
            val updatedTabs = s.tabs.map { t ->
                if (t.index == tabIdx) t.copy(scrollCount = t.scrollCount + 1, lastAction = shortAction) else t
            }
            s.copy(
                tabs = updatedTabs,
                scrollCount = s.scrollCount + 1,
                liveStatusMessage = actionText,
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Scroll", shortAction)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createConfiguredWebView(context: Context, tabIndex: Int): WebView {
        val s = _state.value
        val cfg = s.config
        val wv = WebView(context)
        applyDeviceProfileToWebView(
            wv,
            s.currentDevice,
            cfg?.autoVideoViewEnabled ?: false,
            cfg?.autoClearCachePerCycle ?: true,
            cfg?.blockImagesForSpeed ?: false
        )
        wv.webChromeClient = WebChromeClient()

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                super.onPageFinished(view, loadedUrl)
                if (loadedUrl == null || loadedUrl == "about:blank") return
                val current = _state.value
                if (!current.isRunning) return

                _state.update { cur ->
                    cur.copy(
                        sessionImpressions = cur.sessionImpressions + 1,
                        lastUpdatedLabel = currentTimeFull()
                    )
                }
                totalImpressionsCallback?.invoke()

                // Track synchronized batch load completion
                markTabLoaded(tabIndex)

                if (view != null) {
                    checkManualChallenge(view) { detected ->
                        if (detected) {
                            _state.update { cur ->
                                cur.copy(
                                    manualVerificationNeeded = true,
                                    liveStatusMessage = "Tab ${tabIndex + 1}: Manual verification needed",
                                    lastUpdatedLabel = currentTimeFull()
                                )
                            }
                            addLog("Pause", "Manual verification detected on Tab ${tabIndex + 1}")
                        } else if (current.config?.autoVideoViewEnabled == true) {
                            view.postDelayed({
                                triggerAutoVideo(view, current.config.muteAutoVideo) { playing ->
                                    if (playing && videoCountedPerTab.add(tabIndex)) {
                                        _state.update { cur ->
                                            cur.copy(
                                                sessionVideoViews = cur.sessionVideoViews + 1,
                                                liveStatusMessage = "Tab ${tabIndex + 1}: Video playing",
                                                lastUpdatedLabel = currentTimeFull()
                                            )
                                        }
                                        totalVideoViewsCallback?.invoke()
                                        addLog("Video", "Tab ${tabIndex + 1}: Video started")
                                    }
                                }
                            }, 1400L)
                        }
                    }
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true && error != null) {
                    handlePossibleDeadProxyError(tabIndex, error.errorCode)
                    // Still mark tab settled so batch never deadlocks if direct mode fails
                    if (_state.value.currentProxy == null) {
                        markTabLoaded(tabIndex)
                    }
                }
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView?,
                handler: HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                val proxy = _state.value.currentProxy
                if (proxy != null && proxy.hasAuth) {
                    handler?.proceed(proxy.username, proxy.password)
                } else {
                    super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }
            }
        }
        return wv
    }

    fun clearCacheNow(context: Context? = null) {
        if (context != null && appContext == null) {
            appContext = context.applicationContext
        }
        clearAllWebViewCacheAndCookies(recreateViews = false) {
            _state.update { s ->
                s.copy(
                    liveStatusMessage = "Deep cache & cookies cleared",
                    lastUpdatedLabel = currentTimeFull()
                )
            }
        }
    }

    private fun purgeDiskWebViewCache(ctx: Context) {
        engineScope.launch(Dispatchers.IO) {
            try {
                ctx.cacheDir?.listFiles()?.forEach { it.deleteRecursively() }
                val dataDir = ctx.applicationInfo?.dataDir?.let { File(it) }
                if (dataDir != null) {
                    val cacheFolders = listOf(
                        File(dataDir, "app_webview/Cache"),
                        File(dataDir, "app_webview/Default/Cache"),
                        File(dataDir, "app_webview/Default/Code Cache"),
                        File(dataDir, "app_webview/Default/GPUCache"),
                        File(dataDir, "app_webview/Default/Service Worker/CacheStorage"),
                        File(dataDir, "app_webview/Default/Session Storage"),
                        File(dataDir, "app_webview/Default/Local Storage")
                    )
                    cacheFolders.forEach { folder ->
                        if (folder.exists()) {
                            folder.deleteRecursively()
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun clearAllWebViewCacheAndCookies(
        recreateViews: Boolean = true,
        onCleared: () -> Unit
    ) {
        val ctx = appContext
        try {
            val clearJs = """
                (function() {
                    try { localStorage.clear(); } catch (e) {}
                    try { sessionStorage.clear(); } catch (e) {}
                    try {
                        if (window.caches && caches.keys) {
                            caches.keys().then(function(keys) {
                                keys.forEach(function(k) { caches.delete(k); });
                            });
                        }
                    } catch (e) {}
                })();
            """.trimIndent()

            webViews.values.forEach { wv ->
                try {
                    wv.evaluateJavascript(clearJs, null)
                    wv.stopLoading()
                    wv.clearCache(true)
                    wv.clearHistory()
                    wv.clearFormData()
                    wv.loadUrl("about:blank")
                } catch (_: Exception) {}
            }

            if (recreateViews && webViews.isNotEmpty()) {
                webViews.values.forEach { wv ->
                    try {
                        (wv.parent as? ViewGroup)?.removeView(wv)
                        wv.destroy()
                    } catch (_: Exception) {}
                }
                webViews.clear()
            }

            WebStorage.getInstance().deleteAllData()
            val cm = CookieManager.getInstance()
            cm.removeSessionCookies(null)
            cm.removeAllCookies {
                try {
                    cm.flush()
                } catch (_: Exception) {}
                if (ctx != null) {
                    purgeDiskWebViewCache(ctx)
                }
                _state.update { s ->
                    s.copy(
                        cacheClearCount = s.cacheClearCount + 1,
                        webViewGeneration = if (recreateViews) s.webViewGeneration + 1 else s.webViewGeneration
                    )
                }
                addLog("Cache", "Deep cleared cache, cookies, DOM & disk storage")
                onCleared()
            }
        } catch (_: Exception) {
            onCleared()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applyDeviceProfileToWebView(
        webView: WebView,
        profile: DeviceProfile,
        allowAutoplay: Boolean,
        noCacheMode: Boolean = true,
        blockImages: Boolean = false
    ) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            loadsImagesAutomatically = !blockImages
            blockNetworkImage = blockImages
            cacheMode = if (noCacheMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = !allowAutoplay
            userAgentString = DeviceProfileEngine.sanitizeUserAgent(profile.userAgent)
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(webView.settings, emptySet())
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
    }

    private fun loadTabUrl(
        webView: WebView,
        url: String,
        profile: DeviceProfile,
        proxy: ProxyNode?,
        noCacheHeaders: Boolean = _state.value.config?.autoClearCachePerCycle ?: true
    ) {
        val headers = mutableMapOf(
            "Accept-Language" to (proxy?.acceptLanguage ?: profile.acceptLanguage)
        )
        if (noCacheHeaders) {
            headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            headers["Pragma"] = "no-cache"
        }
        webView.loadUrl(url, headers)
    }

    private fun checkManualChallenge(webView: WebView, onResult: (Boolean) -> Unit) {
        val jsCheck = """
            (function() {
                const title = (document.title || '').toLowerCase();
                const text = (document.body ? document.body.innerText : '').toLowerCase();
                const hasChallengeFrame = document.querySelector(
                    'iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"]'
                ) !== null;
                const hasChallengeText = title.includes('just a moment')
                    || title.includes('attention required')
                    || text.includes('verify you are human')
                    || text.includes('checking your browser');
                return (hasChallengeFrame || hasChallengeText) ? 'CHALLENGE' : 'OK';
            })();
        """.trimIndent()
        webView.evaluateJavascript(jsCheck) { result ->
            onResult(result?.contains("CHALLENGE") == true)
        }
    }

    private fun triggerAutoVideo(webView: WebView, muteVideo: Boolean, onResult: (Boolean) -> Unit) {
        val muteFlag = if (muteVideo) "true" else "false"
        val jsPlay = """
            (function() {
                const videos = Array.from(document.querySelectorAll('video'));
                if (videos.length === 0) return 'NO_VIDEO';
                const target = videos.find(v => v.offsetWidth > 0 && v.offsetHeight > 0) || videos[0];
                try {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.playsInline = true;
                    if ($muteFlag) target.muted = true;
                    if (target.paused) {
                        const p = target.play();
                        if (p && typeof p.catch === 'function') p.catch(function() {});
                        return 'STARTED';
                    }
                    return 'PLAYING';
                } catch (e) {
                    return 'ERROR';
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(jsPlay) { result ->
            onResult(result?.contains("STARTED") == true || result?.contains("PLAYING") == true)
        }
    }

    private fun addLog(tag: String, message: String) {
        val entry = ActivityLogEntry(
            timeLabel = currentTimeShort(),
            tag = tag,
            message = message
        )
        _state.update { s ->
            val updated = (listOf(entry) + s.logs).take(60)
            s.copy(logs = updated)
        }
    }

    private fun updateNotification() {
        val ctx = appContext ?: return
        val s = _state.value
        if (s.isRunning && s.config?.runInBackground == true) {
            val stateWord = when {
                s.isPaused -> "Paused"
                !s.allPagesLoaded -> "Loading ${s.loadedTabsCount}/${s.tabs.size}"
                else -> "Timer ${s.secondsUntilNextRefresh}s"
            }
            AutomationForegroundService.updateStatus(
                ctx,
                "$stateWord • Batch ${s.currentBatchNumber}/${s.totalBatches} • ${s.completedPagesCount}/${s.totalTargetPages} pages"
            )
        }
    }

    private fun activeTimeZone(): TimeZone {
        val tzId = _state.value.currentProxy?.timezoneId
        return if (!tzId.isNullOrBlank()) TimeZone.getTimeZone(tzId) else TimeZone.getDefault()
    }

    private fun currentTimeFull(): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.US)
        sdf.timeZone = activeTimeZone()
        return sdf.format(Date())
    }

    private fun currentTimeShort(): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.US)
        sdf.timeZone = activeTimeZone()
        return sdf.format(Date())
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://ipv4.webshare.io"
            else -> "https://$trimmed"
        }
    }
}
