package com.autopilot.nonroot.engine

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ProxyStorage {

    private const val PREFS_NAME = "autopilot_best_v6_prefs"
    private const val KEY_PROXIES = "saved_proxies_json"
    private const val KEY_INITIALIZED = "proxies_initialized"

    fun saveProxies(context: Context, proxies: List<ProxyNode>) {
        val jsonArray = JSONArray()
        for (node in proxies) {
            val obj = JSONObject().apply {
                put("host", node.host)
                put("port", node.port)
                put("username", node.username ?: "")
                put("password", node.password ?: "")
                put("countryCode", node.countryCode)
                put("isHealthy", node.isHealthy)
                put("latencyMs", node.latencyMs)
            }
            jsonArray.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROXIES, jsonArray.toString())
            .putBoolean(KEY_INITIALIZED, true)
            .apply()
    }

    fun loadProxies(context: Context): List<ProxyNode> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val initialized = prefs.getBoolean(KEY_INITIALIZED, false)
        if (!initialized) {
            val defaults = ProxyManager.defaultWebshareProxies
            saveProxies(context, defaults)
            return defaults
        }

        val raw = prefs.getString(KEY_PROXIES, null) ?: return emptyList()
        return try {
            val jsonArray = JSONArray(raw)
            val result = mutableListOf<ProxyNode>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val host = obj.optString("host", "").trim()
                val port = obj.optInt("port", -1)
                if (host.isNotEmpty() && port in 1..65535) {
                    val user = obj.optString("username", "").takeIf { it.isNotEmpty() }
                    val pass = obj.optString("password", "").takeIf { it.isNotEmpty() }
                    val country = obj.optString("countryCode", "US").ifBlank { "US" }
                    val healthy = obj.optBoolean("isHealthy", true)
                    val latency = obj.optLong("latencyMs", -1L)
                    result.add(
                        ProxyNode(
                            host = host,
                            port = port,
                            username = user,
                            password = pass,
                            countryCode = country,
                            isHealthy = healthy,
                            latencyMs = latency
                        )
                    )
                }
            }
            result
        } catch (_: Exception) {
            ProxyManager.defaultWebshareProxies
        }
    }

    fun clearProxies(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROXIES, "[]")
            .putBoolean(KEY_INITIALIZED, true)
            .apply()
    }
}
