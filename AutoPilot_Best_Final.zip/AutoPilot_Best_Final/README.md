# AutoPilot Best (v4.1.0)

- App name updated to **AutoPilot Best** with a redesigned futuristic emerald, gold & dark-violet delta emblem logo.
- Includes all previous updates:
  - Stealth WebView (`; wv` removal, `Accept-Language` header, proxy auth)
  - Cloudflare challenge detection & auto-pause
  - Device profile & proxy rotation (`ProxyManager` + `DeviceProfileEngine`)
  - Background & screen-off foreground service (`AutomationForegroundService` + `PARTIAL_WAKE_LOCK`)
  - Live impressions counter (Home, Active card, Live Viewer, and Notification)
  - Multi-site input & tab cycling

- Integrated `CloudflareChallengeHandler` in `com.autopilot.nonroot.engine` with safe async JS evaluation and UI-thread auto-pause/reload handling.
- Added `WebChromeClient` and an interactive challenge-paused UI feedback banner with manual Resume control inside `LiveAutomationViewer`.
