package com.autopilot.nonroot.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0E1319)
val SurfaceDark = Color(0xFF171D26)
val CardDark = Color(0xFF1C232E)
val NavBarDark = Color(0xFF141A22)
val AccentBlue = Color(0xFF1E64C8)
val AccentBlueLight = Color(0xFF8AB4F8)
val AccentTeal = Color(0xFF1B5E57)
val SuccessGreen = Color(0xFF22C55E)
val SuccessBg = Color(0xFF132A20)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFF991B1B)
val TextPrimary = Color(0xFFF3F6FA)
val TextSecondary = Color(0xFF9BA5B4)
val BorderMuted = Color(0xFF2D3746)

private val DarkColors = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    secondary = AccentBlueLight,
    background = BgDark,
    surface = SurfaceDark,
    surfaceVariant = CardDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = BorderMuted
)

private val LightColors = lightColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    secondary = AccentTeal,
    background = Color(0xFFF5F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFEBF0F7),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun AutoPilotTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
