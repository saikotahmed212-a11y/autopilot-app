package com.autopilot.nonroot.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.autopilot.nonroot.engine.CloudflareChallengeHandler
import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.model.LiveRunnerState
import com.autopilot.nonroot.service.AutomationForegroundService
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

@SuppressLint("SetJavaScriptEnabled")
fun configureStealthWebView(webView: WebView, userAgent: String) {
    webView.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        userAgentString = DeviceProfileEngine.sanitizeUserAgent(userAgent)
    }

    if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
        WebSettingsCompat.setRequestedWithHeaderOriginAllowList(
            webView.settings,
            emptySet()
        )
    }

    CookieManager.getInstance().apply {
        setAcceptCookie(true)
        setAcceptThirdPartyCookies(webView, true)
    }
}

fun checkCloudflareChallenge(webView: WebView, url: String = "", onResult: (Boolean) -> Unit) {
    CloudflareChallengeHandler.checkAndHandle(url, webView, onResult)
}

@Composable
fun AutomationWebView(
    url: String,
    profile: DeviceProfile,
    refreshIntervalSec: Int,
    scrollIntervalSec: Int,
    randomizeIntervals: Boolean,
    proxyUser: String? = null,
    proxyPass: String? = null,
    onPageLoaded: () -> Unit = {},
    onChallengeDetected: (Boolean) -> Unit
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isPausedForChallenge by remember { mutableStateOf(false) }

    LaunchedEffect(webViewRef, scrollIntervalSec, isPausedForChallenge) {
        while (true) {
            val jitter = if (randomizeIntervals) Random.nextLong(-2000L, 2000L) else 0L
            delay((scrollIntervalSec * 1000L + jitter).coerceAtLeast(2000L))

            webViewRef?.let { wv ->
                checkCloudflareChallenge(wv, url) { detected ->
                    isPausedForChallenge = detected
                    onChallengeDetected(detected)

                    if (!detected) {
                        wv.evaluateJavascript(
                            "window.scrollBy({ top: 300, behavior: 'smooth' });",
                            null
                        )
                    }
                }
            }
        }
    }

    LaunchedEffect(webViewRef, refreshIntervalSec, isPausedForChallenge) {
        while (true) {
            val jitter = if (randomizeIntervals) Random.nextLong(-3000L, 3000L) else 0L
            delay((refreshIntervalSec * 1000L + jitter).coerceAtLeast(5000L))

            if (!isPausedForChallenge) {
                webViewRef?.reload()
            }
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                configureStealthWebView(this, profile.userAgent)
                webChromeClient = WebChromeClient()

                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                        super.onPageFinished(view, loadedUrl)
                        if (view != null) {
                            CloudflareChallengeHandler.checkAndHandle(loadedUrl ?: url, view) { detected ->
                                isPausedForChallenge = detected
                                onChallengeDetected(detected)
                            }
                        }
                        onPageLoaded()
                    }

                    override fun onReceivedHttpAuthRequest(
                        view: WebView?,
                        handler: HttpAuthHandler?,
                        host: String?,
                        realm: String?
                    ) {
                        if (!proxyUser.isNullOrEmpty() && !proxyPass.isNullOrEmpty()) {
                            handler?.proceed(proxyUser, proxyPass)
                        } else {
                            super.onReceivedHttpAuthRequest(view, handler, host, realm)
                        }
                    }
                }

                loadUrl(url, mapOf("Accept-Language" to profile.acceptLanguage))
                webViewRef = this
            }
        }
    )
}

@Composable
fun LiveAutomationViewer(
    runner: LiveRunnerState,
    proxyPool: List<ProxyNode>,
    onMinimize: () -> Unit,
    onStop: () -> Unit,
    onUpdateRunner: (LiveRunnerState) -> Unit,
    onDeviceRotated: () -> Unit,
    onImpressionRecorded: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }
    val config = runner.config
    val siteList = remember(config.urls) {
        config.urls.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("https://www.google.com") }
    }
    val tabCount = config.tabCount.coerceIn(1, 15)

    var selectedTab by remember(config.id) { mutableIntStateOf(runner.activeTabIndex) }
    var activeDevice by remember(config.id) { mutableStateOf(runner.currentDevice) }
    var proxyIndex by remember(config.id) { mutableIntStateOf(0) }
    var currentProxy by remember(config.id) { mutableStateOf(runner.currentProxy) }
    var proxyLabel by remember(config.id) { mutableStateOf(runner.currentProxyLabel) }
    var rotationCount by remember(config.id) { mutableIntStateOf(runner.rotationCount) }
    var sessionImpressions by remember(config.id) { mutableIntStateOf(runner.sessionImpressions) }
    var challengePaused by remember(config.id) { mutableStateOf(false) }
    var cycleKey by remember(config.id) { mutableIntStateOf(0) }

    BackHandler { onMinimize() }

    DisposableEffect(lifecycleOwner, config.id, config.runInBackground) {
        val observer = LifecycleEventObserver { _, event ->
            if (!config.runInBackground) return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_PAUSE -> {
                    AutomationForegroundService.start(
                        context,
                        "Impr: $sessionImpressions • ${activeDevice.name} • $proxyLabel"
                    )
                }
                Lifecycle.Event.ON_RESUME -> {
                    AutomationForegroundService.updateStatus(
                        context,
                        "Impr: $sessionImpressions • ${activeDevice.name} • $proxyLabel"
                    )
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://www.google.com"
            else -> "https://$trimmed"
        }
    }

    fun urlForTab(idx: Int): String {
        return normalizeUrl(siteList[idx % siteList.size])
    }

    fun recordImpression() {
        sessionImpressions += 1
        onImpressionRecorded()
        onUpdateRunner(
            runner.copy(
                currentDevice = activeDevice,
                currentProxy = currentProxy,
                currentProxyLabel = proxyLabel,
                activeTabIndex = selectedTab,
                rotationCount = rotationCount,
                sessionImpressions = sessionImpressions,
                lastStatus = "Impr: $sessionImpressions (${siteList.size} sites)"
            )
        )
        if (config.runInBackground) {
            AutomationForegroundService.updateStatus(
                context,
                "Impr: $sessionImpressions • ${activeDevice.name} • $proxyLabel"
            )
        }
    }

    fun rotateNow() {
        val nextDev = if (config.deviceRotationEnabled) {
            DeviceProfileEngine.pickRandom(activeDevice.name)
        } else {
            activeDevice
        }
        activeDevice = nextDev
        rotationCount += 1
        onDeviceRotated()

        val node = if (config.useProxyRotation && proxyPool.isNotEmpty()) {
            val picked = proxyPool[proxyIndex % proxyPool.size]
            proxyIndex = (proxyIndex + 1) % proxyPool.size
            picked
        } else {
            null
        }
        currentProxy = node

        ProxyManager.applyProxyToWebView(
            node = node,
            directFallback = config.autoFallbackDirect,
            executor = mainExecutor
        ) {
            proxyLabel = if (node != null) "${node.address} (${node.countryCode})" else "Direct"
            cycleKey += 1
            onUpdateRunner(
                runner.copy(
                    currentDevice = nextDev,
                    currentProxy = node,
                    currentProxyLabel = proxyLabel,
                    activeTabIndex = selectedTab,
                    rotationCount = rotationCount,
                    sessionImpressions = sessionImpressions,
                    lastStatus = if (challengePaused) "Paused (Challenge)" else "Impr: $sessionImpressions"
                )
            )
        }
    }

    DisposableEffect(config.id) {
        val initialNode = if (config.useProxyRotation && proxyPool.isNotEmpty()) {
            val picked = proxyPool[0]
            proxyIndex = 1
            picked
        } else {
            null
        }
        currentProxy = initialNode

        ProxyManager.applyProxyToWebView(
            node = initialNode,
            directFallback = config.autoFallbackDirect,
            executor = mainExecutor
        ) {
            proxyLabel = if (initialNode != null) "${initialNode.address} (${initialNode.countryCode})" else "Direct"
            cycleKey += 1
            if (config.runInBackground) {
                AutomationForegroundService.start(
                    context,
                    "Impr: $sessionImpressions • ${activeDevice.name} • $proxyLabel"
                )
            }
        }

        onDispose {
            ProxyManager.applyProxyToWebView(null, directFallback = true, executor = mainExecutor) {}
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Surface(color = SurfaceDark, tonalElevation = 4.dp) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(onClick = onMinimize) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                        }
                        Column {
                            Text(
                                text = "Live (${siteList.size} Sites • $tabCount Tabs)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (challengePaused) "Paused: Challenge detected" else urlForTab(selectedTab),
                                color = if (challengePaused) WarningAmber else AccentBlueLight,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .padding(horizontal = 6.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Visibility, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$sessionImpressions",
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalIconButton(
                            onClick = { rotateNow() },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = AccentBlueLight
                            )
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = "Rotate")
                        }
                        FilledTonalIconButton(
                            onClick = {
                                CloudflareChallengeHandler.setPaused(false)
                                AutomationForegroundService.stop(context)
                                onStop()
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = DangerRed,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Stop")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuccessBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Devices, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeDevice.name,
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (challengePaused) Icons.Rounded.Warning else Icons.Rounded.Public,
                            contentDescription = null,
                            tint = if (challengePaused) WarningAmber else SuccessGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = proxyLabel,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (i in 0 until tabCount) {
                        val isSelected = selectedTab == i
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) AccentBlue else CardDark)
                                .clickable { selectedTab = i }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "Tab ${i + 1}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        if (challengePaused) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF451A03))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Challenge detected — Auto-scroll & refresh paused",
                        color = Color(0xFFFEF3C7),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                TextButton(
                    onClick = {
                        CloudflareChallengeHandler.setPaused(false)
                        challengePaused = false
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Resume", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            key(selectedTab, cycleKey) {
                AutomationWebView(
                    url = urlForTab(selectedTab),
                    profile = activeDevice,
                    refreshIntervalSec = config.refreshIntervalSec,
                    scrollIntervalSec = config.scrollIntervalSec,
                    randomizeIntervals = config.randomizeIntervals,
                    proxyUser = currentProxy?.username,
                    proxyPass = currentProxy?.password,
                    onPageLoaded = { recordImpression() },
                    onChallengeDetected = { detected ->
                        challengePaused = detected
                    }
                )
            }
        }
    }
}
