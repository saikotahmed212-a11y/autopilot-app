package com.autopilot.nonroot.engine

import android.util.Log
import android.webkit.WebView

/**
 * Cloudflare Challenge Handler
 * Detects challenge pages and handles auto-pause / main-thread auto-refresh logic.
 */
object CloudflareChallengeHandler {

    private const val TAG = "CF_Challenge_Handler"

    @Volatile
    private var isPaused = false

    @Volatile
    private var isReloadScheduled = false

    // Cloudflare's common challenge indicators
    private val challengePatterns = listOf(
        "cf-challenge-running",
        "jschl-answer",
        "cdn-cgi/challenge-platform",
        "Checking your browser",
        "challenges.cloudflare.com",
        "turnstile",
        "verify you are human",
        "just a moment"
    )

    fun isChallengePaused(): Boolean = isPaused

    fun checkAndHandle(
        url: String,
        webView: WebView,
        onResult: (Boolean) -> Unit = {}
    ) {
        try {
            val jsInspect = """
                (function() {
                    var html = document.documentElement ? document.documentElement.outerHTML : '';
                    var title = document.title || '';
                    return title + ' ' + html.substring(0, 12000);
                })();
            """.trimIndent()

            webView.evaluateJavascript(jsInspect) { rawContent ->
                val content = rawContent ?: ""
                val hasChallenge = challengePatterns.any { pattern ->
                    content.contains(pattern, ignoreCase = true)
                }

                if (hasChallenge) {
                    if (!isPaused) {
                        Log.d(TAG, "Cloudflare Challenge Detected on $url! Pausing...")
                        isPaused = true
                    }
                    onResult(true)

                    if (!isReloadScheduled) {
                        isReloadScheduled = true
                        // Wait 5 seconds on the UI thread for potential manual solve or timeout
                        webView.postDelayed({
                            isReloadScheduled = false
                            if (!isPaused) {
                                Log.d(TAG, "Challenge solved manually.")
                            } else {
                                Log.d(TAG, "Auto-refreshing due to persistent challenge...")
                                isPaused = false
                                webView.reload()
                            }
                        }, 5000L)
                    }
                } else {
                    if (isPaused) {
                        Log.d(TAG, "Challenge cleared on $url. Resuming...")
                        isPaused = false
                    }
                    onResult(false)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking challenge", e)
            onResult(false)
        }
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
        if (!paused) {
            isReloadScheduled = false
        }
        Log.d(TAG, "Handler State: ${if (paused) "PAUSED" else "ACTIVE"}")
    }
}
