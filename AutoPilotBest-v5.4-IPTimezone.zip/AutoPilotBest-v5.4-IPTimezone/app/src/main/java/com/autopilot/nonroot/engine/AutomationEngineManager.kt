package com.autopilot.nonroot.engine

import android.annotation.SuppressLint
import android.content.Context
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebStorage
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.autopilot.nonroot.model.ActivityLogEntry
import com.autopilot.nonroot.model.AutomationConfig
import com.autopilot.nonroot.model.EngineSnapshot
import com.autopilot.nonroot.model.TabStatus
import com.autopilot.nonroot.model.formatDuration
import com.autopilot.nonroot.service.AutomationForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

/**
 * Persistent background automation engine owned by the Application / ForegroundService lifecycle.
 * Keeps running when the user leaves the app, switches apps, or turns off the screen.
 */
object AutomationEngineManager {

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(EngineSnapshot())
    val state: StateFlow<EngineSnapshot> = _state.asStateFlow()

    private var appContext: Context? = null
    private var proxyPool: List<ProxyNode> = emptyList()
    private var proxyIndex: Int = 0
    private var runtimeJob: Job? = null
    private var scrollJob: Job? = null

    private val webViews = mutableMapOf<Int, WebView>()
    private val videoCountedPerTab = mutableSetOf<Int>()

    private var totalImpressionsCallback: (() -> Unit)? = null
    private var totalVideoViewsCallback: (() -> Unit)? = null

    fun setGlobalCountersCallbacks(
        onImpression: () -> Unit,
        onVideoView: () -> Unit
    ) {
        totalImpressionsCallback = onImpression
        totalVideoViewsCallback = onVideoView
    }

    fun updateProxyPool(proxies: List<ProxyNode>) {
        proxyPool = proxies
    }

    fun getOrCreateWebView(context: Context, tabIndex: Int): WebView {
        val ctx = appContext ?: context.applicationContext
        return webViews.getOrPut(tabIndex) {
            createConfiguredWebView(ctx, tabIndex)
        }
    }

    fun startSession(
        context: Context,
        config: AutomationConfig,
        proxies: List<ProxyNode>
    ) {
        stopSession(context, stopService = false)

        appContext = context.applicationContext
        proxyPool = proxies
        proxyIndex = 0
        videoCountedPerTab.clear()

        val initialDevice = DeviceProfileEngine.getRandomProfile()
        val spoofId = if (config.deviceSpoofingEnabled) {
            DeviceProfileEngine.generateNonRootDeviceId(initialDevice)
        } else {
            "N/A (spoofing disabled)"
        }

        val initialProxy = if (config.useProxyRotation && proxies.isNotEmpty()) {
            proxyIndex = 1
            proxies[0]
        } else {
            null
        }

        val initialTabs = (0 until config.tabCount.coerceIn(1, 15)).map { idx ->
            TabStatus(
                index = idx,
                url = normalizeUrl(config.urls[idx % config.urls.size]),
                isRunning = true,
                scrollCount = 0,
                lastAction = "Tab ready"
            )
        }

        _state.value = EngineSnapshot(
            config = config,
            isRunning = true,
            isPaused = false,
            activeTabIndex = 0,
            tabs = initialTabs,
            currentDevice = initialDevice,
            spoofedDeviceId = spoofId,
            currentProxy = initialProxy,
            proxyStatusLabel = if (initialProxy != null) initialProxy.address else "Disabled",
            proxyCountryLabel = initialProxy?.countryCode ?: "N/A",
            proxyTimezoneLabel = initialProxy?.timezoneId ?: TimeZone.getDefault().id,
            refreshCount = 0,
            scrollCount = 0,
            runtimeSeconds = 0,
            secondsUntilNextRefresh = config.refreshIntervalSec.coerceAtLeast(5),
            sessionImpressions = 0,
            sessionVideoViews = 0,
            liveStatusMessage = "Initializing ${initialTabs.size} tabs...",
            lastUpdatedLabel = currentTimeFull(),
            manualVerificationNeeded = false,
            logs = emptyList()
        )

        addLog("Info", "Session started (${initialTabs.size} tabs)")
        if (config.deviceSpoofingEnabled) {
            addLog("Profile", "Non-Root Spoof ID: $spoofId (${initialDevice.name})")
        }

        if (config.runInBackground) {
            AutomationForegroundService.start(
                context,
                "Running • ${initialTabs.size} Tabs • 00:00:00"
            )
        }

        val executor = ContextCompat.getMainExecutor(context.applicationContext)
        val proceedStart = {
            ProxyManager.applyProxyToWebView(initialProxy, executor) { applied ->
                if (initialProxy != null) {
                    addLog("Proxy", if (applied) "Connected: ${initialProxy.address} (${initialProxy.countryCode})" else "Direct mode (proxy override unsupported)")
                }
                initialTabs.forEach { tab ->
                    val wv = getOrCreateWebView(context.applicationContext, tab.index)
                    loadTabUrl(wv, tab.url, initialDevice, initialProxy)
                    addLog("Info", "Tab ${tab.index + 1} created")
                }
                startLoops()
            }
        }

        if (config.autoClearCachePerCycle) {
            clearAllWebViewCacheAndCookies { proceedStart() }
        } else {
            proceedStart()
        }
    }

    fun togglePause() {
        val current = _state.value
        if (!current.isRunning) return
        val nextPaused = !current.isPaused
        _state.update {
            it.copy(
                isPaused = nextPaused,
                liveStatusMessage = if (nextPaused) "Paused by user" else "Resumed automation",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Pause", if (nextPaused) "Session paused" else "Session resumed")
        updateNotification()
    }

    fun selectTab(index: Int) {
        val current = _state.value
        if (index in current.tabs.indices) {
            _state.update { it.copy(activeTabIndex = index) }
        }
    }

    fun addNewTab() {
        val ctx = appContext ?: return
        val current = _state.value
        val cfg = current.config ?: return
        if (current.tabs.size >= 15) {
            addLog("Info", "Max 15 tabs limit reached")
            return
        }
        val newIdx = current.tabs.size
        val url = normalizeUrl(cfg.urls[newIdx % cfg.urls.size])
        val newTab = TabStatus(index = newIdx, url = url, isRunning = true, lastAction = "Tab ready")
        val updatedTabs = current.tabs + newTab
        _state.update {
            it.copy(
                tabs = updatedTabs,
                liveStatusMessage = "Added Tab ${newIdx + 1}",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        val wv = getOrCreateWebView(ctx, newIdx)
        loadTabUrl(wv, url, current.currentDevice, current.currentProxy)
        addLog("Info", "Tab ${newIdx + 1} created")
        updateNotification()
    }

    fun resumeFromVerification() {
        _state.update {
            it.copy(
                manualVerificationNeeded = false,
                liveStatusMessage = "Resumed after verification",
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Info", "Manual verification cleared")
    }

    fun rotateNow() {
        val ctx = appContext ?: return
        val current = _state.value
        val cfg = current.config ?: return
        if (!current.isRunning) return

        val nextDevice = if (cfg.deviceSpoofingEnabled) {
            DeviceProfileEngine.pickRandom(current.currentDevice.name)
        } else {
            current.currentDevice
        }
        val nextSpoofId = if (cfg.deviceSpoofingEnabled) {
            DeviceProfileEngine.generateNonRootDeviceId(nextDevice)
        } else {
            "N/A (spoofing disabled)"
        }

        val nextProxy = if (cfg.useProxyRotation && proxyPool.isNotEmpty()) {
            val picked = proxyPool[proxyIndex % proxyPool.size]
            proxyIndex = (proxyIndex + 1) % proxyPool.size
            picked
        } else {
            null
        }

        val nextRefreshSec = if (cfg.randomizeIntervals) {
            (cfg.refreshIntervalSec + Random.nextInt(-3, 4)).coerceAtLeast(5)
        } else {
            cfg.refreshIntervalSec.coerceAtLeast(5)
        }

        videoCountedPerTab.clear()
        val executor = ContextCompat.getMainExecutor(ctx)
        val proceedRotation = {
            ProxyManager.applyProxyToWebView(nextProxy, executor) { _ ->
                _state.update { s ->
                    val nextActiveTab = if (s.tabs.isNotEmpty()) (s.activeTabIndex + 1) % s.tabs.size else 0
                    s.copy(
                        currentDevice = nextDevice,
                        spoofedDeviceId = nextSpoofId,
                        currentProxy = nextProxy,
                        proxyStatusLabel = nextProxy?.address ?: "Disabled",
                        proxyCountryLabel = nextProxy?.countryCode ?: "N/A",
                        proxyTimezoneLabel = nextProxy?.timezoneId ?: TimeZone.getDefault().id,
                        refreshCount = s.refreshCount + 1,
                        activeTabIndex = nextActiveTab,
                        secondsUntilNextRefresh = nextRefreshSec,
                        liveStatusMessage = if (cfg.autoClearCachePerCycle) {
                            "Cache cleared • Rotated IP & Device (${s.tabs.size} tabs)"
                        } else {
                            "Rotated profile & refreshed ${s.tabs.size} tabs"
                        },
                        lastUpdatedLabel = currentTimeFull()
                    )
                }

                if (cfg.deviceSpoofingEnabled) {
                    addLog("Profile", "Rotated ID: $nextSpoofId (${nextDevice.name})")
                }
                if (nextProxy != null) {
                    addLog("Proxy", "Switched IP: ${nextProxy.address} (${nextProxy.countryCode} • ${nextProxy.timezoneId})")
                }

                // Reload all active WebViews with the new profile & proxy
                _state.value.tabs.forEach { tab ->
                    val wv = webViews[tab.index]
                    if (wv != null) {
                        applyDeviceProfileToWebView(wv, nextDevice, cfg.autoVideoViewEnabled)
                        loadTabUrl(wv, tab.url, nextDevice, nextProxy)
                    }
                }
                updateNotification()
            }
        }

        if (cfg.autoClearCachePerCycle) {
            clearAllWebViewCacheAndCookies { proceedRotation() }
        } else {
            proceedRotation()
        }
    }

    fun stopSession(context: Context? = null, stopService: Boolean = true) {
        runtimeJob?.cancel()
        scrollJob?.cancel()
        runtimeJob = null
        scrollJob = null

        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) {
            val executor = ContextCompat.getMainExecutor(ctx)
            ProxyManager.applyProxyToWebView(null, executor) {}
            if (stopService) {
                AutomationForegroundService.stop(ctx)
            }
        }

        webViews.values.forEach { wv ->
            try {
                wv.stopLoading()
                wv.loadUrl("about:blank")
                wv.clearHistory()
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.destroy()
            } catch (_: Exception) {}
        }
        webViews.clear()
        videoCountedPerTab.clear()

        _state.value = EngineSnapshot()
    }

    private fun startLoops() {
        runtimeJob?.cancel()
        scrollJob?.cancel()

        // 1-second runtime & refresh countdown loop
        runtimeJob = engineScope.launch {
            while (isActive) {
                delay(1000L)
                val s = _state.value
                if (!s.isRunning) break
                if (s.isPaused || s.manualVerificationNeeded) continue

                val newRuntime = s.runtimeSeconds + 1
                if (s.secondsUntilNextRefresh > 1) {
                    _state.update {
                        it.copy(
                            runtimeSeconds = newRuntime,
                            secondsUntilNextRefresh = it.secondsUntilNextRefresh - 1
                        )
                    }
                } else {
                    _state.update { it.copy(runtimeSeconds = newRuntime) }
                    rotateNow()
                }

                if (newRuntime % 3 == 0) {
                    updateNotification()
                }
            }
        }

        // Scroll & Auto-Video loop across all active tabs (even in background!)
        scrollJob = engineScope.launch {
            while (isActive) {
                val cfg = _state.value.config ?: break
                val jitter = if (cfg.randomizeIntervals) Random.nextLong(-2000L, 2000L) else 0L
                delay((cfg.scrollIntervalSec * 1000L + jitter).coerceAtLeast(2500L))

                val s = _state.value
                if (!s.isRunning) break
                if (s.isPaused || s.manualVerificationNeeded || s.tabs.isEmpty()) continue

                val tabIdx = s.scrollCount % s.tabs.size
                val wv = webViews[tabIdx] ?: continue

                if (cfg.autoVideoViewEnabled) {
                    triggerAutoVideo(wv, cfg.muteAutoVideo) { playing ->
                        if (playing) {
                            if (videoCountedPerTab.add(tabIdx)) {
                                _state.update { cur ->
                                    cur.copy(
                                        sessionVideoViews = cur.sessionVideoViews + 1,
                                        liveStatusMessage = "Tab ${tabIdx + 1}: Video playing",
                                        lastUpdatedLabel = currentTimeFull()
                                    )
                                }
                                totalVideoViewsCallback?.invoke()
                                addLog("Video", "Tab ${tabIdx + 1}: Auto-playing video")
                            }
                        } else {
                            performHumanScroll(wv, tabIdx)
                        }
                    }
                } else if (cfg.autoClickAndBackEnabled && s.scrollCount > 0 && s.scrollCount % 3 == 0) {
                    performAutoClickAndBack(wv, tabIdx)
                } else {
                    performHumanScroll(wv, tabIdx)
                }
            }
        }
    }

    private fun performAutoClickAndBack(wv: WebView, tabIdx: Int) {
        val jsClick = """
            (function() {
                const links = Array.from(document.querySelectorAll('a[href]')).filter(a => {
                    const href = (a.getAttribute('href') || '').trim();
                    if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
                    const rect = a.getBoundingClientRect();
                    return rect.width > 10 && rect.height > 10 && a.offsetParent !== null;
                });
                if (links.length === 0) return 'NO_LINK';
                const target = links[Math.floor(Math.random() * Math.min(links.length, 12))];
                const label = (target.innerText || target.getAttribute('href') || 'link').trim().substring(0, 32);
                try {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.removeAttribute('target');
                    target.click();
                    return 'CLICKED:' + label;
                } catch (e) {
                    return 'ERROR';
                }
            })();
        """.trimIndent()

        wv.evaluateJavascript(jsClick) { raw ->
            val res = raw?.trim('"') ?: ""
            if (res.startsWith("CLICKED:")) {
                val label = res.removePrefix("CLICKED:").ifBlank { "link" }
                _state.update { s ->
                    val updatedTabs = s.tabs.map { t ->
                        if (t.index == tabIdx) t.copy(scrollCount = t.scrollCount + 1, lastAction = "Clicked: $label") else t
                    }
                    s.copy(
                        tabs = updatedTabs,
                        scrollCount = s.scrollCount + 1,
                        liveStatusMessage = "Tab ${tabIdx + 1}: Clicked "$label"",
                        lastUpdatedLabel = currentTimeFull()
                    )
                }
                addLog("Click", "Tab ${tabIdx + 1}: Clicked $label")

                val cfgNow = _state.value.config
                val baseWaitSec = (cfgNow?.clickBackWaitSec ?: 5).coerceIn(1, 120)
                val jitterMs = if (cfgNow?.randomizeIntervals == true) Random.nextLong(-1000L, 1500L) else 0L
                val backDelayMs = (baseWaitSec * 1000L + jitterMs).coerceAtLeast(1000L)
                wv.postDelayed({
                    val cur = _state.value
                    if (!cur.isRunning || cur.isPaused) return@postDelayed
                    if (wv.canGoBack()) {
                        wv.goBack()
                        _state.update { s ->
                            s.copy(
                                liveStatusMessage = "Tab ${tabIdx + 1}: Navigated back",
                                lastUpdatedLabel = currentTimeFull()
                            )
                        }
                        addLog("Back", "Tab ${tabIdx + 1}: Returned back")
                    } else {
                        val origUrl = cur.tabs.getOrNull(tabIdx)?.url
                        if (origUrl != null) {
                            loadTabUrl(wv, origUrl, cur.currentDevice, cur.currentProxy)
                            addLog("Back", "Tab ${tabIdx + 1}: Returned to main page")
                        }
                    }
                }, backDelayMs)
            } else {
                performHumanScroll(wv, tabIdx)
            }
        }
    }

    private fun performHumanScroll(wv: WebView, tabIdx: Int) {
        val scrollBack = Random.nextInt(100) < 22
        val px = if (scrollBack) -Random.nextInt(90, 220) else Random.nextInt(220, 480)
        wv.evaluateJavascript("window.scrollBy({ top: $px, behavior: 'smooth' });", null)

        val actionText = if (scrollBack) {
            "Tab ${tabIdx + 1}: Scrolled back ${-px}px"
        } else {
            "Tab ${tabIdx + 1}: Scrolled down ${px}px"
        }
        val shortAction = if (scrollBack) "Scrolled back ${-px}px" else "Scrolled ${px}px down"

        _state.update { s ->
            val updatedTabs = s.tabs.map { t ->
                if (t.index == tabIdx) t.copy(scrollCount = t.scrollCount + 1, lastAction = shortAction) else t
            }
            s.copy(
                tabs = updatedTabs,
                scrollCount = s.scrollCount + 1,
                liveStatusMessage = actionText,
                lastUpdatedLabel = currentTimeFull()
            )
        }
        addLog("Scroll", shortAction)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createConfiguredWebView(context: Context, tabIndex: Int): WebView {
        val s = _state.value
        val cfg = s.config
        val wv = WebView(context)
        applyDeviceProfileToWebView(wv, s.currentDevice, cfg?.autoVideoViewEnabled ?: false)
        wv.webChromeClient = WebChromeClient()

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                super.onPageFinished(view, loadedUrl)
                val current = _state.value
                if (!current.isRunning) return

                _state.update { cur ->
                    cur.copy(
                        sessionImpressions = cur.sessionImpressions + 1,
                        liveStatusMessage = "Tab ${tabIndex + 1}: Loaded",
                        lastUpdatedLabel = currentTimeFull()
                    )
                }
                totalImpressionsCallback?.invoke()

                if (view != null) {
                    checkManualChallenge(view) { detected ->
                        if (detected) {
                            _state.update { cur ->
                                cur.copy(
                                    manualVerificationNeeded = true,
                                    liveStatusMessage = "Tab ${tabIndex + 1}: Manual verification needed",
                                    lastUpdatedLabel = currentTimeFull()
                                )
                            }
                            addLog("Pause", "Manual verification detected on Tab ${tabIndex + 1}")
                        } else if (current.config?.autoVideoViewEnabled == true) {
                            view.postDelayed({
                                triggerAutoVideo(view, current.config.muteAutoVideo) { playing ->
                                    if (playing && videoCountedPerTab.add(tabIndex)) {
                                        _state.update { cur ->
                                            cur.copy(
                                                sessionVideoViews = cur.sessionVideoViews + 1,
                                                liveStatusMessage = "Tab ${tabIndex + 1}: Video playing",
                                                lastUpdatedLabel = currentTimeFull()
                                            )
                                        }
                                        totalVideoViewsCallback?.invoke()
                                        addLog("Video", "Tab ${tabIndex + 1}: Video started")
                                    }
                                }
                            }, 1400L)
                        }
                    }
                }
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView?,
                handler: HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                val proxy = _state.value.currentProxy
                if (proxy != null && proxy.hasAuth) {
                    handler?.proceed(proxy.username, proxy.password)
                } else {
                    super.onReceivedHttpAuthRequest(view, handler, host, realm)
                }
            }
        }
        return wv
    }

    private fun clearAllWebViewCacheAndCookies(onCleared: () -> Unit) {
        try {
            webViews.values.forEach { wv ->
                wv.clearCache(true)
                wv.clearHistory()
                wv.clearFormData()
            }
            WebStorage.getInstance().deleteAllData()
            val cm = CookieManager.getInstance()
            cm.removeAllCookies {
                try {
                    cm.flush()
                } catch (_: Exception) {}
                addLog("Cache", "Auto-cleared cache, cookies & storage")
                onCleared()
            }
        } catch (_: Exception) {
            onCleared()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applyDeviceProfileToWebView(
        webView: WebView,
        profile: DeviceProfile,
        allowAutoplay: Boolean
    ) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = !allowAutoplay
            userAgentString = DeviceProfileEngine.sanitizeUserAgent(profile.userAgent)
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(webView.settings, emptySet())
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
    }

    private fun loadTabUrl(
        webView: WebView,
        url: String,
        profile: DeviceProfile,
        proxy: ProxyNode?
    ) {
        val headers = mapOf(
            "Accept-Language" to (proxy?.acceptLanguage ?: profile.acceptLanguage)
        )
        webView.loadUrl(url, headers)
    }

    private fun checkManualChallenge(webView: WebView, onResult: (Boolean) -> Unit) {
        val jsCheck = """
            (function() {
                const title = (document.title || '').toLowerCase();
                const text = (document.body ? document.body.innerText : '').toLowerCase();
                const hasChallengeFrame = document.querySelector(
                    'iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"]'
                ) !== null;
                const hasChallengeText = title.includes('just a moment')
                    || title.includes('attention required')
                    || text.includes('verify you are human')
                    || text.includes('checking your browser');
                return (hasChallengeFrame || hasChallengeText) ? 'CHALLENGE' : 'OK';
            })();
        """.trimIndent()
        webView.evaluateJavascript(jsCheck) { result ->
            onResult(result?.contains("CHALLENGE") == true)
        }
    }

    private fun triggerAutoVideo(webView: WebView, muteVideo: Boolean, onResult: (Boolean) -> Unit) {
        val muteFlag = if (muteVideo) "true" else "false"
        val jsPlay = """
            (function() {
                const videos = Array.from(document.querySelectorAll('video'));
                if (videos.length === 0) return 'NO_VIDEO';
                const target = videos.find(v => v.offsetWidth > 0 && v.offsetHeight > 0) || videos[0];
                try {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.playsInline = true;
                    if ($muteFlag) target.muted = true;
                    if (target.paused) {
                        const p = target.play();
                        if (p && typeof p.catch === 'function') p.catch(function() {});
                        return 'STARTED';
                    }
                    return 'PLAYING';
                } catch (e) {
                    return 'ERROR';
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(jsPlay) { result ->
            onResult(result?.contains("STARTED") == true || result?.contains("PLAYING") == true)
        }
    }

    private fun addLog(tag: String, message: String) {
        val entry = ActivityLogEntry(
            timeLabel = currentTimeShort(),
            tag = tag,
            message = message
        )
        _state.update { s ->
            val updated = (listOf(entry) + s.logs).take(60)
            s.copy(logs = updated)
        }
    }

    private fun updateNotification() {
        val ctx = appContext ?: return
        val s = _state.value
        if (s.isRunning && s.config?.runInBackground == true) {
            val stateWord = if (s.isPaused) "Paused" else "Running"
            AutomationForegroundService.updateStatus(
                ctx,
                "$stateWord • ${s.tabs.size} Tabs • ${formatDuration(s.runtimeSeconds)} • Impr: ${s.sessionImpressions}"
            )
        }
    }

    private fun activeTimeZone(): TimeZone {
        val tzId = _state.value.currentProxy?.timezoneId
        return if (!tzId.isNullOrBlank()) TimeZone.getTimeZone(tzId) else TimeZone.getDefault()
    }

    private fun currentTimeFull(): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.US)
        sdf.timeZone = activeTimeZone()
        return sdf.format(Date())
    }

    private fun currentTimeShort(): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.US)
        sdf.timeZone = activeTimeZone()
        return sdf.format(Date())
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://www.google.com"
            else -> "https://$trimmed"
        }
    }
}
