package com.autopilot.nonroot.engine

import android.content.Context
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

data class ProxyNode(
    val host: String,
    val port: Int,
    val country: String = "Auto",
    val latencyMs: Long = 0L,
    val isHealthy: Boolean = false
) {
    val address: String get() = "$host:$port"
}

data class ProxyFetchProgress(
    val tested: Int = 0,
    val total: Int = 0,
    val healthyCount: Int = 0,
    val statusText: String = "Idle"
)

object ProxyManager {

    private val proxySources = listOf(
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=4000&country=all&ssl=yes&anonymity=all",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt"
    )

    suspend fun fetchAndTestProxies(
        maxToTest: Int = 60,
        onProgress: (ProxyFetchProgress) -> Unit
    ): List<ProxyNode> = withContext(Dispatchers.IO) {
        suspend fun report(progress: ProxyFetchProgress) {
            withContext(Dispatchers.Main) {
                onProgress(progress)
            }
        }

        report(ProxyFetchProgress(0, maxToTest, 0, "Downloading SSL/HTTPS proxy lists..."))

        val rawSet = LinkedHashSet<Pair<String, Int>>()
        val ipPortRegex = Regex("""^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{2,5})$""")

        for (sourceUrl in proxySources) {
            try {
                val conn = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                }
                if (conn.responseCode in 200..299) {
                    BufferedReader(InputStreamReader(conn.inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            val trimmed = line?.trim().orEmpty()
                            val match = ipPortRegex.matchEntire(trimmed)
                            if (match != null) {
                                val host = match.groupValues[1]
                                val port = match.groupValues[2].toIntOrNull()
                                if (port != null && port in 1..65535) {
                                    rawSet.add(host to port)
                                }
                            }
                            if (rawSet.size >= 400) break
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Skip unreachable source cleanly
            }
        }

        val candidates = rawSet.toList().shuffled().take(maxToTest)
        if (candidates.isEmpty()) {
            report(ProxyFetchProgress(0, 0, 0, "No proxy list reached — Direct mode ready"))
            return@withContext emptyList()
        }

        val testedCounter = AtomicInteger(0)
        val healthyCounter = AtomicInteger(0)
        val semaphore = Semaphore(20)

        val healthyNodes = coroutineScope {
            candidates.map { (host, port) ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val result = testHttpsProxy(host, port)
                        val testedNow = testedCounter.incrementAndGet()
                        val healthyNow = if (result != null) healthyCounter.incrementAndGet() else healthyCounter.get()
                        report(
                            ProxyFetchProgress(
                                tested = testedNow,
                                total = candidates.size,
                                healthyCount = healthyNow,
                                statusText = "HTTPS Testing $testedNow/${candidates.size} ($healthyNow healthy)"
                            )
                        )
                        result
                    }
                }
            }.awaitAll().filterNotNull().sortedBy { it.latencyMs }
        }

        report(
            ProxyFetchProgress(
                tested = candidates.size,
                total = candidates.size,
                healthyCount = healthyNodes.size,
                statusText = if (healthyNodes.isNotEmpty()) {
                    "${healthyNodes.size} HTTPS-verified proxies ready"
                } else {
                    "0 fast HTTPS proxies — Direct fallback active"
                }
            )
        )
        healthyNodes
    }

    private fun testHttpsProxy(host: String, port: Int): ProxyNode? {
        val start = System.currentTimeMillis()
        return try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress(host, port))
            val conn = (URL("https://www.google.com/generate_204").openConnection(proxy) as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 3000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            val code = conn.responseCode
            conn.disconnect()
            val latency = System.currentTimeMillis() - start
            if ((code == 204 || code in 200..399) && latency < 3500) {
                ProxyNode(
                    host = host,
                    port = port,
                    country = "Auto",
                    latencyMs = latency,
                    isHealthy = true
                )
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Thread-safe non-root WebView ProxyController override using ContextCompat.getMainExecutor.
     */
    fun applyWebViewProxy(
        context: Context,
        proxy: ProxyNode?,
        allowDirectFallback: Boolean = true,
        onApplied: (String) -> Unit
    ) {
        val mainExecutor = ContextCompat.getMainExecutor(context)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            mainExecutor.execute { onApplied("Direct (Native Engine)") }
            return
        }

        try {
            val controller = ProxyController.getInstance()
            if (proxy == null) {
                controller.clearProxyOverride(
                    mainExecutor,
                    Runnable { onApplied("Direct Connection") }
                )
            } else {
                val builder = ProxyConfig.Builder()
                    .addProxyRule("http://${proxy.host}:${proxy.port}")
                if (allowDirectFallback) {
                    builder.addDirect()
                }
                controller.setProxyOverride(
                    builder.build(),
                    mainExecutor,
                    Runnable { onApplied("${proxy.host}:${proxy.port} (${proxy.latencyMs}ms)") }
                )
            }
        } catch (_: Exception) {
            mainExecutor.execute { onApplied("Direct Connection (Fallback)") }
        }
    }
}
