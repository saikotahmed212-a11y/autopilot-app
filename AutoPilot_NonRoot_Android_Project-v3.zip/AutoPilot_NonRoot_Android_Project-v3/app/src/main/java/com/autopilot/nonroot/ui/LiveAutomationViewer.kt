package com.autopilot.nonroot.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.model.LiveRunnerState
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.random.Random

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LiveAutomationViewer(
    runner: LiveRunnerState,
    healthyProxies: List<ProxyNode>,
    onMinimize: () -> Unit,
    onStop: () -> Unit,
    onUpdateRunner: (LiveRunnerState) -> Unit,
    onDeviceRotated: () -> Unit
) {
    val context = LocalContext.current
    val config = runner.config
    val tabCount = config.tabCount.coerceIn(1, 15)

    val latestRunner by rememberUpdatedState(runner)
    val latestProxies by rememberUpdatedState(healthyProxies)

    val webViews = remember(config.id) { mutableStateListOf<WebView>() }
    val tabProgress = remember(config.id) { mutableStateMapOf<Int, Int>() }
    val tabCurrentUrls = remember(config.id) { mutableStateMapOf<Int, String>() }
    val tabRetryCounts = remember(config.id) { mutableStateMapOf<Int, Int>() }
    val tabLoadStartedAt = remember(config.id) { mutableStateMapOf<Int, Long>() }

    var currentProxyIndex by remember(config.id) { mutableIntStateOf(0) }
    var activeDevice by remember(config.id) { mutableStateOf(runner.currentDevice) }
    var activeProxyText by remember(config.id) { mutableStateOf(runner.currentProxyLabel) }
    var countdown by remember(config.id) { mutableIntStateOf(config.refreshIntervalSec) }
    var rotationCount by remember(config.id) { mutableIntStateOf(runner.rotationCount) }
    var selectedTab by remember(config.id) { mutableIntStateOf(runner.activeTabIndex) }
    var forceDirectMode by remember(config.id) { mutableStateOf(!config.useFreeProxy) }

    // Handle phone back button gracefully
    BackHandler {
        val currentWv = webViews.getOrNull(selectedTab)
        if (currentWv != null && currentWv.canGoBack()) {
            currentWv.goBack()
        } else {
            onMinimize()
        }
    }

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://www.wikipedia.org"
            else -> "https://$trimmed"
        }
    }

    fun urlForTab(index: Int): String {
        val list = config.urls.ifEmpty { listOf("https://www.wikipedia.org") }
        return normalizeUrl(list[index % list.size])
    }

    fun applyDeviceToWebView(wv: WebView, profile: DeviceProfile) {
        wv.settings.userAgentString = profile.userAgent
    }

    fun recoverTabWithDirect(tabIdx: Int, wv: WebView) {
        val retries = tabRetryCounts[tabIdx] ?: 0
        if (retries >= 2) return
        tabRetryCounts[tabIdx] = retries + 1
        ProxyManager.applyWebViewProxy(
            context = context,
            proxy = null,
            allowDirectFallback = true
        ) { label ->
            activeProxyText = "$label (Auto-Healed)"
            wv.postDelayed({
                wv.stopLoading()
                tabLoadStartedAt[tabIdx] = System.currentTimeMillis()
                wv.loadUrl(urlForTab(tabIdx))
            }, 350)
        }
    }

    fun rotateIdentityAndReload(forceDirect: Boolean = forceDirectMode) {
        if (config.clearCookiesOnRotate) {
            try {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            } catch (_: Exception) {}
        }

        val nextDevice = if (config.deviceRotationEnabled) {
            DeviceProfileEngine.pickRandom(activeDevice.id)
        } else {
            activeDevice
        }
        activeDevice = nextDevice
        rotationCount += 1
        tabRetryCounts.clear()
        onDeviceRotated()

        val proxies = latestProxies
        val chosenProxy: ProxyNode? = if (!forceDirect && config.useFreeProxy && proxies.isNotEmpty()) {
            val node = proxies[currentProxyIndex % proxies.size]
            currentProxyIndex++
            node
        } else {
            null
        }

        ProxyManager.applyWebViewProxy(
            context = context,
            proxy = chosenProxy,
            allowDirectFallback = config.autoFallbackDirect
        ) { appliedLabel ->
            activeProxyText = appliedLabel
            onUpdateRunner(
                latestRunner.copy(
                    currentDevice = nextDevice,
                    currentProxyLabel = appliedLabel,
                    rotationCount = rotationCount,
                    activeTabIndex = selectedTab,
                    lastStatus = "Rotated: ${nextDevice.name}"
                )
            )
            webViews.forEachIndexed { idx, wv ->
                wv.post {
                    applyDeviceToWebView(wv, nextDevice)
                    tabLoadStartedAt[idx] = System.currentTimeMillis()
                    wv.loadUrl(urlForTab(idx))
                }
            }
        }
    }

    DisposableEffect(config.id) {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        val initialProxy = if (!forceDirectMode && config.useFreeProxy && latestProxies.isNotEmpty()) {
            latestProxies[0]
        } else null

        for (i in 0 until tabCount) {
            val targetUrl = urlForTab(i)
            tabCurrentUrls[i] = targetUrl
            tabProgress[i] = 10

            val wv = WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(android.graphics.Color.WHITE)

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    allowContentAccess = true
                    allowFileAccess = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    setSupportZoom(true)
                    setSupportMultipleWindows(false)
                    javaScriptCanOpenWindowsAutomatically = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    mediaPlaybackRequiresUserGesture = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    userAgentString = activeDevice.userAgent
                }

                cookieManager.setAcceptThirdPartyCookies(this, true)

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        tabProgress[i] = newProgress
                        if (newProgress >= 100) {
                            tabLoadStartedAt.remove(i)
                        }
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return false
                        val scheme = uri.scheme?.lowercase().orEmpty()
                        return !(scheme == "http" || scheme == "https")
                    }

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        tabProgress[i] = 15
                        tabLoadStartedAt[i] = System.currentTimeMillis()
                        if (!url.isNullOrBlank()) tabCurrentUrls[i] = url
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        tabProgress[i] = 100
                        tabRetryCounts[i] = 0
                        tabLoadStartedAt.remove(i)
                        if (!url.isNullOrBlank()) tabCurrentUrls[i] = url
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        if (request?.isForMainFrame == true && view != null) {
                            recoverTabWithDirect(i, view)
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        errorResponse: WebResourceResponse?
                    ) {
                        val code = errorResponse?.statusCode ?: 0
                        if (request?.isForMainFrame == true && view != null && code in listOf(407, 502, 503, 504)) {
                            recoverTabWithDirect(i, view)
                        }
                    }

                    @SuppressLint("WebViewClientOnReceivedSslError")
                    override fun onReceivedSslError(
                        view: WebView?,
                        handler: SslErrorHandler?,
                        error: SslError?
                    ) {
                        handler?.proceed()
                    }
                }
            }
            webViews.add(wv)
        }

        ProxyManager.applyWebViewProxy(
            context = context,
            proxy = initialProxy,
            allowDirectFallback = config.autoFallbackDirect
        ) { appliedLabel ->
            activeProxyText = appliedLabel
            onUpdateRunner(
                latestRunner.copy(
                    currentDevice = activeDevice,
                    currentProxyLabel = appliedLabel,
                    lastStatus = "Live on ${activeDevice.name}"
                )
            )
            webViews.forEachIndexed { idx, wv ->
                wv.post {
                    tabLoadStartedAt[idx] = System.currentTimeMillis()
                    wv.loadUrl(urlForTab(idx))
                }
            }
        }

        onDispose {
            webViews.forEach { wv ->
                try {
                    wv.stopLoading()
                    wv.destroy()
                } catch (_: Exception) {}
            }
            webViews.clear()
            ProxyManager.applyWebViewProxy(context, null, true) {}
        }
    }

    // Timeout Watchdog: auto-recovers slow free proxies after 10s
    LaunchedEffect(config.id) {
        while (true) {
            delay(2500L)
            val now = System.currentTimeMillis()
            webViews.forEachIndexed { idx, wv ->
                val startedAt = tabLoadStartedAt[idx]
                val prog = tabProgress[idx] ?: 0
                if (startedAt != null && prog < 50 && (now - startedAt) > 10_000L) {
                    tabLoadStartedAt.remove(idx)
                    recoverTabWithDirect(idx, wv)
                }
            }
        }
    }

    // Periodic Auto-Refresh + Device & Proxy Rotation Loop
    LaunchedEffect(config.id) {
        while (true) {
            val baseInterval = config.refreshIntervalSec.coerceAtLeast(15)
            val actualInterval = if (config.randomizeIntervals) {
                val jitter = (baseInterval * 0.2).toInt().coerceAtLeast(2)
                max(12, baseInterval + Random.nextInt(-jitter, jitter + 1))
            } else {
                baseInterval
            }

            for (sec in actualInterval downTo 1) {
                countdown = sec
                delay(1000L)
            }
            rotateIdentityAndReload(forceDirect = forceDirectMode)
        }
    }

    // Smooth Auto-Scroll Loop
    LaunchedEffect(config.id) {
        val scrollStepSec = config.scrollIntervalSec.coerceAtLeast(3)
        while (true) {
            delay(scrollStepSec * 1000L)
            val scrollJs = """
                (function() {
                    try {
                        const maxScroll = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight;
                        if (window.scrollY >= maxScroll - 40) {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                        } else {
                            window.scrollBy({ top: 360, behavior: 'smooth' });
                        }
                    } catch (e) {}
                })();
            """.trimIndent()
            webViews.forEach { wv ->
                wv.post { wv.evaluateJavascript(scrollJs, null) }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
    ) {
        Surface(color = SurfaceDark, tonalElevation = 4.dp) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(onClick = onMinimize) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Minimize",
                                tint = TextPrimary
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Live Engine ($tabCount Tabs)",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.Rounded.Verified,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Text(
                                text = "Next Rotate: ${countdown}s • ${tabCurrentUrls[selectedTab].orEmpty()}",
                                color = AccentBlueLight,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalIconButton(
                            onClick = {
                                webViews.getOrNull(selectedTab)?.let { wv ->
                                    tabLoadStartedAt[selectedTab] = System.currentTimeMillis()
                                    wv.reload()
                                }
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = TextPrimary
                            )
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Reload Tab")
                        }
                        FilledTonalIconButton(
                            onClick = { rotateIdentityAndReload(forceDirectMode) },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = AccentBlueLight
                            )
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = "Rotate Now")
                        }
                        FilledTonalIconButton(
                            onClick = onStop,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = DangerRed,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Stop")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuccessBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Devices,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeDevice.name} (${activeDevice.osLabel})",
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .clickable {
                                forceDirectMode = !forceDirectMode
                                rotateIdentityAndReload(forceDirect = forceDirectMode)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Public,
                            contentDescription = null,
                            tint = if (forceDirectMode) WarningAmber else AccentBlueLight,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeProxyText,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (i in 0 until tabCount) {
                        val isSelected = selectedTab == i
                        val prog = tabProgress[i] ?: 0
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) AccentBlue else CardDark)
                                .clickable { selectedTab = i }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (prog in 1..99) "Tab ${i + 1} ($prog%)" else "Tab ${i + 1}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (webViews.isNotEmpty() && selectedTab in webViews.indices) {
                key(selectedTab) {
                    val activeWebView = webViews[selectedTab]
                    AndroidView(
                        factory = {
                            (activeWebView.parent as? ViewGroup)?.removeView(activeWebView)
                            activeWebView.onResume()
                            activeWebView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            val currentProg = tabProgress[selectedTab] ?: 0
            if (currentProg in 1..99) {
                LinearProgressIndicator(
                    progress = { currentProg / 100f },
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    color = AccentBlueLight,
                    trackColor = CardDark
                )
            }
        }
    }
}
