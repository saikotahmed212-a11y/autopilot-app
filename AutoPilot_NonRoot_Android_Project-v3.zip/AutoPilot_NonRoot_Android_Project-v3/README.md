# AutoPilot Non-Root v3.0 (Final Polished Edition)

## v3.0-তে যা যা ঠিক ও আপগ্রেড করা হয়েছে
- **কাস্টম Adaptive App Logo Icon:** Android 7 থেকে Android 15—সব ফোনেই শার্প ও আধুনিক গ্রেডিয়েন্ট AutoPilot রোবট লোগো আইকন (রাউন্ড ও স্কয়ার উভয় ভার্সনসহ) যুক্ত করা হয়েছে।
- **Thread-Safe Crash Fix:** `ProxyManager` ও `ProxyController` কলব্যাকগুলোকে `Dispatchers.Main` এবং `ContextCompat.getMainExecutor`-এ সেফভাবে রাউট করা হয়েছে যাতে ব্যাকগ্রাউন্ড থ্রেড থেকে UI আপডেট হয়ে অ্যাপ ক্র্যাশ না করে।
- **Back Button সাপোর্ট:** লাইভ পেজ দেখার সময় ফোনের Back বাটন চাপলে অ্যাপ বন্ধ না হয়ে ওয়েবসাইটের আগের পেজে যাবে বা হোম স্ক্রিনে ফিরে আসবে।
- **আসল HTTPS প্রক্সি চেক + Auto-Recovery:** ১০ সেকেন্ড Timeout Watchdog এবং HTTP 407/502/503/504 Auto-Healer যুক্ত আছে।
- **Smart GitHub Actions Builder:** `.github/workflows/build-apk.yml` যুক্ত আছে যাতে এক ক্লিকেই `app-debug.apk` বিল্ড হয়।
