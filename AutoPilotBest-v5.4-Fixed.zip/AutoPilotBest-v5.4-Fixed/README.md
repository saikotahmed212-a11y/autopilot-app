# AutoPilot Best v5.0 Pro (Non-Root)

- **Persistent Background Engine (`AutomationForegroundService` + `AutomationEngineManager`)**: Automation, timers, scrolling, refreshing, proxy rotation, and auto video playback run inside a Foreground Service with `PARTIAL_WAKE_LOCK` and `START_STICKY`, continuing even when you leave the app or turn off the screen.
- **Non-Root Device Spoofing**: Generates per-session spoofed Device IDs, rotates realistic mobile/desktop User-Agent profiles, viewport metrics, and language headers without requiring root access.
- **Realtime Dashboard + Live WebView Switcher**: View Active Tabs, Refresh Count, Scroll Count, Runtime, Impressions, Video Views, Spoofed Device ID, Proxy/Country status, live Activity Log, and Tabs Overview with Pause/Stop/Add Tab controls—plus a 1-tap switch to inspect the live WebView.
- **Authenticated Proxy Pool & Real Latency Tester**: Pre-loaded with default proxies (editable via Bulk Paste and saved in `SharedPreferences`), automatic sequential IP rotation, and fixed `Proxy-Authorization` socket health check.
- **Auto Video View & Multi-Site Support**: Automatically plays HTML5 videos (with optional mute) across multiple sites and up to 15 tabs.
- **v5.1.0 Auto Clear Cache (Per Cycle)**: Automatically clears WebView cache, cookies, history, form data, and WebStorage before every IP & device rotation.
- **v5.2.0 Auto Click & Back**: Periodically clicks a visible link on loaded pages, waits 4–6 seconds, and navigates back automatically.
- **v5.3.0 Custom Click & Back Timer**: Added user-adjustable wait time slider (2s–60s) under Auto Click & Back.
- **v5.4.0 IP-Matched Timezone**: Automatically maps each proxy IP's country to its corresponding timezone (`America/New_York`, `Europe/Berlin`, etc.) and updates dashboard timestamps, logs, and status cards accordingly.
- **v5.4.1 Fix**: Fixed Kotlin string quote syntax error on line 450 in `AutomationEngineManager.kt`.
