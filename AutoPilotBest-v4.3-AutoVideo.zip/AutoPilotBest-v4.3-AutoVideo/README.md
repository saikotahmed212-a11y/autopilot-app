# AutoPilot Best

This app automates your own browsing sessions. It does NOT bypass any security challenges. Use only on sites where automation is permitted by their terms.

- v4.3.0: Added Auto Video View toggle (HTML5 `<video>` auto-playback with optional mute and live video view counter).
