package com.autopilot.nonroot.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.PowerManager
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.OndemandVideo
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.model.LiveRunnerState
import com.autopilot.nonroot.service.AutomationForegroundService
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

@SuppressLint("SetJavaScriptEnabled")
fun configureStandardWebView(webView: WebView, userAgent: String, allowAutoplay: Boolean = false) {
    webView.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        mediaPlaybackRequiresUserGesture = !allowAutoplay
        userAgentString = userAgent
    }

    CookieManager.getInstance().apply {
        setAcceptCookie(true)
        setAcceptThirdPartyCookies(webView, true)
    }
}

fun detectManualVerificationChallenge(webView: WebView, onResult: (Boolean) -> Unit) {
    val jsCheck = """
        (function() {
            const title = (document.title || '').toLowerCase();
            const text = (document.body ? document.body.innerText : '').toLowerCase();
            const hasChallengeFrame = document.querySelector(
                'iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"]'
            ) !== null;
            const hasChallengeText = title.includes('just a moment')
                || title.includes('attention required')
                || text.includes('verify you are human')
                || text.includes('checking your browser');
            return (hasChallengeFrame || hasChallengeText) ? 'CHALLENGE' : 'OK';
        })();
    """.trimIndent()

    webView.evaluateJavascript(jsCheck) { result ->
        val isChallenge = result?.contains("CHALLENGE") == true
        onResult(isChallenge)
    }
}

fun triggerAutoVideoPlayback(
    webView: WebView,
    muteVideo: Boolean,
    onResult: (Boolean) -> Unit
) {
    val muteFlag = if (muteVideo) "true" else "false"
    val jsPlay = """
        (function() {
            const videos = Array.from(document.querySelectorAll('video'));
            if (videos.length === 0) return 'NO_VIDEO';
            const target = videos.find(v => v.offsetWidth > 0 && v.offsetHeight > 0) || videos[0];
            try {
                target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                target.playsInline = true;
                if ($muteFlag) {
                    target.muted = true;
                }
                if (target.paused) {
                    const p = target.play();
                    if (p && typeof p.catch === 'function') {
                        p.catch(function() {});
                    }
                    return 'STARTED';
                }
                return 'PLAYING';
            } catch (e) {
                return 'ERROR';
            }
        })();
    """.trimIndent()

    webView.evaluateJavascript(jsPlay) { result ->
        val playing = result?.contains("STARTED") == true || result?.contains("PLAYING") == true
        onResult(playing)
    }
}

@Composable
fun AutomationWebView(
    url: String,
    profile: DeviceProfile,
    scrollIntervalSec: Int,
    randomizeIntervals: Boolean,
    proxyUser: String? = null,
    proxyPass: String? = null,
    isActivityForeground: Boolean = true,
    autoVideoViewEnabled: Boolean = false,
    muteAutoVideo: Boolean = true,
    onPageLoaded: () -> Unit = {},
    onVideoPlayed: () -> Unit = {},
    onVerificationRequired: (Boolean) -> Unit
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isPausedForVerification by remember { mutableStateOf(false) }
    var isVideoActive by remember { mutableStateOf(false) }
    var videoCountedForCycle by remember { mutableStateOf(false) }

    LaunchedEffect(webViewRef, scrollIntervalSec, isPausedForVerification, isActivityForeground, autoVideoViewEnabled, muteAutoVideo) {
        while (true) {
            val jitter = if (randomizeIntervals) Random.nextLong(-3000L, 3000L) else 0L
            delay((scrollIntervalSec * 1000L + jitter).coerceAtLeast(2000L))

            if (!isActivityForeground) continue

            webViewRef?.let { wv ->
                detectManualVerificationChallenge(wv) { detected ->
                    isPausedForVerification = detected
                    onVerificationRequired(detected)

                    if (!detected) {
                        if (autoVideoViewEnabled) {
                            triggerAutoVideoPlayback(wv, muteAutoVideo) { playing ->
                                isVideoActive = playing
                                if (playing && !videoCountedForCycle) {
                                    videoCountedForCycle = true
                                    onVideoPlayed()
                                }
                                if (!playing) {
                                    wv.evaluateJavascript(
                                        "window.scrollBy({ top: 300, behavior: 'smooth' });",
                                        null
                                    )
                                }
                            }
                        } else {
                            wv.evaluateJavascript(
                                "window.scrollBy({ top: 300, behavior: 'smooth' });",
                                null
                            )
                        }
                    }
                }
            }
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                configureStandardWebView(this, profile.userAgent, allowAutoplay = autoVideoViewEnabled)
                webChromeClient = WebChromeClient()

                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                        super.onPageFinished(view, loadedUrl)
                        if (view != null) {
                            detectManualVerificationChallenge(view) { detected ->
                                isPausedForVerification = detected
                                onVerificationRequired(detected)
                                if (!detected && autoVideoViewEnabled) {
                                    view.postDelayed({
                                        triggerAutoVideoPlayback(view, muteAutoVideo) { playing ->
                                            isVideoActive = playing
                                            if (playing && !videoCountedForCycle) {
                                                videoCountedForCycle = true
                                                onVideoPlayed()
                                            }
                                        }
                                    }, 1500L)
                                }
                            }
                        }
                        onPageLoaded()
                    }

                    override fun onReceivedHttpAuthRequest(
                        view: WebView?,
                        handler: HttpAuthHandler?,
                        host: String?,
                        realm: String?
                    ) {
                        if (!proxyUser.isNullOrEmpty() && !proxyPass.isNullOrEmpty()) {
                            handler?.proceed(proxyUser, proxyPass)
                        } else {
                            super.onReceivedHttpAuthRequest(view, handler, host, realm)
                        }
                    }
                }

                loadUrl(url)
                webViewRef = this
            }
        },
        onRelease = { wv ->
            wv.stopLoading()
            wv.loadUrl("about:blank")
            wv.clearHistory()
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
    )
}

@Composable
fun LiveAutomationViewer(
    runner: LiveRunnerState,
    proxyPool: List<ProxyNode>,
    onMinimize: () -> Unit,
    onStop: () -> Unit,
    onUpdateRunner: (LiveRunnerState) -> Unit,
    onDeviceRotated: () -> Unit,
    onImpressionRecorded: () -> Unit,
    onVideoViewRecorded: () -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }
    val config = runner.config
    val siteList = remember(config.urls) {
        config.urls.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("https://example.com") }
    }
    val tabCount = config.tabCount.coerceIn(1, 15)

    var selectedTab by remember(config.id) { mutableIntStateOf(runner.activeTabIndex) }
    var activeDevice by remember(config.id) { mutableStateOf(runner.currentDevice) }
    var proxyIndex by remember(config.id) { mutableIntStateOf(0) }
    var currentProxy by remember(config.id) { mutableStateOf(runner.currentProxy) }
    var proxyLabel by remember(config.id) { mutableStateOf(runner.currentProxyLabel) }
    var rotationCount by remember(config.id) { mutableIntStateOf(runner.rotationCount) }
    var sessionImpressions by remember(config.id) { mutableIntStateOf(runner.sessionImpressions) }
    var sessionVideoViews by remember(config.id) { mutableIntStateOf(runner.sessionVideoViews) }
    var elapsedSeconds by remember(config.id) { mutableIntStateOf(runner.elapsedSeconds) }
    var manualVerificationNeeded by remember(config.id) { mutableStateOf(false) }
    var cycleKey by remember(config.id) { mutableIntStateOf(0) }
    var isProxyReady by remember(config.id) { mutableStateOf(!config.useProxyRotation) }
    var isActivityForeground by remember(config.id) { mutableStateOf(true) }
    var secondsLeft by remember(config.id) { mutableIntStateOf(config.refreshIntervalSec.coerceAtLeast(5)) }

    BackHandler { onMinimize() }

    DisposableEffect(lifecycleOwner, config.id, config.startForegroundService) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AutoPilotBest:ForegroundViewerLock"
        ).apply {
            setReferenceCounted(false)
        }

        fun acquireForegroundLock() {
            try {
                if (!wakeLock.isHeld) {
                    wakeLock.acquire()
                }
            } catch (_: Exception) {}
        }

        fun releaseForegroundLock() {
            try {
                if (wakeLock.isHeld) {
                    wakeLock.release()
                }
            } catch (_: Exception) {}
        }

        acquireForegroundLock()

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    isActivityForeground = true
                    acquireForegroundLock()
                    if (config.startForegroundService) {
                        AutomationForegroundService.updateStatus(
                            context,
                            "Tabs: $tabCount • Elapsed: ${elapsedSeconds}s • Impr: $sessionImpressions"
                        )
                    }
                }
                Lifecycle.Event.ON_PAUSE -> {
                    isActivityForeground = false
                    if (config.startForegroundService) {
                        AutomationForegroundService.updateStatus(
                            context,
                            "Session paused — reopen the app to continue"
                        )
                    }
                }
                Lifecycle.Event.ON_STOP -> {
                    isActivityForeground = false
                    releaseForegroundLock()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            releaseForegroundLock()
        }
    }

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://example.com"
            else -> "https://$trimmed"
        }
    }

    fun urlForTab(idx: Int): String {
        return normalizeUrl(siteList[idx % siteList.size])
    }

    fun formatProxyLabel(node: ProxyNode?): String {
        if (node == null) return "Direct"
        return if (ProxyManager.isProxyOverrideSupported()) {
            node.address
        } else {
            "Direct (Override unsupported)"
        }
    }

    fun recordImpression() {
        sessionImpressions += 1
        onImpressionRecorded()
        onUpdateRunner(
            runner.copy(
                currentDevice = activeDevice,
                currentProxy = currentProxy,
                currentProxyLabel = proxyLabel,
                activeTabIndex = selectedTab,
                rotationCount = rotationCount,
                sessionImpressions = sessionImpressions,
                sessionVideoViews = sessionVideoViews,
                elapsedSeconds = elapsedSeconds,
                lastStatus = if (config.autoVideoViewEnabled) {
                    "Tabs: $tabCount • Impr: $sessionImpressions • Vid: $sessionVideoViews"
                } else {
                    "Tabs: $tabCount • Impr: $sessionImpressions"
                }
            )
        )
    }

    fun recordVideoView() {
        sessionVideoViews += 1
        onVideoViewRecorded()
        onUpdateRunner(
            runner.copy(
                currentDevice = activeDevice,
                currentProxy = currentProxy,
                currentProxyLabel = proxyLabel,
                activeTabIndex = selectedTab,
                rotationCount = rotationCount,
                sessionImpressions = sessionImpressions,
                sessionVideoViews = sessionVideoViews,
                elapsedSeconds = elapsedSeconds,
                lastStatus = "Tabs: $tabCount • Impr: $sessionImpressions • Vid: $sessionVideoViews"
            )
        )
    }

    fun rotateNow() {
        val nextDev = if (config.deviceRotationEnabled) {
            DeviceProfileEngine.pickRandom(activeDevice.name)
        } else {
            activeDevice
        }
        activeDevice = nextDev
        rotationCount += 1
        onDeviceRotated()

        val node = if (config.useProxyRotation && proxyPool.isNotEmpty()) {
            val picked = proxyPool[proxyIndex % proxyPool.size]
            proxyIndex = (proxyIndex + 1) % proxyPool.size
            picked
        } else {
            null
        }
        currentProxy = node

        isProxyReady = false
        ProxyManager.applyProxyToWebView(
            node = node,
            executor = mainExecutor
        ) { applied ->
            proxyLabel = if (node != null && applied) node.address else formatProxyLabel(node)
            secondsLeft = if (config.randomizeIntervals) {
                (config.refreshIntervalSec + Random.nextInt(-3, 4)).coerceAtLeast(5)
            } else {
                config.refreshIntervalSec.coerceAtLeast(5)
            }
            if (tabCount > 1) {
                selectedTab = (selectedTab + 1) % tabCount
            }
            isProxyReady = true
            cycleKey += 1
            onUpdateRunner(
                runner.copy(
                    currentDevice = nextDev,
                    currentProxy = node,
                    currentProxyLabel = proxyLabel,
                    activeTabIndex = selectedTab,
                    rotationCount = rotationCount,
                    sessionImpressions = sessionImpressions,
                    sessionVideoViews = sessionVideoViews,
                    elapsedSeconds = elapsedSeconds,
                    lastStatus = if (manualVerificationNeeded) "Paused: Manual verification" else "Tabs: $tabCount • Impr: $sessionImpressions"
                )
            )
        }
    }

    DisposableEffect(config.id) {
        val initialNode = if (config.useProxyRotation && proxyPool.isNotEmpty()) {
            val picked = proxyPool[0]
            proxyIndex = 1
            picked
        } else {
            null
        }
        currentProxy = initialNode

        isProxyReady = false
        ProxyManager.applyProxyToWebView(
            node = initialNode,
            executor = mainExecutor
        ) { applied ->
            proxyLabel = if (initialNode != null && applied) initialNode.address else formatProxyLabel(initialNode)
            isProxyReady = true
            cycleKey += 1
            if (config.startForegroundService) {
                AutomationForegroundService.start(
                    context,
                    "Tabs: $tabCount • Elapsed: ${elapsedSeconds}s"
                )
            }
        }

        onDispose {
            ProxyManager.applyProxyToWebView(null, executor = mainExecutor) {}
        }
    }

    LaunchedEffect(config.id, isProxyReady, manualVerificationNeeded, isActivityForeground) {
        while (true) {
            delay(1000L)
            if (isActivityForeground && isProxyReady && !manualVerificationNeeded) {
                elapsedSeconds += 1
                if (config.startForegroundService && elapsedSeconds % 5 == 0) {
                    AutomationForegroundService.updateStatus(
                        context,
                        "Tabs: $tabCount • Elapsed: ${elapsedSeconds}s • Impr: $sessionImpressions"
                    )
                }
                if (secondsLeft > 1) {
                    secondsLeft -= 1
                } else {
                    rotateNow()
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Surface(color = SurfaceDark, tonalElevation = 4.dp) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(onClick = onMinimize) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                        }
                        Column {
                            Text(
                                text = "Live (${siteList.size} Sites • $tabCount Tabs)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (manualVerificationNeeded) "Site requires manual verification" else urlForTab(selectedTab),
                                color = if (manualVerificationNeeded) WarningAmber else AccentBlueLight,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(CardDark)
                                .padding(horizontal = 7.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Timer, contentDescription = null, tint = AccentBlueLight, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${secondsLeft}s",
                                color = AccentBlueLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(CardDark)
                                .padding(horizontal = 7.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Visibility, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "$sessionImpressions",
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        if (config.autoVideoViewEnabled) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CardDark)
                                    .padding(horizontal = 7.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.OndemandVideo, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "$sessionVideoViews",
                                    color = WarningAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalIconButton(
                            onClick = { rotateNow() },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = AccentBlueLight
                            )
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = "Rotate")
                        }
                        FilledTonalIconButton(
                            onClick = {
                                AutomationForegroundService.stop(context)
                                onStop()
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = DangerRed,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Stop")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuccessBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Devices, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeDevice.name,
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (manualVerificationNeeded) Icons.Rounded.Warning else Icons.Rounded.Public,
                            contentDescription = null,
                            tint = if (manualVerificationNeeded) WarningAmber else SuccessGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = proxyLabel,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (i in 0 until tabCount) {
                        val isSelected = selectedTab == i
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) AccentBlue else CardDark)
                                .clickable { selectedTab = i }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "Tab ${i + 1}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        if (manualVerificationNeeded) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF451A03))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Site requires manual verification",
                        color = Color(0xFFFEF3C7),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                TextButton(
                    onClick = { manualVerificationNeeded = false },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Resume", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
            if (!isProxyReady) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AccentBlueLight)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Applying proxy configuration...", color = TextSecondary, fontSize = 13.sp)
                }
            } else {
                key(selectedTab, cycleKey) {
                    AutomationWebView(
                        url = urlForTab(selectedTab),
                        profile = activeDevice,
                        scrollIntervalSec = config.scrollIntervalSec,
                        randomizeIntervals = config.randomizeIntervals,
                        proxyUser = currentProxy?.username,
                        proxyPass = currentProxy?.password,
                        isActivityForeground = isActivityForeground,
                        autoVideoViewEnabled = config.autoVideoViewEnabled,
                        muteAutoVideo = config.muteAutoVideo,
                        onPageLoaded = { recordImpression() },
                        onVideoPlayed = { recordVideoView() },
                        onVerificationRequired = { detected ->
                            manualVerificationNeeded = detected
                        }
                    )
                }
            }
        }
    }
}
