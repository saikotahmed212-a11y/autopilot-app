package com.autopilot.nonroot.engine

import android.util.Base64
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicInteger

data class ProxyNode(
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val isHealthy: Boolean = false,
    val latencyMs: Long = -1L
) {
    val address: String get() = "$host:$port"
    val hasAuth: Boolean get() = !username.isNullOrBlank() && !password.isNullOrBlank()
}

data class ProxyFetchProgress(
    val tested: Int = 0,
    val total: Int = 0,
    val healthyCount: Int = 0,
    val statusText: String = "No proxies loaded"
)

object ProxyManager {

    fun parseBulkProxies(rawText: String): List<ProxyNode> {
        return rawText.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.contains(":") }
            .mapNotNull { line ->
                val cleaned = line
                    .removePrefix("http://")
                    .removePrefix("https://")
                    .trimEnd('/')
                val parts = cleaned.split(":")
                val host = parts.getOrNull(0)?.trim().orEmpty()
                val port = parts.getOrNull(1)?.trim()?.toIntOrNull()
                if (host.isEmpty() || port == null || port !in 1..65535) {
                    return@mapNotNull null
                }
                when (parts.size) {
                    2 -> ProxyNode(host = host, port = port)
                    4 -> ProxyNode(
                        host = host,
                        port = port,
                        username = parts[2].trim(),
                        password = parts[3].trim()
                    )
                    else -> null
                }
            }
    }

    suspend fun testProxyHealth(
        node: ProxyNode,
        testUrl: String = "https://www.google.com/generate_204"
    ): ProxyNode = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        var connection: HttpURLConnection? = null
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress(node.host, node.port))
            connection = (URL(testUrl).openConnection(proxy) as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = false
                if (node.hasAuth) {
                    val creds = "${node.username}:${node.password}"
                    val encoded = Base64.encodeToString(creds.toByteArray(), Base64.NO_WRAP)
                    setRequestProperty("Proxy-Authorization", "Basic $encoded")
                }
            }
            connection.connect()
            val code = connection.responseCode
            val latency = System.currentTimeMillis() - start
            val reachable = code in 200..399
            node.copy(
                isHealthy = reachable,
                latencyMs = if (reachable) latency else -1L
            )
        } catch (_: Exception) {
            node.copy(isHealthy = false, latencyMs = -1L)
        } finally {
            connection?.disconnect()
        }
    }

    suspend fun testProxyPool(
        nodes: List<ProxyNode>,
        onProgress: (ProxyFetchProgress) -> Unit
    ): List<ProxyNode> = withContext(Dispatchers.IO) {
        if (nodes.isEmpty()) {
            withContext(Dispatchers.Main) {
                onProgress(ProxyFetchProgress(0, 0, 0, "No proxies to test"))
            }
            return@withContext emptyList()
        }

        val testedCount = AtomicInteger(0)
        val healthyCount = AtomicInteger(0)

        withContext(Dispatchers.Main) {
            onProgress(ProxyFetchProgress(0, nodes.size, 0, "Testing ${nodes.size} proxies..."))
        }

        val results = coroutineScope {
            nodes.map { node ->
                async(Dispatchers.IO) {
                    val checked = testProxyHealth(node)
                    val t = testedCount.incrementAndGet()
                    val h = if (checked.isHealthy) healthyCount.incrementAndGet() else healthyCount.get()
                    withContext(Dispatchers.Main) {
                        onProgress(
                            ProxyFetchProgress(
                                tested = t,
                                total = nodes.size,
                                healthyCount = h,
                                statusText = "Tested $t/${nodes.size} ($h reachable)"
                            )
                        )
                    }
                    checked
                }
            }.awaitAll()
        }

        val sorted = results.sortedWith(
            compareByDescending<ProxyNode> { it.isHealthy }
                .thenBy { if (it.latencyMs >= 0) it.latencyMs else Long.MAX_VALUE }
        )
        val online = sorted.count { it.isHealthy }
        withContext(Dispatchers.Main) {
            onProgress(
                ProxyFetchProgress(
                    tested = nodes.size,
                    total = nodes.size,
                    healthyCount = online,
                    statusText = "$online/${nodes.size} proxies reachable"
                )
            )
        }
        sorted
    }

    fun isProxyOverrideSupported(): Boolean {
        return WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)
    }

    fun applyProxyToWebView(
        node: ProxyNode?,
        executor: Executor,
        onApplied: (Boolean) -> Unit
    ) {
        if (!isProxyOverrideSupported()) {
            onApplied(false)
            return
        }

        if (node == null) {
            ProxyController.getInstance().clearProxyOverride(executor) {
                onApplied(true)
            }
            return
        }

        val config = ProxyConfig.Builder()
            .addProxyRule("http://${node.host}:${node.port}")
            .build()

        ProxyController.getInstance().setProxyOverride(config, executor) {
            onApplied(true)
        }
    }
}
