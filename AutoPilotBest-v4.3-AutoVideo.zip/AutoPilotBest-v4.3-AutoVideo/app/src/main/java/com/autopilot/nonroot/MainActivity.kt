package com.autopilot.nonroot

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.engine.ProxyStorage
import com.autopilot.nonroot.model.*
import com.autopilot.nonroot.service.AutomationForegroundService
import com.autopilot.nonroot.ui.LiveAutomationViewer
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        setContent {
            AutoPilotApp()
        }
    }
}

@Composable
fun AutoPilotApp() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var uiState by remember {
        val savedProxies = ProxyStorage.loadProxies(context)
        val initialStatus = if (savedProxies.isEmpty()) {
            "No proxies loaded"
        } else {
            "${savedProxies.size} saved proxies loaded"
        }
        mutableStateOf(
            AppUiState(
                proxyPool = savedProxies,
                proxyProgress = ProxyFetchProgress(
                    tested = 0,
                    total = savedProxies.size,
                    healthyCount = savedProxies.count { it.isHealthy },
                    statusText = initialStatus
                )
            )
        )
    }

    fun testLoadedProxies() {
        if (uiState.isTestingProxies) return
        scope.launch {
            uiState = uiState.copy(isTestingProxies = true)
            val checked = ProxyManager.testProxyPool(uiState.proxyPool) { progress ->
                uiState = uiState.copy(proxyProgress = progress)
            }
            ProxyStorage.saveProxies(context, checked)
            uiState = uiState.copy(proxyPool = checked, isTestingProxies = false)
        }
    }

    AutoPilotTheme(darkTheme = uiState.darkThemeEnabled) {
        val activeRunner = uiState.activeRunner
        if (uiState.showLiveViewer && activeRunner != null) {
            LiveAutomationViewer(
                runner = activeRunner,
                proxyPool = uiState.proxyPool,
                onMinimize = { uiState = uiState.copy(showLiveViewer = false) },
                onStop = {
                    AutomationForegroundService.stop(context)
                    uiState = uiState.copy(activeRunner = null, showLiveViewer = false)
                },
                onUpdateRunner = { updated -> uiState = uiState.copy(activeRunner = updated) },
                onDeviceRotated = { uiState = uiState.copy(totalDeviceRotations = uiState.totalDeviceRotations + 1) },
                onImpressionRecorded = { uiState = uiState.copy(totalImpressions = uiState.totalImpressions + 1) },
                onVideoViewRecorded = { uiState = uiState.copy(totalVideoViews = uiState.totalVideoViews + 1) }
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(
                        containerColor = if (uiState.darkThemeEnabled) NavBarDark else Color.White,
                        tonalElevation = 0.dp
                    ) {
                        val tabs = listOf(
                            BottomTab.HOME to Icons.Rounded.Home,
                            BottomTab.AUTOMATIONS to Icons.Rounded.PlayCircle,
                            BottomTab.VPN to Icons.Rounded.Public,
                            BottomTab.PROFILE to Icons.Rounded.Person
                        )
                        tabs.forEach { (tab, icon) ->
                            val selected = uiState.currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { uiState = uiState.copy(currentTab = tab) },
                                icon = { Icon(imageVector = icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 12.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AccentBlueLight,
                                    indicatorColor = AccentBlue,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                    when (uiState.currentTab) {
                        BottomTab.HOME -> HomeScreen(
                            uiState = uiState,
                            onStartNew = { uiState = uiState.copy(currentTab = BottomTab.AUTOMATIONS) },
                            onOpenLive = { uiState = uiState.copy(showLiveViewer = true) },
                            onStopActive = {
                                AutomationForegroundService.stop(context)
                                uiState = uiState.copy(activeRunner = null, showLiveViewer = false)
                            },
                            onAddSchedule = { task -> uiState = uiState.copy(scheduledTasks = uiState.scheduledTasks + task) },
                            onRunScheduled = { task ->
                                val cfg = AutomationConfig(
                                    urls = parseMultipleSites(task.url),
                                    tabCount = task.tabs,
                                    refreshIntervalSec = uiState.defaultRefreshSec,
                                    scrollIntervalSec = uiState.defaultScrollSec,
                                    startForegroundService = true
                                )
                                uiState = uiState.copy(
                                    activeRunner = LiveRunnerState(config = cfg, currentDevice = DeviceProfileEngine.getRandomProfile()),
                                    showLiveViewer = true,
                                    totalAutomationsRun = uiState.totalAutomationsRun + 1
                                )
                            }
                        )

                        BottomTab.AUTOMATIONS -> CreateAutomationScreen(
                            uiState = uiState,
                            onLaunch = { config ->
                                uiState = uiState.copy(
                                    activeRunner = LiveRunnerState(config = config, currentDevice = DeviceProfileEngine.getRandomProfile()),
                                    showLiveViewer = true,
                                    totalAutomationsRun = uiState.totalAutomationsRun + 1
                                )
                            }
                        )

                        BottomTab.VPN -> ProxyPoolScreen(
                            uiState = uiState,
                            onTestProxies = { testLoadedProxies() },
                            onClearAll = {
                                ProxyStorage.clearProxies(context)
                                uiState = uiState.copy(
                                    proxyPool = emptyList(),
                                    proxyProgress = ProxyFetchProgress(0, 0, 0, "All proxies cleared")
                                )
                            },
                            onImportBulk = { parsed, replaceAll ->
                                val updated = if (replaceAll) parsed else (parsed + uiState.proxyPool)
                                ProxyStorage.saveProxies(context, updated)
                                uiState = uiState.copy(
                                    proxyPool = updated,
                                    proxyProgress = ProxyFetchProgress(
                                        tested = 0,
                                        total = updated.size,
                                        healthyCount = updated.count { it.isHealthy },
                                        statusText = "${updated.size} proxies saved"
                                    )
                                )
                            }
                        )

                        BottomTab.PROFILE -> ProfileScreen(
                            uiState = uiState,
                            onNameChange = { uiState = uiState.copy(userName = it) },
                            onEmailChange = { uiState = uiState.copy(userEmail = it) },
                            onToggleTheme = { uiState = uiState.copy(darkThemeEnabled = !uiState.darkThemeEnabled) },
                            onDefaultTabsChange = { uiState = uiState.copy(defaultTabs = it) },
                            onDefaultRefreshChange = { uiState = uiState.copy(defaultRefreshSec = it) },
                            onDefaultScrollChange = { uiState = uiState.copy(defaultScrollSec = it) },
                            onClearCache = {
                                try {
                                    CookieManager.getInstance().removeAllCookies(null)
                                    CookieManager.getInstance().flush()
                                    WebStorage.getInstance().deleteAllData()
                                    context.cacheDir.deleteRecursively()
                                } catch (_: Exception) {}
                                uiState = uiState.copy(cacheMessage = "WebView cache & cookies cleared")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppLogoBadge(sizeDp: Int = 36) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape((sizeDp / 3.5f).dp))
            .background(Color(0xFF111827)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "AutoPilot Best Logo",
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun HomeScreen(
    uiState: AppUiState,
    onStartNew: () -> Unit,
    onOpenLive: () -> Unit,
    onStopActive: () -> Unit,
    onAddSchedule: (ScheduledTask) -> Unit,
    onRunScheduled: (ScheduledTask) -> Unit
) {
    var showScheduleDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogoBadge(sizeDp = 38)
                Spacer(modifier = Modifier.width(10.dp))
                Text("AutoPilot Best", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AccentBlueLight)
            }
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(CardDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = AccentBlueLight)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Hello, ${uiState.userName}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Multi-tab browser automation for your own sites.", fontSize = 14.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp)
            ) {
                Text("Total Impressions", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("${uiState.totalImpressions}", color = SuccessGreen, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp)
            ) {
                Text("Video Views", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("${uiState.totalVideoViews}", color = WarningAmber, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp)
            ) {
                Text("Sessions", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("${uiState.totalAutomationsRun}", color = AccentBlueLight, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onStartNew,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Start New Automation", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SuccessBg)
                .border(1.dp, SuccessGreen.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(26.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Multi-Tab Browser Testing", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Automate multi-tab scrolling, reloads, and User-Agent profile views on your own sites while the app is open.",
                    color = Color(0xFFBBF7D0),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text("Active Runner", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(12.dp))

        val runner = uiState.activeRunner
        if (runner == null) {
            Box(
                modifier = Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text("No active session", color = TextSecondary, fontSize = 15.sp)
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)
            ) {
                Text("${runner.config.urls.size} Sites • ${runner.config.urls.firstOrNull().orEmpty()}", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Impressions: ${runner.sessionImpressions} • Profile: ${runner.currentDevice.name}", color = AccentBlueLight, fontSize = 13.sp)
                Text("Status: ${runner.lastStatus}", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onOpenLive, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) {
                        Text("View Live")
                    }
                    OutlinedButton(onClick = onStopActive, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF87171))) {
                        Text("Stop")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Scheduled Tasks (Local)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            TextButton(onClick = { showScheduleDialog = true }) { Text("+ Add", color = AccentBlueLight, fontWeight = FontWeight.SemiBold) }
        }

        if (uiState.scheduledTasks.isEmpty()) {
            Text("No local schedules added", color = TextSecondary, fontSize = 14.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                uiState.scheduledTasks.forEach { task ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.label, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("${task.url} • ${task.tabs} tabs • ${task.timeLabel}", color = TextSecondary, fontSize = 12.sp)
                        }
                        Button(onClick = { onRunScheduled(task) }) { Text("Run") }
                    }
                }
            }
        }
    }

    if (showScheduleDialog) {
        var label by rememberSaveable { mutableStateOf("My Site Check") }
        var url by rememberSaveable { mutableStateOf("https://example.com") }
        var time by rememberSaveable { mutableStateOf("10:00 AM") }
        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = { Text("Add Local Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Task Name") })
                    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Sites (comma separated)") })
                    OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time Label") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (url.isNotBlank()) {
                        onAddSchedule(ScheduledTask(label = label, url = url, timeLabel = time, tabs = uiState.defaultTabs))
                    }
                    showScheduleDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showScheduleDialog = false }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAutomationScreen(
    uiState: AppUiState,
    onLaunch: (AutomationConfig) -> Unit
) {
    var urlInput by rememberSaveable { mutableStateOf("https://example.com") }
    var quickSiteInput by rememberSaveable { mutableStateOf("") }
    var tabs by rememberSaveable { mutableFloatStateOf(uiState.defaultTabs.toFloat()) }
    var refreshSec by rememberSaveable { mutableIntStateOf(uiState.defaultRefreshSec) }
    var scrollSec by rememberSaveable { mutableIntStateOf(uiState.defaultScrollSec) }
    var deviceRotateEnabled by rememberSaveable { mutableStateOf(true) }
    var randomizeEnabled by rememberSaveable { mutableStateOf(true) }
    var useProxyRotation by rememberSaveable { mutableStateOf(true) }
    var startForegroundService by rememberSaveable { mutableStateOf(true) }
    var autoVideoViewEnabled by rememberSaveable { mutableStateOf(true) }
    var muteAutoVideo by rememberSaveable { mutableStateOf(true) }

    var refreshExpanded by remember { mutableStateOf(false) }
    var scrollExpanded by remember { mutableStateOf(false) }

    val refreshOptions = listOf(15, 30, 45, 60, 90, 120)
    val scrollOptions = listOf(5, 8, 10, 15, 20, 30)
    val parsedSites = remember(urlInput) { parseMultipleSites(urlInput) }

    fun addQuickSite() {
        val cleaned = quickSiteInput.trim()
        if (cleaned.isNotEmpty()) {
            urlInput = if (urlInput.isBlank()) cleaned else "$urlInput, $cleaned"
            quickSiteInput = ""
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("Create Automation", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(18.dp)
        ) {
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text("Target URLs (comma or newline separated)") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = quickSiteInput,
                    onValueChange = { quickSiteInput = it },
                    label = { Text("Add site") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                FilledTonalButton(onClick = { addQuickSite() }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("${parsedSites.size} sites configured", color = AccentBlueLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                parsedSites.forEach { site ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(site, color = TextPrimary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Number of Tabs", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("1", color = TextSecondary, fontSize = 13.sp)
                Slider(
                    value = tabs,
                    onValueChange = { tabs = it },
                    valueRange = 1f..15f,
                    steps = 13,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("15", color = TextSecondary, fontSize = 13.sp)
            }
            Text("${tabs.roundToInt()} tabs", color = AccentBlueLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

            Spacer(modifier = Modifier.height(14.dp))
            Text("Auto Refresh Interval (seconds)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(expanded = refreshExpanded, onExpandedChange = { refreshExpanded = !refreshExpanded }) {
                OutlinedTextField(
                    value = refreshSec.toString(),
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = refreshExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                )
                ExposedDropdownMenu(expanded = refreshExpanded, onDismissRequest = { refreshExpanded = false }) {
                    refreshOptions.forEach { opt ->
                        DropdownMenuItem(text = { Text("$opt seconds") }, onClick = { refreshSec = opt; refreshExpanded = false })
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Auto Scroll Interval (seconds)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(expanded = scrollExpanded, onExpandedChange = { scrollExpanded = !scrollExpanded }) {
                OutlinedTextField(
                    value = scrollSec.toString(),
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scrollExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                )
                ExposedDropdownMenu(expanded = scrollExpanded, onDismissRequest = { scrollExpanded = false }) {
                    scrollOptions.forEach { opt ->
                        DropdownMenuItem(text = { Text("$opt seconds") }, onClick = { scrollSec = opt; scrollExpanded = false })
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Device Profile Rotation", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                Switch(checked = deviceRotateEnabled, onCheckedChange = { deviceRotateEnabled = it })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Randomize Intervals (±3s)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                Switch(checked = randomizeEnabled, onCheckedChange = { randomizeEnabled = it })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Use Proxy Rotation", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                Switch(checked = useProxyRotation, onCheckedChange = { useProxyRotation = it })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Start Foreground Service", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                    Text("Shows session stats notification while active", color = TextSecondary, fontSize = 11.sp)
                }
                Switch(checked = startForegroundService, onCheckedChange = { startForegroundService = it })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Auto Video View", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Automatically plays HTML5 videos on loaded pages", color = WarningAmber, fontSize = 11.sp)
                }
                Switch(checked = autoVideoViewEnabled, onCheckedChange = { autoVideoViewEnabled = it })
            }
            if (autoVideoViewEnabled) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Mute Auto-Played Videos", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                    Switch(checked = muteAutoVideo, onCheckedChange = { muteAutoVideo = it })
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    onLaunch(
                        AutomationConfig(
                            urls = parsedSites,
                            tabCount = tabs.roundToInt(),
                            refreshIntervalSec = refreshSec,
                            scrollIntervalSec = scrollSec,
                            deviceRotationEnabled = deviceRotateEnabled,
                            randomizeIntervals = randomizeEnabled,
                            useProxyRotation = useProxyRotation,
                            startForegroundService = startForegroundService,
                            autoVideoViewEnabled = autoVideoViewEnabled,
                            muteAutoVideo = muteAutoVideo
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Launch Live Viewer", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProxyPoolScreen(
    uiState: AppUiState,
    onTestProxies: () -> Unit,
    onClearAll: () -> Unit,
    onImportBulk: (List<ProxyNode>, Boolean) -> Unit
) {
    var showBulkDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Proxy Pool", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Row {
                IconButton(onClick = { showBulkDialog = true }) { Icon(Icons.Rounded.Add, contentDescription = "Bulk Paste", tint = AccentBlueLight) }
                IconButton(onClick = onTestProxies) { Icon(Icons.Rounded.Refresh, contentDescription = "Test Proxies", tint = AccentBlueLight) }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "You are responsible for the proxies you use.",
            color = WarningAmber,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(AccentBlue), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Shield, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("${uiState.proxyPool.size} Proxies Saved", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(uiState.proxyProgress.statusText, fontSize = 12.sp, color = SuccessGreen)
            }
            if (uiState.isTestingProxies) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp, color = AccentBlueLight)
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showBulkDialog = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) {
                Text("Bulk Paste")
            }
            FilledTonalButton(onClick = onTestProxies, modifier = Modifier.weight(1f), enabled = uiState.proxyPool.isNotEmpty() && !uiState.isTestingProxies) {
                Text("Test Proxies")
            }
            OutlinedButton(onClick = onClearAll, enabled = uiState.proxyPool.isNotEmpty()) {
                Text("Clear All")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        if (uiState.proxyPool.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text("No proxies added. Tap Bulk Paste to add your proxies.", color = TextSecondary, fontSize = 13.sp)
            }
        } else {
            uiState.proxyPool.forEach { node ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(node.address, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                        Text(if (node.hasAuth) "HTTP • Auth configured" else "HTTP • Unauthenticated", color = TextSecondary, fontSize = 11.sp)
                    }
                    val statusLabel = when {
                        node.isHealthy && node.latencyMs >= 0 -> "${node.latencyMs} ms"
                        !node.isHealthy && node.latencyMs == -1L && uiState.proxyProgress.tested > 0 -> "unreachable"
                        else -> "untested"
                    }
                    Text(
                        text = statusLabel,
                        color = if (node.isHealthy) SuccessGreen else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showBulkDialog) {
        var bulkText by rememberSaveable { mutableStateOf("") }
        var replaceAll by rememberSaveable { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showBulkDialog = false },
            title = { Text("Bulk Paste Proxies") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Format: host:port or host:port:username:password (one per line)", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(value = bulkText, onValueChange = { bulkText = it }, label = { Text("Proxies") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = replaceAll, onCheckedChange = { replaceAll = it })
                        Text("Replace existing list", fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parsed = ProxyManager.parseBulkProxies(bulkText)
                    if (parsed.isNotEmpty()) onImportBulk(parsed, replaceAll)
                    showBulkDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBulkDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ProfileScreen(
    uiState: AppUiState,
    onNameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onToggleTheme: () -> Unit,
    onDefaultTabsChange: (Int) -> Unit,
    onDefaultRefreshChange: (Int) -> Unit,
    onDefaultScrollChange: (Int) -> Unit,
    onClearCache: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Profile", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(18.dp))
        AppLogoBadge(sizeDp = 84)
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = uiState.userName,
            onValueChange = onNameChange,
            label = { Text("Display Name (Local)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = uiState.userEmail,
            onValueChange = onEmailChange,
            label = { Text("Email (Local)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onToggleTheme() }.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Theme", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Text(if (uiState.darkThemeEnabled) "Dark" else "Light", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Column(modifier = Modifier.fillMaxWidth()) {
            Text("Default Tabs: ${uiState.defaultTabs}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultTabs.toFloat(), onValueChange = { onDefaultTabsChange(it.roundToInt()) }, valueRange = 1f..15f, steps = 13)
            Text("Default Refresh (sec): ${uiState.defaultRefreshSec}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultRefreshSec.toFloat(), onValueChange = { onDefaultRefreshChange(it.roundToInt()) }, valueRange = 15f..120f, steps = 9)
            Text("Default Scroll (sec): ${uiState.defaultScrollSec}", color = MaterialTheme.colorScheme.onBackground)
            Slider(value = uiState.defaultScrollSec.toFloat(), onValueChange = { onDefaultScrollChange(it.roundToInt()) }, valueRange = 5f..30f, steps = 4)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Clear WebView cache & cookies", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                Text(uiState.cacheMessage ?: "Removes stored WebView cookies and storage", color = TextSecondary, fontSize = 12.sp)
            }
            TextButton(onClick = onClearCache) { Text("Clear", color = AccentBlueLight, fontWeight = FontWeight.Bold) }
        }
    }
}
