package com.autopilot.nonroot.model

import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyNode
import java.util.UUID

enum class BottomTab(val label: String) {
    HOME("Home"),
    AUTOMATIONS("Automations"),
    VPN("Proxies"),
    PROFILE("Profile")
}

fun parseMultipleSites(rawInput: String): List<String> {
    return rawInput
        .split(",", "\n", ";")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
        .ifEmpty { listOf("https://example.com") }
}

data class AutomationConfig(
    val id: String = UUID.randomUUID().toString(),
    val urls: List<String>,
    val tabCount: Int = 3,
    val refreshIntervalSec: Int = 45,
    val scrollIntervalSec: Int = 8,
    val deviceRotationEnabled: Boolean = true,
    val randomizeIntervals: Boolean = true,
    val useProxyRotation: Boolean = true,
    val startForegroundService: Boolean = true,
    val autoVideoViewEnabled: Boolean = false,
    val muteAutoVideo: Boolean = true
)

data class ScheduledTask(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val url: String,
    val timeLabel: String,
    val tabs: Int
)

data class LiveRunnerState(
    val config: AutomationConfig,
    val isRunning: Boolean = true,
    val currentDevice: DeviceProfile = DeviceProfileEngine.getRandomProfile(),
    val currentProxy: ProxyNode? = null,
    val currentProxyLabel: String = "Direct",
    val activeTabIndex: Int = 0,
    val rotationCount: Int = 1,
    val sessionImpressions: Int = 0,
    val sessionVideoViews: Int = 0,
    val elapsedSeconds: Int = 0,
    val lastStatus: String = "Active"
)

data class AppUiState(
    val currentTab: BottomTab = BottomTab.HOME,
    val userName: String = "User",
    val userEmail: String = "user@example.com",
    val totalAutomationsRun: Int = 0,
    val totalDeviceRotations: Int = 0,
    val totalImpressions: Int = 0,
    val totalVideoViews: Int = 0,
    val defaultTabs: Int = 3,
    val defaultRefreshSec: Int = 45,
    val defaultScrollSec: Int = 8,
    val darkThemeEnabled: Boolean = true,
    val proxyPool: List<ProxyNode> = emptyList(),
    val isTestingProxies: Boolean = false,
    val proxyProgress: ProxyFetchProgress = ProxyFetchProgress(0, 0, 0, "No proxies loaded"),
    val activeRunner: LiveRunnerState? = null,
    val showLiveViewer: Boolean = false,
    val scheduledTasks: List<ScheduledTask> = emptyList(),
    val cacheMessage: String? = null
)
