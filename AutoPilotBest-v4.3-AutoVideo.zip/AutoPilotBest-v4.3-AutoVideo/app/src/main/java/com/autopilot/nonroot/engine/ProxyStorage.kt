package com.autopilot.nonroot.engine

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ProxyStorage {

    private const val PREFS_NAME = "autopilot_proxy_prefs"
    private const val KEY_PROXIES = "saved_proxies_json"

    fun saveProxies(context: Context, proxies: List<ProxyNode>) {
        val jsonArray = JSONArray()
        for (node in proxies) {
            val obj = JSONObject().apply {
                put("host", node.host)
                put("port", node.port)
                put("username", node.username ?: "")
                put("password", node.password ?: "")
                put("isHealthy", node.isHealthy)
                put("latencyMs", node.latencyMs)
            }
            jsonArray.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PROXIES, jsonArray.toString())
            .apply()
    }

    fun loadProxies(context: Context): List<ProxyNode> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PROXIES, null) ?: return emptyList()

        return try {
            val jsonArray = JSONArray(raw)
            val result = mutableListOf<ProxyNode>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val host = obj.optString("host", "").trim()
                val port = obj.optInt("port", -1)
                if (host.isNotEmpty() && port in 1..65535) {
                    val user = obj.optString("username", "").takeIf { it.isNotEmpty() }
                    val pass = obj.optString("password", "").takeIf { it.isNotEmpty() }
                    val healthy = obj.optBoolean("isHealthy", false)
                    val latency = obj.optLong("latencyMs", -1L)
                    result.add(
                        ProxyNode(
                            host = host,
                            port = port,
                            username = user,
                            password = pass,
                            isHealthy = healthy,
                            latencyMs = latency
                        )
                    )
                }
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearProxies(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_PROXIES)
            .apply()
    }
}
