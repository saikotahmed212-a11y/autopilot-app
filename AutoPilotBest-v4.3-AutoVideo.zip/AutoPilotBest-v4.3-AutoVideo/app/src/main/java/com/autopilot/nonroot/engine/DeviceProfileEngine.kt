package com.autopilot.nonroot.engine

data class DeviceProfile(
    val name: String,
    val userAgent: String,
    val acceptLanguage: String = "en-US,en;q=0.9",
    val osLabel: String = "Mobile/Desktop"
) {
    val id: String get() = name
}

object DeviceProfileEngine {
    val profiles: List<DeviceProfile> = listOf(
        DeviceProfile(
            name = "Android Chrome",
            userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "Android 14"
        ),
        DeviceProfile(
            name = "iOS Safari",
            userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "iOS 17.6"
        ),
        DeviceProfile(
            name = "Desktop Chrome Windows",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
            acceptLanguage = "en-US,en;q=0.9",
            osLabel = "Windows 10/11"
        )
    )

    fun getRandomProfile(): DeviceProfile = profiles.random()

    fun pickRandom(excludeId: String? = null): DeviceProfile {
        val candidates = profiles.filter { it.name != excludeId }
        return if (candidates.isNotEmpty()) candidates.random() else getRandomProfile()
    }
}
