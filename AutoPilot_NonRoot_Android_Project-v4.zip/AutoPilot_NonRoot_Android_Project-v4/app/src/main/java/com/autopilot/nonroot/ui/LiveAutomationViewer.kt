package com.autopilot.nonroot.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.model.LiveRunnerState
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.delay
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.random.Random

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LiveAutomationViewer(
    runner: LiveRunnerState,
    proxyPool: List<ProxyNode>,
    onMinimize: () -> Unit,
    onStop: () -> Unit,
    onUpdateRunner: (LiveRunnerState) -> Unit,
    onDeviceRotated: () -> Unit
) {
    val context = LocalContext.current
    val config = runner.config
    val tabCount = config.tabCount.coerceIn(1, 15)

    val latestRunner by rememberUpdatedState(runner)
    val latestProxies by rememberUpdatedState(proxyPool)

    val webViews = remember(config.id) { mutableStateListOf<WebView>() }
    val tabProgress = remember(config.id) { mutableStateMapOf<Int, Int>() }
    val tabCurrentUrls = remember(config.id) { mutableStateMapOf<Int, String>() }
    val tabLoadStartedAt = remember(config.id) { mutableStateMapOf<Int, Long>() }

    // Holds the currently active ProxyNode so WebViewClient.onReceivedHttpAuthRequest can authenticate cleanly
    val activeProxyRef = remember(config.id) { AtomicReference<ProxyNode?>(null) }
    var currentProxyIndex by remember(config.id) { mutableIntStateOf(0) }
    var activeDevice by remember(config.id) { mutableStateOf(runner.currentDevice) }
    var activeProxyText by remember(config.id) { mutableStateOf(runner.currentProxyLabel) }
    var countdown by remember(config.id) { mutableIntStateOf(config.refreshIntervalSec) }
    var rotationCount by remember(config.id) { mutableIntStateOf(runner.rotationCount) }
    var selectedTab by remember(config.id) { mutableIntStateOf(runner.activeTabIndex) }
    var forceDirectMode by remember(config.id) { mutableStateOf(!config.useProxyRotation) }
    var lastAutoSkipMs by remember(config.id) { mutableLongStateOf(0L) }

    BackHandler {
        val currentWv = webViews.getOrNull(selectedTab)
        if (currentWv != null && currentWv.canGoBack()) {
            currentWv.goBack()
        } else {
            onMinimize()
        }
    }

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.isEmpty() -> "https://whatismyipaddress.com"
            else -> "https://$trimmed"
        }
    }

    fun urlForTab(index: Int): String {
        val list = config.urls.ifEmpty { listOf("https://whatismyipaddress.com") }
        return normalizeUrl(list[index % list.size])
    }

    fun applyDeviceToWebView(wv: WebView, profile: DeviceProfile) {
        wv.settings.userAgentString = profile.userAgent
    }

    fun pickNextProxy(forceDirect: Boolean): ProxyNode? {
        if (forceDirect || !config.useProxyRotation) return null
        val list = latestProxies
        if (list.isEmpty()) return null
        val node = list[currentProxyIndex % list.size]
        currentProxyIndex = (currentProxyIndex + 1) % list.size
        return node
    }

    fun rotateIdentityAndReload(forceDirect: Boolean = forceDirectMode, reason: String = "Rotated") {
        if (config.clearCookiesOnRotate) {
            try {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            } catch (_: Exception) {}
        }

        val nextDevice = if (config.deviceRotationEnabled) {
            DeviceProfileEngine.pickRandom(activeDevice.id)
        } else {
            activeDevice
        }
        activeDevice = nextDevice
        rotationCount += 1
        onDeviceRotated()

        val chosenProxy = pickNextProxy(forceDirect)
        activeProxyRef.set(chosenProxy)

        ProxyManager.applyWebViewProxy(
            context = context,
            proxy = chosenProxy,
            allowDirectFallback = config.autoFallbackDirect
        ) { appliedLabel ->
            val badge = if (chosenProxy != null) "${chosenProxy.label} • $appliedLabel" else appliedLabel
            activeProxyText = badge
            onUpdateRunner(
                latestRunner.copy(
                    currentDevice = nextDevice,
                    currentProxyLabel = badge,
                    rotationCount = rotationCount,
                    activeTabIndex = selectedTab,
                    lastStatus = "$reason: ${nextDevice.name}"
                )
            )
            webViews.forEachIndexed { idx, wv ->
                wv.post {
                    applyDeviceToWebView(wv, nextDevice)
                    tabLoadStartedAt[idx] = System.currentTimeMillis()
                    wv.stopLoading()
                    wv.loadUrl(urlForTab(idx))
                }
            }
        }
    }

    /**
     * Strict No-Leak recovery:
     * - If autoFallbackDirect is OFF (default), switches to the NEXT Webshare proxy (never leaks real IP).
     * - If autoFallbackDirect is ON, falls back to Direct Connection.
     */
    fun handleProxyFailure() {
        val now = System.currentTimeMillis()
        if (now - lastAutoSkipMs < 6000L) return
        lastAutoSkipMs = now

        if (config.autoFallbackDirect) {
            activeProxyRef.set(null)
            ProxyManager.applyWebViewProxy(context, null, true) { label ->
                activeProxyText = "$label (Fallback)"
                webViews.forEachIndexed { idx, wv ->
                    wv.post {
                        tabLoadStartedAt[idx] = System.currentTimeMillis()
                        wv.loadUrl(urlForTab(idx))
                    }
                }
            }
        } else if (!forceDirectMode && latestProxies.size > 1) {
            rotateIdentityAndReload(forceDirect = false, reason = "Auto-Skipped Proxy")
        }
    }

    DisposableEffect(config.id) {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        val initialProxy = pickNextProxy(forceDirectMode)
        activeProxyRef.set(initialProxy)

        for (i in 0 until tabCount) {
            val targetUrl = urlForTab(i)
            tabCurrentUrls[i] = targetUrl
            tabProgress[i] = 10

            val wv = WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(android.graphics.Color.WHITE)

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    allowContentAccess = true
                    allowFileAccess = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    setSupportZoom(true)
                    setSupportMultipleWindows(false)
                    javaScriptCanOpenWindowsAutomatically = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    mediaPlaybackRequiresUserGesture = false
                    cacheMode = WebSettings.LOAD_NO_CACHE
                    userAgentString = activeDevice.userAgent
                }

                cookieManager.setAcceptThirdPartyCookies(this, true)

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        tabProgress[i] = newProgress
                        if (newProgress >= 100) {
                            tabLoadStartedAt.remove(i)
                        }
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun onReceivedHttpAuthRequest(
                        view: WebView?,
                        handler: HttpAuthHandler?,
                        host: String?,
                        realm: String?
                    ) {
                        val proxy = activeProxyRef.get()
                        if (proxy != null && proxy.hasAuth) {
                            handler?.proceed(proxy.username, proxy.password)
                        } else {
                            super.onReceivedHttpAuthRequest(view, handler, host, realm)
                        }
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return false
                        val scheme = uri.scheme?.lowercase().orEmpty()
                        return !(scheme == "http" || scheme == "https")
                    }

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        tabProgress[i] = 15
                        tabLoadStartedAt[i] = System.currentTimeMillis()
                        if (!url.isNullOrBlank()) tabCurrentUrls[i] = url
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        tabProgress[i] = 100
                        tabLoadStartedAt.remove(i)
                        if (!url.isNullOrBlank()) tabCurrentUrls[i] = url
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        if (request?.isForMainFrame == true) {
                            handleProxyFailure()
                        }
                    }

                    @SuppressLint("WebViewClientOnReceivedSslError")
                    override fun onReceivedSslError(
                        view: WebView?,
                        handler: SslErrorHandler?,
                        error: SslError?
                    ) {
                        handler?.proceed()
                    }
                }
            }
            webViews.add(wv)
        }

        ProxyManager.applyWebViewProxy(
            context = context,
            proxy = initialProxy,
            allowDirectFallback = config.autoFallbackDirect
        ) { appliedLabel ->
            val badge = if (initialProxy != null) "${initialProxy.label} • $appliedLabel" else appliedLabel
            activeProxyText = badge
            onUpdateRunner(
                latestRunner.copy(
                    currentDevice = activeDevice,
                    currentProxyLabel = badge,
                    lastStatus = "Live on ${activeDevice.name}"
                )
            )
            webViews.forEachIndexed { idx, wv ->
                wv.post {
                    tabLoadStartedAt[idx] = System.currentTimeMillis()
                    wv.loadUrl(urlForTab(idx))
                }
            }
        }

        onDispose {
            activeProxyRef.set(null)
            webViews.forEach { wv ->
                try {
                    wv.stopLoading()
                    wv.destroy()
                } catch (_: Exception) {}
            }
            webViews.clear()
            ProxyManager.applyWebViewProxy(context, null, true) {}
        }
    }

    // Watchdog: if a proxy hangs > 15s, auto-skip to the NEXT proxy (Strict No-Leak)
    LaunchedEffect(config.id) {
        while (true) {
            delay(3000L)
            val now = System.currentTimeMillis()
            val stuck = webViews.indices.any { idx ->
                val startedAt = tabLoadStartedAt[idx]
                val prog = tabProgress[idx] ?: 0
                startedAt != null && prog < 35 && (now - startedAt) > 15_000L
            }
            if (stuck) {
                tabLoadStartedAt.clear()
                handleProxyFailure()
            }
        }
    }

    // Periodic Auto-Refresh + Auto Proxy & Device Rotation Loop
    LaunchedEffect(config.id) {
        while (true) {
            val baseInterval = config.refreshIntervalSec.coerceAtLeast(15)
            val actualInterval = if (config.randomizeIntervals) {
                val jitter = (baseInterval * 0.2).toInt().coerceAtLeast(2)
                max(12, baseInterval + Random.nextInt(-jitter, jitter + 1))
            } else {
                baseInterval
            }

            for (sec in actualInterval downTo 1) {
                countdown = sec
                delay(1000L)
            }
            rotateIdentityAndReload(forceDirect = forceDirectMode)
        }
    }

    // Smooth Auto-Scroll Loop
    LaunchedEffect(config.id) {
        val scrollStepSec = config.scrollIntervalSec.coerceAtLeast(3)
        while (true) {
            delay(scrollStepSec * 1000L)
            val scrollJs = """
                (function() {
                    try {
                        const maxScroll = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight;
                        if (window.scrollY >= maxScroll - 40) {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                        } else {
                            window.scrollBy({ top: 360, behavior: 'smooth' });
                        }
                    } catch (e) {}
                })();
            """.trimIndent()
            webViews.forEach { wv ->
                wv.post { wv.evaluateJavascript(scrollJs, null) }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Surface(color = SurfaceDark, tonalElevation = 4.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(onClick = onMinimize) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Minimize",
                                tint = TextPrimary
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Live Engine ($tabCount Tabs)",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.Rounded.Verified,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Text(
                                text = "Next IP Rotate: ${countdown}s • ${tabCurrentUrls[selectedTab].orEmpty()}",
                                color = AccentBlueLight,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalIconButton(
                            onClick = {
                                webViews.getOrNull(selectedTab)?.let { wv ->
                                    tabLoadStartedAt[selectedTab] = System.currentTimeMillis()
                                    wv.reload()
                                }
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = TextPrimary
                            )
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Reload Tab")
                        }
                        FilledTonalIconButton(
                            onClick = { rotateIdentityAndReload(forceDirectMode, "Manual Rotate") },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = CardDark,
                                contentColor = AccentBlueLight
                            )
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = "Next Proxy & Device")
                        }
                        FilledTonalIconButton(
                            onClick = onStop,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = DangerRed,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Stop")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuccessBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Devices,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeDevice.name} (${activeDevice.osLabel})",
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardDark)
                            .clickable {
                                rotateIdentityAndReload(forceDirect = forceDirectMode, reason = "Next IP")
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Public,
                            contentDescription = null,
                            tint = if (forceDirectMode) WarningAmber else SuccessGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeProxyText,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (i in 0 until tabCount) {
                        val isSelected = selectedTab == i
                        val prog = tabProgress[i] ?: 0
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) AccentBlue else CardDark)
                                .clickable { selectedTab = i }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (prog in 1..99) "Tab ${i + 1} ($prog%)" else "Tab ${i + 1}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (webViews.isNotEmpty() && selectedTab in webViews.indices) {
                key(selectedTab) {
                    val activeWebView = webViews[selectedTab]
                    AndroidView(
                        factory = {
                            (activeWebView.parent as? ViewGroup)?.removeView(activeWebView)
                            activeWebView.onResume()
                            activeWebView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            val currentProg = tabProgress[selectedTab] ?: 0
            if (currentProg in 1..99) {
                LinearProgressIndicator(
                    progress = { currentProg / 100f },
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    color = AccentBlueLight,
                    trackColor = CardDark
                )
            }
        }
    }
}
