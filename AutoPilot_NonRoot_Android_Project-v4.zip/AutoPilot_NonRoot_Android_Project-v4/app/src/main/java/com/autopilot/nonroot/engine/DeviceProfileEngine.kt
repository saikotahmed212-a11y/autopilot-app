package com.autopilot.nonroot.engine

import kotlin.random.Random

data class DeviceProfile(
    val id: String,
    val name: String,
    val osLabel: String,
    val userAgent: String
)

object DeviceProfileEngine {

    val profiles: List<DeviceProfile> = listOf(
        DeviceProfile(
            id = "s24_ultra",
            name = "Samsung Galaxy S24 Ultra",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "pixel_9_pro",
            name = "Google Pixel 9 Pro",
            osLabel = "Android 15",
            userAgent = "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.83 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "xiaomi_14",
            name = "Xiaomi 14 Pro",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; 23116PN5BC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.102 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "oneplus_12",
            name = "OnePlus 12 5G",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; CPH2581) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.104 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "iphone_16_pro",
            name = "iPhone 16 Pro",
            osLabel = "iOS 18",
            userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1"
        ),
        DeviceProfile(
            id = "redmi_note_13",
            name = "Redmi Note 13 Pro",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; 2312DRA50G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.6668.100 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "samsung_a55",
            name = "Samsung Galaxy A55 5G",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; SM-A556E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.81 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "vivo_v40",
            name = "Vivo V40 Pro",
            osLabel = "Android 14",
            userAgent = "Mozilla/5.0 (Linux; Android 14; V2347) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36"
        ),
        DeviceProfile(
            id = "windows_chrome",
            name = "Windows 11 Desktop",
            osLabel = "Chrome 132",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
        ),
        DeviceProfile(
            id = "macbook_safari",
            name = "MacBook Air M3",
            osLabel = "macOS Safari",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
        )
    )

    fun pickRandom(excludeId: String? = null): DeviceProfile {
        val candidates = profiles.filter { it.id != excludeId }
        return if (candidates.isNotEmpty()) {
            candidates[Random.nextInt(candidates.size)]
        } else {
            profiles.first()
        }
    }
}
