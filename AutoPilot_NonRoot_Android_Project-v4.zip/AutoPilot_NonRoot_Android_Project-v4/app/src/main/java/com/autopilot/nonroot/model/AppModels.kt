package com.autopilot.nonroot.model

import com.autopilot.nonroot.engine.DeviceProfile
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import java.util.UUID

enum class BottomTab(val label: String) {
    HOME("Home"),
    AUTOMATIONS("Automations"),
    VPN("Proxies"),
    PROFILE("Profile")
}

data class AutomationConfig(
    val id: String = UUID.randomUUID().toString(),
    val urls: List<String>,
    val tabCount: Int = 3,
    val refreshIntervalSec: Int = 45,
    val scrollIntervalSec: Int = 8,
    val deviceRotationEnabled: Boolean = true,
    val randomizeIntervals: Boolean = true,
    val useProxyRotation: Boolean = true,
    val autoFallbackDirect: Boolean = false, // Strict No-Leak by default!
    val clearCookiesOnRotate: Boolean = false
)

data class ScheduledTask(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val url: String,
    val timeLabel: String,
    val tabs: Int
)

data class LiveRunnerState(
    val config: AutomationConfig,
    val isRunning: Boolean = true,
    val currentDevice: DeviceProfile = DeviceProfileEngine.pickRandom(),
    val currentProxyLabel: String = "Connecting Proxy...",
    val activeTabIndex: Int = 0,
    val rotationCount: Int = 1,
    val lastStatus: String = "Loading pages..."
)

data class AppUiState(
    val currentTab: BottomTab = BottomTab.HOME,
    val userName: String = "Expert",
    val userEmail: String = "autopilot.nonroot@local",
    val totalAutomationsRun: Int = 0,
    val totalDeviceRotations: Int = 0,
    val defaultTabs: Int = 3,
    val defaultRefreshSec: Int = 45,
    val defaultScrollSec: Int = 8,
    val darkThemeEnabled: Boolean = true,
    val proxyPool: List<ProxyNode> = ProxyManager.defaultWebshareProxies,
    val isTestingProxies: Boolean = false,
    val proxyProgress: ProxyFetchProgress = ProxyFetchProgress(),
    val activeRunner: LiveRunnerState? = null,
    val showLiveViewer: Boolean = false,
    val scheduledTasks: List<ScheduledTask> = emptyList(),
    val cacheMessage: String? = null
)
