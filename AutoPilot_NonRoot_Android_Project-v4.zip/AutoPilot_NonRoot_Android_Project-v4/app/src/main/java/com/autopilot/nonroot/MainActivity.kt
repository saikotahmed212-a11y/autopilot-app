package com.autopilot.nonroot

import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autopilot.nonroot.engine.DeviceProfileEngine
import com.autopilot.nonroot.engine.ProxyFetchProgress
import com.autopilot.nonroot.engine.ProxyManager
import com.autopilot.nonroot.engine.ProxyNode
import com.autopilot.nonroot.model.*
import com.autopilot.nonroot.ui.LiveAutomationViewer
import com.autopilot.nonroot.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AutoPilotApp()
        }
    }
}

@Composable
fun AutoPilotApp() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var uiState by remember { mutableStateOf(AppUiState()) }

    fun testLoadedProxies() {
        if (uiState.isTestingProxies) return
        scope.launch {
            uiState = uiState.copy(isTestingProxies = true)
            val checked = ProxyManager.testProxyPool(uiState.proxyPool) { progress ->
                uiState = uiState.copy(proxyProgress = progress)
            }
            uiState = uiState.copy(
                proxyPool = checked,
                isTestingProxies = false
            )
        }
    }

    AutoPilotTheme(darkTheme = uiState.darkThemeEnabled) {
        val activeRunner = uiState.activeRunner
        if (uiState.showLiveViewer && activeRunner != null) {
            LiveAutomationViewer(
                runner = activeRunner,
                proxyPool = uiState.proxyPool,
                onMinimize = { uiState = uiState.copy(showLiveViewer = false) },
                onStop = {
                    uiState = uiState.copy(activeRunner = null, showLiveViewer = false)
                },
                onUpdateRunner = { updated ->
                    uiState = uiState.copy(activeRunner = updated)
                },
                onDeviceRotated = {
                    uiState = uiState.copy(totalDeviceRotations = uiState.totalDeviceRotations + 1)
                }
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(
                        containerColor = if (uiState.darkThemeEnabled) NavBarDark else Color.White,
                        tonalElevation = 0.dp
                    ) {
                        val tabs = listOf(
                            BottomTab.HOME to Icons.Rounded.Home,
                            BottomTab.AUTOMATIONS to Icons.Rounded.PlayCircle,
                            BottomTab.VPN to Icons.Rounded.Public,
                            BottomTab.PROFILE to Icons.Rounded.Person
                        )
                        tabs.forEach { (tab, icon) ->
                            val selected = uiState.currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { uiState = uiState.copy(currentTab = tab) },
                                icon = {
                                    Icon(imageVector = icon, contentDescription = tab.label)
                                },
                                label = { Text(tab.label, fontSize = 12.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AccentBlueLight,
                                    indicatorColor = AccentBlue,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (uiState.currentTab) {
                        BottomTab.HOME -> HomeScreen(
                            uiState = uiState,
                            onStartNew = { uiState = uiState.copy(currentTab = BottomTab.AUTOMATIONS) },
                            onOpenLive = { uiState = uiState.copy(showLiveViewer = true) },
                            onStopActive = { uiState = uiState.copy(activeRunner = null, showLiveViewer = false) },
                            onAddSchedule = { task ->
                                uiState = uiState.copy(scheduledTasks = uiState.scheduledTasks + task)
                            },
                            onRunScheduled = { task ->
                                val cfg = AutomationConfig(
                                    urls = listOf(task.url),
                                    tabCount = task.tabs,
                                    refreshIntervalSec = uiState.defaultRefreshSec,
                                    scrollIntervalSec = uiState.defaultScrollSec
                                )
                                uiState = uiState.copy(
                                    activeRunner = LiveRunnerState(
                                        config = cfg,
                                        currentDevice = DeviceProfileEngine.pickRandom()
                                    ),
                                    showLiveViewer = true,
                                    totalAutomationsRun = uiState.totalAutomationsRun + 1
                                )
                            }
                        )

                        BottomTab.AUTOMATIONS -> CreateAutomationScreen(
                            uiState = uiState,
                            onLaunch = { config ->
                                uiState = uiState.copy(
                                    activeRunner = LiveRunnerState(
                                        config = config,
                                        currentDevice = DeviceProfileEngine.pickRandom()
                                    ),
                                    showLiveViewer = true,
                                    totalAutomationsRun = uiState.totalAutomationsRun + 1
                                )
                            }
                        )

                        BottomTab.VPN -> ProxyPoolScreen(
                            uiState = uiState,
                            onTestProxies = { testLoadedProxies() },
                            onResetWebshare = {
                                val defaults = ProxyManager.defaultWebshareProxies
                                uiState = uiState.copy(
                                    proxyPool = defaults,
                                    proxyProgress = ProxyFetchProgress(
                                        tested = defaults.size,
                                        total = defaults.size,
                                        healthyCount = defaults.size,
                                        statusText = "${defaults.size} Webshare private proxies restored"
                                    )
                                )
                            },
                            onImportBulk = { parsed, replaceAll ->
                                val updated = if (replaceAll) parsed else (parsed + uiState.proxyPool)
                                uiState = uiState.copy(
                                    proxyPool = updated,
                                    proxyProgress = ProxyFetchProgress(
                                        tested = updated.size,
                                        total = updated.size,
                                        healthyCount = updated.size,
                                        statusText = "${updated.size} proxies loaded & ready"
                                    )
                                )
                            }
                        )

                        BottomTab.PROFILE -> ProfileScreen(
                            uiState = uiState,
                            onToggleTheme = {
                                uiState = uiState.copy(darkThemeEnabled = !uiState.darkThemeEnabled)
                            },
                            onDefaultTabsChange = { uiState = uiState.copy(defaultTabs = it) },
                            onDefaultRefreshChange = { uiState = uiState.copy(defaultRefreshSec = it) },
                            onDefaultScrollChange = { uiState = uiState.copy(defaultScrollSec = it) },
                            onClearCache = {
                                try {
                                    CookieManager.getInstance().removeAllCookies(null)
                                    CookieManager.getInstance().flush()
                                    WebStorage.getInstance().deleteAllData()
                                    context.cacheDir.deleteRecursively()
                                } catch (_: Exception) {}
                                uiState = uiState.copy(cacheMessage = "Cache & cookies cleared (0.0 MB)")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppLogoBadge(sizeDp: Int = 36) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape((sizeDp / 3.5f).dp))
            .background(Color(0xFF152B52)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "AutoPilot Logo",
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun HomeScreen(
    uiState: AppUiState,
    onStartNew: () -> Unit,
    onOpenLive: () -> Unit,
    onStopActive: () -> Unit,
    onAddSchedule: (ScheduledTask) -> Unit,
    onRunScheduled: (ScheduledTask) -> Unit
) {
    var showScheduleDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogoBadge(sizeDp = 38)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "AutoPilot",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentBlueLight
                )
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CardDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = AccentBlueLight)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Hello, ${uiState.userName} 👋",
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Private Proxy Rotation + Non-Root Engine Ready.",
            fontSize = 15.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onStartNew,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Start New Automation",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SuccessBg)
                .border(1.dp, SuccessGreen.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.VerifiedUser,
                contentDescription = null,
                tint = SuccessGreen,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Webshare Private Pool Active (v4.0)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "${uiState.proxyPool.size} private authenticated proxies loaded with Strict No-Leak protection & auto IP rotation.",
                    color = Color(0xFFBBF7D0),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Active Automations",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(12.dp))

        val runner = uiState.activeRunner
        if (runner == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(128.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.PlayCircle,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No active automations", color = TextSecondary, fontSize = 15.sp)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = runner.config.urls.firstOrNull().orEmpty(),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Surface(color = SuccessBg, shape = RoundedCornerShape(10.dp)) {
                        Text(
                            text = "LIVE",
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Device: ${runner.currentDevice.name}", color = AccentBlueLight, fontSize = 13.sp)
                Text("Proxy: ${runner.currentProxyLabel} • ${runner.config.tabCount} tabs", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onOpenLive,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        Text("View Live Pages")
                    }
                    OutlinedButton(
                        onClick = onStopActive,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF87171))
                    ) {
                        Text("Stop")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Scheduled",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            TextButton(onClick = { showScheduleDialog = true }) {
                Text("+ Add", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
            }
        }

        if (uiState.scheduledTasks.isEmpty()) {
            Text(
                text = "No schedules yet — tap + Add to save a quick preset.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                uiState.scheduledTasks.forEach { task ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(task.label, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("${task.url} • ${task.tabs} tabs • ${task.timeLabel}", color = TextSecondary, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { onRunScheduled(task) },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Run")
                        }
                    }
                }
            }
        }
    }

    if (showScheduleDialog) {
        var label by remember { mutableStateOf("Quick Preset") }
        var url by remember { mutableStateOf("https://whatismyipaddress.com") }
        var time by remember { mutableStateOf("10:00 AM") }

        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = { Text("Add Scheduled Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Task Name") })
                    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Website URL") })
                    OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (url.isNotBlank()) {
                        onAddSchedule(ScheduledTask(label = label, url = url, timeLabel = time, tabs = uiState.defaultTabs))
                    }
                    showScheduleDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAutomationScreen(
    uiState: AppUiState,
    onLaunch: (AutomationConfig) -> Unit
) {
    var urlInput by remember { mutableStateOf("https://whatismyipaddress.com") }
    var tabs by remember { mutableFloatStateOf(uiState.defaultTabs.toFloat()) }
    var refreshSec by remember { mutableIntStateOf(uiState.defaultRefreshSec) }
    var scrollSec by remember { mutableIntStateOf(uiState.defaultScrollSec) }
    var deviceRotateEnabled by remember { mutableStateOf(true) }
    var randomizeEnabled by remember { mutableStateOf(true) }
    var useProxyRotation by remember { mutableStateOf(true) }
    var autoFallback by remember { mutableStateOf(false) } // Strict No-Leak default OFF!
    var showAdvanced by remember { mutableStateOf(false) }

    var refreshExpanded by remember { mutableStateOf(false) }
    var scrollExpanded by remember { mutableStateOf(false) }

    val refreshOptions = listOf(15, 30, 45, 60, 90, 120)
    val scrollOptions = listOf(5, 8, 10, 15, 20, 30)

    val demoPresets = listOf(
        "Check IP" to "https://whatismyipaddress.com",
        "Check IP Fast" to "https://ipv4.webshare.io/",
        "Check UA/Device" to "https://httpbin.org/user-agent",
        "Google" to "https://www.google.com"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            text = "Create Automation",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(18.dp)
        ) {
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text("Website URL (comma = multiple)") },
                trailingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = false,
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text("Quick Test Sites:", color = TextSecondary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                demoPresets.forEach { (title, link) ->
                    AssistChip(
                        onClick = { urlInput = link },
                        label = { Text(title, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Number of Tabs", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("1", color = TextSecondary, fontSize = 13.sp)
                Slider(
                    value = tabs,
                    onValueChange = { tabs = it },
                    valueRange = 1f..15f,
                    steps = 13,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = AccentBlueLight,
                        activeTrackColor = AccentBlueLight,
                        inactiveTrackColor = AccentTeal
                    )
                )
                Text("15", color = TextSecondary, fontSize = 13.sp)
            }
            Text("${tabs.roundToInt()} tabs", color = AccentBlueLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

            Spacer(modifier = Modifier.height(16.dp))

            Text("Auto Refresh & IP Rotate Interval (sec)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(
                expanded = refreshExpanded,
                onExpandedChange = { refreshExpanded = !refreshExpanded }
            ) {
                OutlinedTextField(
                    value = refreshSec.toString(),
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = refreshExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = refreshExpanded,
                    onDismissRequest = { refreshExpanded = false }
                ) {
                    refreshOptions.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text("$opt seconds") },
                            onClick = {
                                refreshSec = opt
                                refreshExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text("Auto Scroll Interval (seconds)", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            ExposedDropdownMenuBox(
                expanded = scrollExpanded,
                onExpandedChange = { scrollExpanded = !scrollExpanded }
            ) {
                OutlinedTextField(
                    value = scrollSec.toString(),
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scrollExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = scrollExpanded,
                    onDismissRequest = { scrollExpanded = false }
                ) {
                    scrollOptions.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text("$opt seconds") },
                            onClick = {
                                scrollSec = opt
                                scrollExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto Device Profile Switch (Non-Root)",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Rotates mobile & desktop User-Agent automatically",
                        color = SuccessGreen,
                        fontSize = 12.sp
                    )
                }
                Switch(checked = deviceRotateEnabled, onCheckedChange = { deviceRotateEnabled = it })
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto Proxy IP Rotation",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${uiState.proxyPool.size} private proxies rotating automatically",
                        color = AccentBlueLight,
                        fontSize = 12.sp
                    )
                }
                Switch(checked = useProxyRotation, onCheckedChange = { useProxyRotation = it })
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAdvanced = !showAdvanced }
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Advanced Options", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                Icon(
                    imageVector = if (showAdvanced) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }

            if (showAdvanced) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Randomize Intervals", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                    Switch(checked = randomizeEnabled, onCheckedChange = { randomizeEnabled = it })
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Direct IP Fallback", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                        Text("Keep OFF to never leak your real Bangladesh IP", color = WarningAmber, fontSize = 12.sp)
                    }
                    Switch(checked = autoFallback, onCheckedChange = { autoFallback = it })
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val parsedUrls = urlInput
                        .split(",")
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .ifEmpty { listOf("https://whatismyipaddress.com") }

                    onLaunch(
                        AutomationConfig(
                            urls = parsedUrls,
                            tabCount = tabs.roundToInt(),
                            refreshIntervalSec = refreshSec,
                            scrollIntervalSec = scrollSec,
                            deviceRotationEnabled = deviceRotateEnabled,
                            randomizeIntervals = randomizeEnabled,
                            useProxyRotation = useProxyRotation,
                            autoFallbackDirect = autoFallback
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Live Automation", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProxyPoolScreen(
    uiState: AppUiState,
    onTestProxies: () -> Unit,
    onResetWebshare: () -> Unit,
    onImportBulk: (List<ProxyNode>, Boolean) -> Unit
) {
    var showBulkDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Private Proxy Pool",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Row {
                IconButton(onClick = { showBulkDialog = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Bulk Import Proxies", tint = AccentBlueLight)
                }
                IconButton(onClick = onTestProxies) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Test Latency", tint = AccentBlueLight)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AccentBlue),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Shield, contentDescription = null, tint = Color.White)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${uiState.proxyPool.size} Proxies Loaded",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = uiState.proxyProgress.statusText,
                    fontSize = 12.sp,
                    color = SuccessGreen
                )
            }
            if (uiState.isTestingProxies) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.5.dp,
                    color = AccentBlueLight
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { showBulkDialog = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bulk Paste", fontSize = 13.sp)
            }
            OutlinedButton(
                onClick = onResetWebshare,
                modifier = Modifier.weight(1f)
            ) {
                Text("Reset Webshare 10", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Active Auto-Rotation List",
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        uiState.proxyPool.forEach { node ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(node.address, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text(
                        text = if (node.hasAuth) "${node.label} • Auth Enabled" else node.label,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                val badgeText = if (node.latencyMs > 0) "${node.latencyMs} ms" else "READY"
                Text(badgeText, color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showBulkDialog) {
        var bulkText by remember { mutableStateOf("") }
        var replaceAll by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBulkDialog = false },
            title = { Text("Bulk Import Proxies") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste one per line in format:\nhost:port:username:password\nor host:port",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = bulkText,
                        onValueChange = { bulkText = it },
                        label = { Text("Proxy List") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = replaceAll, onCheckedChange = { replaceAll = it })
                        Text("Replace existing proxies", fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parsed = ProxyManager.parseBulkProxies(bulkText)
                    if (parsed.isNotEmpty()) {
                        onImportBulk(parsed, replaceAll)
                    }
                    showBulkDialog = false
                }) { Text("Import") }
            },
            dismissButton = {
                TextButton(onClick = { showBulkDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ProfileScreen(
    uiState: AppUiState,
    onToggleTheme: () -> Unit,
    onDefaultTabsChange: (Int) -> Unit,
    onDefaultRefreshChange: (Int) -> Unit,
    onDefaultScrollChange: (Int) -> Unit,
    onClearCache: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Profile",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(18.dp))

        AppLogoBadge(sizeDp = 84)

        Spacer(modifier = Modifier.height(12.dp))
        Text(uiState.userName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(uiState.userEmail, fontSize = 13.sp, color = TextSecondary)

        Spacer(modifier = Modifier.height(20.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp)
        ) {
            Text("Usage Stats", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = BorderMuted)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total Automations", color = TextSecondary)
                Text("${uiState.totalAutomationsRun}", color = AccentBlueLight, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("IP & Device Rotations", color = TextSecondary)
                Text("${uiState.totalDeviceRotations}", color = SuccessGreen, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(22.dp))
        Text("Appearance", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { onToggleTheme() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Palette, contentDescription = null, tint = AccentBlueLight)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Theme", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text(if (uiState.darkThemeEnabled) "Dark" else "Light", color = TextSecondary, fontSize = 12.sp)
                }
            }
            Text(if (uiState.darkThemeEnabled) "Dark" else "Light", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(22.dp))
        Text("Default Preferences", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(12.dp))

        Column(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Number of Tabs", color = MaterialTheme.colorScheme.onBackground)
                Text("${uiState.defaultTabs}", color = AccentBlueLight, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = uiState.defaultTabs.toFloat(),
                onValueChange = { onDefaultTabsChange(it.roundToInt()) },
                valueRange = 1f..15f,
                steps = 13
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Refresh Interval (sec)", color = MaterialTheme.colorScheme.onBackground)
                Text("${uiState.defaultRefreshSec}", color = AccentBlueLight, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = uiState.defaultRefreshSec.toFloat(),
                onValueChange = { onDefaultRefreshChange(it.roundToInt()) },
                valueRange = 15f..120f,
                steps = 9
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Scroll Interval (sec)", color = MaterialTheme.colorScheme.onBackground)
                Text("${uiState.defaultScrollSec}", color = AccentBlueLight, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = uiState.defaultScrollSec.toFloat(),
                onValueChange = { onDefaultScrollChange(it.roundToInt()) },
                valueRange = 3f..30f,
                steps = 8
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Device & Engine Status", color = AccentBlueLight, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Strict No-Leak Proxy Engine", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text("Webshare Auth + Auto-Skip enabled", color = TextSecondary, fontSize = 12.sp)
                }
                Surface(color = SuccessBg, shape = RoundedCornerShape(10.dp)) {
                    Text(
                        "v4.0 Active",
                        color = SuccessGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                    Text(uiState.cacheMessage ?: "WebView cache & cookies", color = TextSecondary, fontSize = 12.sp)
                }
                TextButton(onClick = onClearCache) {
                    Text("Clear", color = AccentBlueLight, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
